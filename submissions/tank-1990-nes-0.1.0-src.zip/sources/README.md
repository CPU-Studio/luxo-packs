# Tank 1990: Battlefield in Depth — model sources

All models are original designs built from scratch for this pack.  Nothing is
copied from the game's art; the game's sprites are only used on this machine as
a size and role reference.

## Rebuild

`build_models.py` creates every model in its own Blender scene, saves a
`.blend` in `sources/blend/`, and prints the triangle counts.  Run it in a live
Blender (MCP `execute_blender_code`) or headless:

```
blender -b --python sources/build_models.py
```

Then export each one to `../models/`:

```
for m in player_tank enemy_tank enemy_heavy shell eagle_base explosion; do
  blender -b sources/blend/$m.blend --python ../../tools/luxo3d/blender_export.py \
      -- --out ../models/$m.glb
done
```

## Models

| Model | File | Triangles | Size (w x h x d, game px) | Notes |
|---|---|---|---|---|
| Hero medium tank | `player_tank.glb` | 11,260 | 15.3 x 10.1 x 19.2 | yellow/cream paint, long gun, cupola, AA MG, stowage, antenna |
| Raider light tank | `enemy_tank.glb` | 5,732 | 13.2 x 7.9 x 16.6 | wedge hull, exposed road wheels, dozer blade, missile pod; `pal1`–`pal3` materials take the enemy palette |
| Bulwark heavy tank | `enemy_heavy.glb` | 5,772 | 17.2 x 7.4 x 18.4 | spaced armour, twin stacks, box turret, heavy gun, rocket pod; `pal1`–`pal3` |
| Shell | `shell.glb` | 656 | 2.0 x 4.3 x 2.1 | brass projectile used for the bullet groups |
| Eagle monument | `eagle_base.glb` | 3,088 | 15.0 x 6.9 x 15.0 | stone plinth and bronze eagle for the defended base |
| Explosion burst | `explosion.glb` | 1,216 | 10.0 x 8.3 x 10.0 | hot core with eight flame spikes; used at 1.25x in the pack |

Every model uses 256 px embedded PNG textures, UV set 0, Z up, facing −Y in
Blender (the exporter turns it into +Y up, facing +Z).  The enemy tanks use
materials named `pal1`, `pal2` and `pal3`, so the same model is green (palette
5) or grey/blue (palette 6) in game.

## Look

The contact-shadow plates are part of the models: they ground the tanks on the
black battlefield.  The hero tank's barrel is deliberately thicker and longer
than scale so it reads from the 58° top camera.
