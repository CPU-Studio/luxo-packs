"""Tank 1990 3D pack: rebuild every model from scratch.

Run inside Blender (the live session or `blender -b --python`).  Each model is
built at 1 Blender unit = 1 game pixel, Z up, facing -Y (front view) and saved
as its own .blend in this folder; export with blender_export.py.

All designs are original: a hero medium tank, a light raider tank, a heavy
assault tank and a shell.  Textures are generated here with numpy and packed
into the .blend / GLB.
"""

import math
import os

import bmesh
import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else "/home/kienct/luxo-tools/my-packs/tank-1990-nes/sources"
N = 256


# ---------------------------------------------------------------------------
# scene / material helpers

def begin_model(name):
    """Build in a scene of its own, so the person's open scene is untouched."""
    sc = bpy.data.scenes.new("Luxo_" + name)
    bpy.context.window.scene = sc
    world = bpy.data.worlds.new("LuxoWorld_" + name)
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg is not None:
        bg.inputs[0].default_value = (0.16, 0.17, 0.19, 1)
        bg.inputs[1].default_value = 1.0
    sc.world = world
    return sc


def save_blend(name, sc):
    # The model scene is active, so it is the scene the .blend opens on.
    blend_dir = os.path.join(HERE, "blend")
    os.makedirs(blend_dir, exist_ok=True)
    path = os.path.join(blend_dir, name + ".blend")
    bpy.ops.wm.save_as_mainfile(filepath=path, copy=True)
    print("saved", path)


def close_model(sc):
    for o in list(sc.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.data.scenes.remove(sc)


def tri_count():
    n = 0
    for o in bpy.context.scene.objects:
        if o.type == "MESH":
            o.data.calc_loop_triangles()
            n += len(o.data.loop_triangles)
    return n


def rgba_image(name, rgb):
    img = bpy.data.images.new(name, N, N, alpha=True)
    rgba = np.ones((N, N, 4), dtype=np.float32)
    rgba[..., :3] = np.clip(rgb, 0, 1)[::-1]
    img.pixels.foreach_set(rgba.ravel())
    img.file_format = "PNG"
    img.pack()
    return img


def make_mat(name, image, roughness=0.6, metallic=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = next(n for n in nodes if n.type == "BSDF_PRINCIPLED")
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = image
    tex.interpolation = "Linear"
    mat.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    return mat


def solid_mat(name, rgb, roughness=0.7, metallic=0.0):
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = rgb
    return make_mat(name, rgba_image(name + "_tex", img), roughness, metallic)


# ---------------------------------------------------------------------------
# textures

def _blur(a, r):
    out = a.copy()
    for _ in range(r):
        out = (out + np.roll(out, 1, 0) + np.roll(out, -1, 0)
               + np.roll(out, 1, 1) + np.roll(out, -1, 1)) / 5
    return out


def _noise(rng, scale):
    a = _blur(rng.random((N, N)), scale)
    a -= a.min()
    return a / max(a.max(), 1e-6)


def paint_texture(base, camo, seed, stencil=False):
    """Weathered factory paint with camo blotches, seams and rivets."""
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:N, 0:N]
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = base
    # camo: soft irregular patches
    n = _noise(rng, 12)
    m = _blur((n > 0.56).astype(np.float32), 2)
    m = np.clip((m - 0.35) * 4, 0, 1)[..., None]
    img = img * (1 - m * 0.85) + np.array(camo)[None, None, :] * (m * 0.85)
    # grain and panel seams
    grain = _noise(rng, 1)
    img *= (0.86 + 0.22 * grain[..., None])
    for c in (x, y):
        mm = c % 64
        img[mm == 0] *= 0.55
        img[mm == 1] *= 1.10
    # rivets on seams
    for c in range(6, N, 18):
        for s in range(0, N, 64):
            for (ry, rx) in ((c, s + 8), (s + 8, c)):
                d = (y - ry) ** 2 + (x - rx) ** 2
                img[d <= 3] *= 1.30
                img[(d > 3) & (d <= 6)] *= 0.65
    # wear and scratches
    g = _noise(rng, 10)
    img *= (1 - 0.30 * np.clip(g - 0.55, 0, 1)[..., None] * 3)
    for _ in range(70):
        x0, y0 = rng.integers(0, N, 2)
        ang = rng.random() * math.pi
        for t in range(rng.integers(4, 26)):
            px = int(x0 + math.cos(ang) * t) % N
            py = int(y0 + math.sin(ang) * t) % N
            img[py, px] = img[py, px] * 0.5 + np.array([0.62, 0.60, 0.52]) * 0.5
    if stencil:
        # a simple painted chevron stripe near the rear
        band = (x > 180) & (x < 214) & (((y + (x - 180)) % 26) < 9)
        img[band] = img[band] * 0.25 + np.array([0.95, 0.92, 0.80]) * 0.75
    return img


def metal_texture(dark=0.30, seed=7):
    rng = np.random.default_rng(seed)
    streak = _blur(rng.random((N, N)), 1).mean(axis=1, keepdims=True)
    streak = np.repeat(streak, N, axis=1)
    img = np.full((N, N, 3), dark, dtype=np.float32)
    img *= (0.80 + 0.38 * streak[..., None])
    img *= (0.88 + 0.24 * _noise(rng, 3)[..., None])
    return np.clip(img, 0, 1)


def track_texture():
    rng = np.random.default_rng(11)
    y, x = np.mgrid[0:N, 0:N]
    img = np.full((N, N, 3), 0.17, dtype=np.float32)
    img *= (0.82 + 0.35 * _noise(rng, 2)[..., None])
    mx, my = x % 32, y % 32
    img[(mx < 2) | (my < 2)] *= 0.45
    img[(my > 12) & (my < 19)] = img[(my > 12) & (my < 19)] * 1.65 + 0.04
    pin = ((mx - 1) ** 2 + (my - 16) ** 2) < 7
    img[pin] = 0.55
    return np.clip(img, 0, 1)


def detail_texture(seed=3):
    """Light grey surface for palette materials: seams, bolts, wear."""
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:N, 0:N]
    img = np.full((N, N, 3), 0.82, dtype=np.float32)
    img *= (0.90 + 0.16 * _noise(rng, 2)[..., None])
    for c in (x, y):
        mm = c % 48
        img[mm == 0] *= 0.62
        img[mm == 1] *= 1.10
    for c in range(7, N, 24):
        for s in range(0, N, 48):
            d = (y - c) ** 2 + (x - (s + 6)) ** 2
            img[d <= 3] *= 1.18
            img[(d > 3) & (d <= 5)] *= 0.80
    g = _noise(rng, 12)
    img *= (1 - 0.22 * np.clip(g - 0.6, 0, 1)[..., None] * 3)
    return np.clip(img, 0, 1)


# ---------------------------------------------------------------------------
# geometry helpers

def box(name, size, loc, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return o


def cyl(name, r, depth, loc, rot=(0, 0, 0), verts=24, r2=None):
    if r2 is None:
        bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=r, depth=depth,
                                            location=loc, rotation=rot)
    else:
        bpy.ops.mesh.primitive_cone_add(vertices=verts, radius1=r, radius2=r2,
                                        depth=depth, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    return o


def sphere(name, r, loc, segs=20, rings=12):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segs, ring_count=rings, radius=r, location=loc)
    o = bpy.context.active_object
    o.name = name
    return o


def box_map(obj, density):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    uv = bm.loops.layers.uv.verify()
    for f in bm.faces:
        n = f.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        a, b = [(1, 2), (0, 2), (0, 1)][ax]
        for loop in f.loops:
            co = loop.vert.co
            loop[uv].uv = (co[a] * density, co[b] * density)
    bm.transform(obj.matrix_world.inverted())
    bm.to_mesh(obj.data)
    bm.free()


def finish(obj, mat, density, bevel=0.0, segments=2, smooth=False):
    obj.data.materials.append(mat)
    if bevel > 0:
        m = obj.modifiers.new("bevel", "BEVEL")
        m.width = bevel
        m.segments = segments
        m.limit_method = "ANGLE"
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(modifier=m.name)
    box_map(obj, density)
    if smooth:
        for p in obj.data.polygons:
            p.use_smooth = True
        # Mark hard edges by hand instead of adding Blender's "Smooth by
        # Angle" modifier, which links the bundled geometry-nodes library:
        # source bundles must not link library files.
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        for e in bm.edges:
            if len(e.link_faces) == 2:
                try:
                    if e.calc_face_angle() > math.radians(40):
                        e.smooth = False
                except ValueError:
                    pass
        bm.to_mesh(obj.data)
        bm.free()
    return obj


def taper(obj, ztop, fx, fy):
    for v in obj.data.vertices:
        if v.co.z > ztop - 1e-4:
            v.co.x *= fx
            v.co.y *= fy


def slope_front(obj, zmin, amount):
    for v in obj.data.vertices:
        if v.co.z > zmin and v.co.y < 0:
            v.co.y += amount


def camera_and_lights():
    bpy.ops.object.camera_add(location=(19, -27, 26), rotation=(math.radians(55), 0, math.radians(35)))
    cam = bpy.context.active_object
    cam.data.lens = 70
    bpy.context.scene.camera = cam
    bpy.ops.object.light_add(type="SUN", location=(-14, -18, 30), rotation=(math.radians(48), math.radians(8), math.radians(-35)))
    bpy.context.active_object.data.energy = 4.0
    bpy.ops.object.light_add(type="AREA", location=(18, 14, 18), rotation=(math.radians(40), 0, math.radians(140)))
    bpy.context.active_object.data.energy = 500
    bpy.context.active_object.data.size = 20
    bpy.context.scene.render.engine = "BLENDER_EEVEE"
    bpy.context.scene.render.resolution_x = 640
    bpy.context.scene.render.resolution_y = 640


# ---------------------------------------------------------------------------
# hero medium tank

def build_player():
    sc = begin_model("player")
    paint = make_mat("paint", rgba_image("paint", paint_texture(
        (0.84, 0.58, 0.13), (0.42, 0.34, 0.11), 1990, stencil=True)), 0.52, 0.05)
    cream = make_mat("paint_cream", rgba_image("paint_cream", paint_texture(
        (0.95, 0.83, 0.52), (0.88, 0.52, 0.12), 1991)), 0.50, 0.03)
    track = make_mat("track", rgba_image("track", track_texture()), 0.85, 0.15)
    metal = make_mat("metal", rgba_image("metal", metal_texture()), 0.35, 0.75)
    glass = solid_mat("glass", (0.85, 0.93, 0.95), 0.15, 0.0)
    light = solid_mat("lamp", (1.0, 0.92, 0.62), 0.25, 0.0)
    shadow = solid_mat("shadow", (0.05, 0.05, 0.05), 0.95, 0.0)

    D_P, D_T, D_M = 1 / 5.0, 1 / 2.2, 1 / 3.0

    sh = box("contact_shadow", (13.6, 16.4, 0.16), (0, 0, 0.08))
    finish(sh, shadow, 0.5, smooth=False)

    # running gear, both sides: track band, road wheels, sprocket/idler, skirt
    for side in (-1, 1):
        x = side * 5.6
        band = box("track_%d" % side, (2.7, 15.4, 2.7), (x, 0, 1.35))
        finish(band, track, D_T, bevel=0.75, segments=4, smooth=True)
        for i in range(5):
            w = cyl("wheel_%d_%d" % (side, i), 1.05, 0.55, (x + side * 1.36, -5.2 + i * 2.6, 1.15),
                    rot=(0, math.pi / 2, 0), verts=18)
            finish(w, metal, D_M, bevel=0.12)
            hub = cyl("hub_%d_%d" % (side, i), 0.42, 0.62, (x + side * 1.47, -5.2 + i * 2.6, 1.15),
                      rot=(0, math.pi / 2, 0), verts=12)
            finish(hub, paint, D_P, bevel=0.06)
        for yy in (-7.1, 7.1):
            sp = cyl("sprocket_%d_%d" % (side, int(yy)), 0.85, 0.6, (x + side * 1.40, yy, 1.7),
                     rot=(0, math.pi / 2, 0), verts=10)
            finish(sp, metal, D_M, bevel=0.1)
        skirt = box("skirt_%d" % side, (0.45, 13.8, 1.25), (x + side * 1.52, -0.3, 2.65))
        finish(skirt, paint, D_P, bevel=0.14, segments=2)
        # three spare track links hung on the skirt
        for i in range(3):
            link = box("spare_%d_%d" % (side, i), (0.30, 1.15, 0.55), (x + side * 1.72, 2.4 + i * 1.4, 2.15))
            finish(link, track, D_T, bevel=0.08)

    # hull: sloped glacis, rear plate, fenders
    hull = box("hull", (10.4, 14.2, 2.5), (0, 0, 3.05))
    slope_front(hull, 3.4, 1.9)
    finish(hull, paint, D_P, bevel=0.30, segments=3, smooth=True)
    glacis = box("glacis", (9.6, 2.2, 1.7), (0, -6.0, 3.6), rot=(math.radians(-32), 0, 0))
    finish(glacis, paint, D_P, bevel=0.18)
    plate = box("front_plate", (6.4, 1.4, 0.35), (0, -6.6, 4.2), rot=(math.radians(-28), 0, 0))
    finish(plate, cream, D_P, bevel=0.08)
    rear = box("rear_plate", (9.4, 0.6, 1.9), (0, 7.0, 3.1), rot=(math.radians(12), 0, 0))
    finish(rear, paint, D_P, bevel=0.12)
    for side in (-1, 1):
        f = box("fender_%d" % side, (1.5, 14.6, 0.28), (side * 6.9, 0, 4.05))
        finish(f, cream, D_P, bevel=0.06)
    # tow hooks and headlights
    for side in (-1, 1):
        hook = box("hook_%d" % side, (0.55, 0.9, 0.55), (side * 3.4, -7.3, 2.3))
        finish(hook, metal, D_M, bevel=0.12)
        lamp = cyl("lamp_%d" % side, 0.42, 0.35, (side * 4.2, -7.1, 4.15), rot=(math.radians(90), 0, 0), verts=14)
        finish(lamp, light, D_M, bevel=0.05)
        guard = box("lamp_guard_%d" % side, (0.85, 0.12, 0.85), (side * 4.2, -7.28, 4.15))
        finish(guard, metal, D_M)
    # spare track links on the glacis
    for i in range(3):
        l = box("glacis_link_%d" % i, (1.6, 0.55, 0.38), (0.0, -5.3 + i * 0.9, 4.35 - i * 0.25))
        finish(l, track, D_T, bevel=0.07)

    # turret: faceted, tapered, with a rear bustle
    ring = cyl("turret_ring", 3.5, 0.35, (0, 0.9, 4.45), verts=28)
    finish(ring, metal, D_M, bevel=0.08)
    collar = cyl("turret_collar", 3.7, 0.5, (0, 0.9, 4.8), verts=9)
    finish(collar, metal, D_M, bevel=0.08)
    tur = cyl("turret", 3.8, 2.5, (0, 0.9, 5.75), verts=9)
    taper(tur, 5.9, 0.74, 0.82)
    for v in tur.data.vertices:
        if v.co.y > 1.6:
            v.co.y *= 1.28
    finish(tur, cream, D_P, bevel=0.36, segments=3, smooth=True)
    bustle = box("bustle", (4.6, 2.6, 1.4), (0, 4.3, 5.55))
    finish(bustle, paint, D_P, bevel=0.28, segments=3)
    # stowage basket at the back
    for i in range(3):
        bar = box("basket_%d" % i, (4.4, 0.12, 0.12), (0, 4.5 + i * 0.4, 6.25))
        finish(bar, metal, D_M)
    for side in (-1, 1):
        br = box("basket_side_%d" % side, (0.12, 1.2, 0.5), (side * 2.2, 4.9, 6.0))
        finish(br, metal, D_M)

    # commander cupola, hatch, periscopes, AA machine gun
    cup = cyl("cupola", 1.15, 0.65, (-1.15, 2.2, 7.05), verts=18)
    finish(cup, cream, D_P, bevel=0.14, smooth=True)
    hatch = cyl("hatch", 0.85, 0.22, (-1.15, 2.2, 7.42), verts=18)
    finish(hatch, metal, D_M, bevel=0.06)
    for i, (px, py) in enumerate(((-2.0, 1.2), (-0.3, 1.2), (-1.15, 3.1))):
        p = box("periscope_%d" % i, (0.5, 0.32, 0.30), (px, py, 7.02))
        finish(p, glass, D_M)
    # AA MG on the cupola
    mg_base = cyl("mg_base", 0.28, 0.5, (0.1, 2.3, 7.05), verts=10)
    finish(mg_base, metal, D_M)
    mg = cyl("mg_barrel", 0.13, 2.4, (0.1, 1.1, 7.25), rot=(math.radians(90), 0, 0), verts=8)
    finish(mg, metal, D_M)

    # main gun: mantlet, barrel, muzzle brake, coax
    mant = box("mantlet", (2.5, 1.2, 1.55), (0, -2.6, 5.35))
    finish(mant, paint, D_P, bevel=0.3, segments=3, smooth=True)
    barrel = cyl("barrel", 0.72, 7.0, (0, -6.5, 5.35), rot=(math.radians(90), 0, 0), verts=18)
    finish(barrel, metal, D_M, bevel=0.05)
    brake = cyl("muzzle", 1.02, 1.35, (0, -10.3, 5.35), rot=(math.radians(90), 0, 0), verts=16)
    finish(brake, metal, D_M, bevel=0.1)
    for i in range(2):
        slot = box("brake_slot_%d" % i, (1.5, 0.34, 0.26), (0, -9.95 - i * 0.75, 5.35))
        finish(slot, cream, D_P)
    band = cyl("muzzle_band", 0.82, 0.5, (0, -8.9, 5.35), rot=(math.radians(90), 0, 0), verts=16)
    finish(band, cream, D_P, bevel=0.05)
    coax = cyl("coax", 0.16, 1.8, (1.0, -3.9, 5.15), rot=(math.radians(90), 0, 0), verts=8)
    finish(coax, metal, D_M)
    # smoke grenade launchers on the turret cheeks
    for side in (-1, 1):
        for i in range(2):
            s = cyl("smoke_%d_%d" % (side, i), 0.20, 0.75, (side * 2.4, -0.6 + i * 0.55, 6.05),
                    rot=(math.radians(55), 0, 0), verts=8)
            finish(s, metal, D_M)
    # antenna
    ant = cyl("antenna", 0.07, 4.2, (-2.9, 4.2, 8.0), verts=6)
    finish(ant, metal, D_M)
    # rivets around the turret
    for i in range(10):
        a = math.pi * 2 * i / 10
        rv = sphere("rivet_%d" % i, 0.16, (math.cos(a) * 3.35, math.sin(a) * 3.35 + 0.9, 5.05), 8, 6)
        finish(rv, metal, D_M)

    camera_and_lights()
    print("player_tank triangles", tri_count())
    save_blend("player_tank", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# raider light tank (palette materials)

def build_enemy_light():
    sc = begin_model("enemy_light")
    pal1 = make_mat("pal1", rgba_image("pal1_detail", detail_texture(5)), 0.62, 0.0)
    pal2 = make_mat("pal2", rgba_image("pal2_detail", detail_texture(6)), 0.55, 0.05)
    pal3 = make_mat("pal3", rgba_image("pal3_detail", detail_texture(7)), 0.45, 0.15)
    track = make_mat("track", rgba_image("track", track_texture()), 0.85, 0.15)
    metal = make_mat("metal", rgba_image("metal", metal_texture(0.28, 9)), 0.38, 0.7)
    shadow = solid_mat("shadow", (0.05, 0.05, 0.05), 0.95, 0.0)

    sh = box("raider_shadow", (11.6, 15.6, 0.14), (0, 0, 0.07))
    finish(sh, shadow, 0.5, smooth=False)

    # four big road wheels, exposed, with angular fenders
    for side in (-1, 1):
        x = side * 5.1
        for i in range(2):
            band = box("track_%d_%d" % (side, i), (2.4, 6.2, 2.4), (x, -4.2 + i * 7.4, 1.2))
            finish(band, track, 0.45, bevel=0.7, segments=4, smooth=True)
        for i in range(4):
            w = cyl("wheel_%d_%d" % (side, i), 1.0, 0.5, (x + side * 1.25, -5.1 + i * 3.4, 1.05),
                    rot=(0, math.pi / 2, 0), verts=16)
            finish(w, metal, 0.34, bevel=0.1)
    # low wedge hull
    hull = box("raider_hull", (9.0, 13.6, 2.0), (0, 0, 2.6))
    slope_front(hull, 3.0, 2.4)
    taper(hull, 3.6, 0.92, 0.96)
    finish(hull, pal2, 0.28, bevel=0.24, segments=3, smooth=True)
    glacis = box("raider_glacis", (8.2, 2.0, 1.2), (0, -6.2, 3.15), rot=(math.radians(-38), 0, 0))
    finish(glacis, pal2, 0.3, bevel=0.15)
    # slat armour panels on the sides
    for side in (-1, 1):
        for i in range(4):
            slat = box("slat_%d_%d" % (side, i), (0.18, 1.5, 1.2), (side * 4.7, -4.2 + i * 2.9, 2.5))
            finish(slat, pal1, 0.5, bevel=0.05)
        ex = cyl("exhaust_%d" % side, 0.35, 1.4, (side * 3.6, 6.9, 3.3), rot=(math.radians(90), 0, 0), verts=10)
        finish(ex, metal, 0.4, bevel=0.05)
    # offset angular turret
    tur = cyl("raider_turret", 3.0, 1.7, (-0.6, 0.7, 4.35), verts=6)
    taper(tur, 4.7, 0.7, 0.75)
    finish(tur, pal3, 0.4, bevel=0.3, segments=2, smooth=True)
    for v in tur.data.vertices:
        if v.co.y > 1.0:
            v.co.y *= 1.2
    hatch = cyl("raider_hatch", 0.7, 0.3, (-0.9, 1.3, 5.5), verts=14)
    finish(hatch, pal1, 0.55, bevel=0.06)
    # stubby gun with a thermal sleeve
    slee = cyl("raider_sleeve", 0.78, 3.4, (-0.6, -3.2, 4.2), rot=(math.radians(90), 0, 0), verts=14)
    finish(slee, pal1, 0.55, bevel=0.08)
    barrel = cyl("raider_barrel", 0.56, 4.6, (-0.6, -6.4, 4.2), rot=(math.radians(90), 0, 0), verts=12)
    finish(barrel, metal, 0.4, bevel=0.04)
    brake = cyl("raider_muzzle", 0.85, 0.9, (-0.6, -8.4, 4.2), rot=(math.radians(90), 0, 0), verts=12)
    finish(brake, metal, 0.4, bevel=0.06)
    # missile pod on the right cheek (original detail)
    pod = box("raider_pod", (1.6, 1.8, 1.2), (2.0, 0.4, 5.1), rot=(0, 0, math.radians(-12)))
    finish(pod, pal1, 0.5, bevel=0.18)
    for i in range(2):
        for j in range(2):
            hole = cyl("pod_tube_%d_%d" % (i, j), 0.24, 0.2, (2.0 + (i - 0.5) * 0.55, -0.5, 4.9 + j * 0.55),
                       rot=(math.radians(90), 0, 0), verts=10)
            finish(hole, metal, 0.6)
    # front lights and a dozer blade
    for side in (-1, 1):
        lamp = box("raider_lamp_%d" % side, (0.5, 0.2, 0.35), (side * 3.1, -7.0, 3.0))
        finish(lamp, pal1, 0.6)
    blade = box("raider_blade", (8.6, 0.8, 1.5), (0, -7.5, 1.1))
    slope_front(blade, 0, 0.0)
    finish(blade, metal, 0.4, bevel=0.2)
    # antenna
    ant = cyl("raider_antenna", 0.06, 3.4, (-2.6, 3.6, 6.2), verts=6)
    finish(ant, metal, 0.5)
    camera_and_lights()
    print("enemy_tank triangles", tri_count())
    save_blend("enemy_tank", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# heavy assault tank (palette materials)

def build_enemy_heavy():
    sc = begin_model("enemy_heavy")
    pal1 = make_mat("pal1", rgba_image("pal1_detail", detail_texture(15)), 0.66, 0.0)
    pal2 = make_mat("pal2", rgba_image("pal2_detail", detail_texture(16)), 0.58, 0.05)
    pal3 = make_mat("pal3", rgba_image("pal3_detail", detail_texture(17)), 0.48, 0.15)
    track = make_mat("track", rgba_image("track", track_texture()), 0.86, 0.18)
    metal = make_mat("metal", rgba_image("metal", metal_texture(0.26, 19)), 0.4, 0.7)
    shadow = solid_mat("shadow", (0.05, 0.05, 0.05), 0.95, 0.0)

    sh = box("heavy_shadow", (14.6, 17.0, 0.16), (0, 0, 0.08))
    finish(sh, shadow, 0.5, smooth=False)

    for side in (-1, 1):
        x = side * 6.4
        band = box("heavy_track_%d" % side, (3.2, 15.8, 3.2), (x, 0, 1.6))
        finish(band, track, 0.42, bevel=0.85, segments=5, smooth=True)
        for i in range(4):
            w = cyl("heavy_wheel_%d_%d" % (side, i), 1.15, 0.6, (x + side * 1.5, -5.4 + i * 3.6, 1.25),
                    rot=(0, math.pi / 2, 0), verts=18)
            finish(w, metal, 0.34, bevel=0.12)
        # spaced armour plates
        for i in range(3):
            plate = box("armour_%d_%d" % (side, i), (0.35, 3.4, 2.2), (x + side * 1.9, -4.4 + i * 4.4, 3.0),
                        rot=(0, math.radians(side * 6), 0))
            finish(plate, pal2, 0.4, bevel=0.12)
    hull = box("heavy_hull", (11.6, 14.8, 2.8), (0, 0, 3.3))
    slope_front(hull, 3.7, 1.4)
    taper(hull, 4.5, 0.96, 0.98)
    finish(hull, pal2, 0.26, bevel=0.3, segments=3, smooth=True)
    glacis = box("heavy_glacis", (11.0, 2.0, 1.6), (0, -6.5, 4.0), rot=(math.radians(-30), 0, 0))
    finish(glacis, pal1, 0.3, bevel=0.18)
    # twin exhaust stacks at the rear
    for side in (-1, 1):
        st = cyl("stack_%d" % side, 0.55, 2.2, (side * 2.6, 7.0, 5.3), verts=12)
        finish(st, metal, 0.4, bevel=0.08)
        cap = cyl("stack_cap_%d" % side, 0.7, 0.3, (side * 2.6, 7.0, 6.45), verts=12)
        finish(cap, pal1, 0.5, bevel=0.05)
    # big hexagonal turret with a heavy gun and a rocket pod
    tur = box("heavy_turret", (6.2, 5.8, 2.8), (0, 0.6, 5.65))
    for v in tur.data.vertices:      # sloped turret face
        if v.co.z > 6.2 and v.co.y < 0:
            v.co.y += 1.1
        if v.co.z > 6.2:
            v.co.x *= 0.92
    finish(tur, pal3, 0.36, bevel=0.32, segments=3, smooth=True)
    bust = box("heavy_bustle", (5.2, 2.8, 1.4), (0, 4.4, 5.9))
    finish(bust, pal1, 0.4, bevel=0.25, segments=2)
    for v in tur.data.vertices:
        if v.co.y > 1.5:
            v.co.y *= 1.3
    cup = cyl("heavy_cupola", 1.1, 0.7, (-1.5, 2.4, 6.9), verts=16)
    finish(cup, pal1, 0.5, bevel=0.12)
    mant = box("heavy_mantlet", (3.0, 1.2, 1.8), (0, -3.2, 5.4))
    finish(mant, pal1, 0.35, bevel=0.3, segments=3)
    barrel = cyl("heavy_barrel", 0.95, 6.0, (0, -6.2, 5.4), rot=(math.radians(90), 0, 0), verts=16)
    finish(barrel, metal, 0.34, bevel=0.06)
    brake = cyl("heavy_muzzle", 1.28, 1.5, (0, -9.1, 5.4), rot=(math.radians(90), 0, 0), verts=14)
    finish(brake, metal, 0.34, bevel=0.1)
    # rocket pod on the turret side
    pod = box("heavy_pod", (2.2, 2.6, 1.8), (2.6, 1.6, 6.4), rot=(math.radians(-8), 0, 0))
    finish(pod, pal1, 0.4, bevel=0.22)
    for i in range(2):
        for j in range(2):
            hole = cyl("heavy_tube_%d_%d" % (i, j), 0.3, 0.24, (2.6 + (i - 0.5) * 0.8, 0.2, 6.2 + j * 0.8),
                       rot=(math.radians(90), 0, 0), verts=10)
            finish(hole, metal, 0.5)
    # unditching beam on the rear deck
    beam = box("heavy_beam", (8.0, 0.7, 0.7), (0, 6.4, 4.9))
    finish(beam, metal, 0.4, bevel=0.15)
    for i in range(4):
        r = sphere("heavy_rivet_%d" % i, 0.18, (-3.6 + i * 2.4, 6.4, 5.3), 8, 6)
        finish(r, pal1, 0.5)
    camera_and_lights()
    print("enemy_heavy triangles", tri_count())
    save_blend("enemy_heavy", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# shell

def build_shell():
    sc = begin_model("shell")
    brass = solid_mat("brass", (0.72, 0.52, 0.18), 0.35, 0.65)
    tip = solid_mat("tip", (0.95, 0.82, 0.45), 0.25, 0.4)
    soot = solid_mat("soot", (0.20, 0.18, 0.16), 0.9, 0.0)
    body = cyl("shell_body", 0.9, 3.2, (0, 0, 0.9), verts=14)
    finish(body, brass, 0.6, bevel=0.08, smooth=True)
    nose = cyl("shell_nose", 0.9, 1.4, (0, 0, 2.9), verts=14, r2=0.35)
    finish(nose, tip, 0.6, bevel=0.05, smooth=True)
    rim = cyl("shell_rim", 1.05, 0.35, (0, 0, 2.15), verts=14)
    finish(rim, brass, 0.6, bevel=0.05)
    base = cyl("shell_base", 0.8, 0.3, (0, 0, -0.15), verts=14)
    finish(base, soot, 0.8, bevel=0.04)
    camera_and_lights()
    print("shell triangles", tri_count())
    save_blend("shell", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# eagle monument (the base the player defends)

def stone_texture():
    rng = np.random.default_rng(31)
    y, x = np.mgrid[0:N, 0:N]
    img = np.full((N, N, 3), 0.52, dtype=np.float32)
    img *= (0.82 + 0.30 * _noise(rng, 3)[..., None])
    # mortar joints
    for c in (x, y):
        mm = c % 64
        img[mm < 2] *= 0.55
    # cracks
    for _ in range(12):
        x0, y0 = rng.integers(0, N, 2)
        for t in range(rng.integers(20, 80)):
            px = int(x0 + t * 0.7) % N
            py = int(y0 + t * 0.3 + math.sin(t * 0.3) * 3) % N
            img[py, px] *= 0.45
    return np.clip(img, 0, 1)


def bronze_texture():
    rng = np.random.default_rng(37)
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = (0.36, 0.24, 0.10)
    patina = np.clip(_noise(rng, 6) - 0.45, 0, 1)[..., None] * 2.2
    img = img * (1 - patina * 0.85) + np.array([0.20, 0.42, 0.34])[None, None, :] * (patina * 0.85)
    img *= (0.85 + 0.25 * _noise(rng, 1)[..., None])
    return np.clip(img, 0, 1)


def build_eagle():
    sc = begin_model("eagle")
    stone = make_mat("stone", rgba_image("stone", stone_texture()), 0.85, 0.0)
    bronze = make_mat("bronze", rgba_image("bronze", bronze_texture()), 0.4, 0.7)
    shadow = solid_mat("shadow", (0.04, 0.04, 0.04), 0.95, 0.0)

    sh = box("eagle_shadow", (15.0, 15.0, 0.12), (0, 0, 0.06))
    finish(sh, shadow, 0.5)
    base1 = box("plinth_low", (14.0, 14.0, 1.1), (0, 0, 0.55))
    finish(base1, stone, 0.22, bevel=0.22, segments=2, smooth=True)
    base2 = box("plinth_high", (11.6, 11.6, 1.0), (0, 0, 1.6))
    finish(base2, stone, 0.24, bevel=0.20, segments=2, smooth=True)
    rock = box("rock", (7.6, 6.8, 2.0), (0, 0.6, 3.0))
    for v in rock.data.vertices:
        v.co.x += 0.35 * math.sin(v.co.z * 2.1) * (1 if v.co.x > 0 else -1)
    finish(rock, stone, 0.3, bevel=0.55, segments=3, smooth=True)

    body = sphere("eagle_body", 1.55, (0, 0.4, 4.9), 18, 12)
    body.scale = (0.85, 1.25, 1.0)
    bpy.ops.object.transform_apply(scale=True)
    finish(body, bronze, 0.55, smooth=True)
    head = sphere("eagle_head", 0.75, (0, -1.25, 6.15), 14, 10)
    finish(head, bronze, 0.6, smooth=True)
    beak = cyl("eagle_beak", 0.34, 0.9, (0, -2.05, 6.05), rot=(math.radians(90), 0, 0), verts=8, r2=0.06)
    finish(beak, bronze, 0.7, smooth=True)
    tail = box("eagle_tail", (1.7, 1.9, 0.35), (0, 2.0, 4.7), rot=(math.radians(18), 0, 0))
    finish(tail, bronze, 0.5, bevel=0.12)
    for side in (-1, 1):
        # leading-edge arm of the wing
        arm = box("eagle_arm_%d" % side, (4.2, 0.75, 0.55), (side * 2.7, 0.1, 5.5),
                  rot=(0, math.radians(side * 12), math.radians(side * -8)))
        for v in arm.data.vertices:
            if v.co.x * side > 0:
                v.co.y *= 0.55
        finish(arm, bronze, 0.5, bevel=0.12, smooth=True)
        # five fanned primary feathers
        for i in range(5):
            ln = 4.6 - i * 0.42
            f = box("eagle_feather_%d_%d" % (side, i), (ln, 0.72 - i * 0.05, 0.20),
                    (side * (1.1 + ln / 2 - i * 0.25), 0.45 + i * 0.42, 5.32 + i * 0.06),
                    rot=(0, math.radians(side * (10 + i * 3)), math.radians(side * (-14 - i * 4))))
            finish(f, bronze, 0.6, bevel=0.05)
    for i in range(3):
        t = box("eagle_tailfeather_%d" % i, (0.75, 2.2 - i * 0.25, 0.22),
                (0, 2.2 + i * 0.18, 4.45 + i * 0.05), rot=(math.radians(20), 0, math.radians(-8 + i * 8)))
        finish(t, bronze, 0.6, bevel=0.06)
    for side in (-1, 1):
        eye = sphere("eagle_eye_%d" % side, 0.11, (side * 0.32, -1.72, 6.35), 8, 6)
        finish(eye, bronze, 0.6)
    plaque = box("plaque", (3.6, 0.3, 1.0), (0, -7.05, 0.9))
    finish(plaque, bronze, 0.6, bevel=0.06)
    camera_and_lights()
    print("eagle_base triangles", tri_count())
    save_blend("eagle_base", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# explosion burst

def fire_texture():
    rng = np.random.default_rng(41)
    y, x = np.mgrid[0:N, 0:N]
    r = np.sqrt((x - N / 2) ** 2 + (y - N / 2) ** 2) / (N / 2)
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[..., 0] = np.clip(1.25 - r * 0.65, 0, 1)
    img[..., 1] = np.clip(1.05 - r * 0.95, 0, 1) ** 1.15
    img[..., 2] = np.clip(0.55 - r * 1.1, 0, 1) ** 2
    img = img * (1.0 - 0.35 * _noise(rng, 3)[..., None])
    img[r > 1.0] = 0.05
    return np.clip(img, 0, 1)


def build_explosion():
    sc = begin_model("explosion")
    fire = make_mat("fire", rgba_image("fire", fire_texture()), 0.22, 0.0)
    hot = solid_mat("hot", (1.0, 0.92, 0.55), 0.2, 0.0)
    smoke = solid_mat("smoke", (0.12, 0.10, 0.09), 0.9, 0.0)
    core = sphere("blast_core", 2.9, (0, 0, 3.6), 16, 10)
    finish(core, fire, 0.55, smooth=True)
    inner = sphere("blast_inner", 1.8, (0, 0, 3.8), 14, 9)
    finish(inner, hot, 0.55, smooth=True)
    from mathutils import Vector
    for i in range(8):
        a = math.pi * 2 * i / 8
        tilt = math.radians(48 if i % 2 else 22)
        ln = 4.6 if i % 2 else 3.4
        d = Vector((math.cos(a) * math.cos(tilt), math.sin(a) * math.cos(tilt), math.sin(tilt)))
        sp = cyl("blast_spike_%d" % i, 0.9, ln, (d.x * 3.7, d.y * 3.7, 3.6 + d.z * 3.7), verts=8, r2=0.04)
        sp.rotation_euler = Vector((0, 0, 1)).rotation_difference(d).to_euler()
        bpy.context.view_layer.objects.active = sp
        bpy.ops.object.transform_apply(rotation=True)
        finish(sp, fire, 0.6, smooth=True)
    for i in range(4):
        a = math.pi * 2 * i / 4 + 0.4
        p = sphere("smoke_%d" % i, 1.1, (math.cos(a) * 4.2, math.sin(a) * 4.2, 0.9), 10, 7)
        finish(p, smoke, 0.6, smooth=True)
    camera_and_lights()
    print("explosion triangles", tri_count())
    save_blend("explosion", sc)
    close_model(sc)


def reset_file():
    """Start from one empty scene: no leftover objects, scenes or libraries."""
    active = bpy.context.scene.name
    for sc in list(bpy.data.scenes):
        for o in list(sc.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        if sc.name != active:
            bpy.data.scenes.remove(sc)
    for lib in list(bpy.data.libraries):
        bpy.data.libraries.remove(lib)
    for ng in list(bpy.data.node_groups):
        if ng.library:
            bpy.data.node_groups.remove(ng)


if __name__ == "__main__":
    reset_file()
    build_player()
    build_enemy_light()
    build_enemy_heavy()
    build_shell()
    build_eagle()
    build_explosion()
    print("all models built")
