"""Contra diorama pack: enemies and props (drawn in Blender through Blender MCP).

Models: pod (flying weapon capsule), rock_ledge (floating rock platform), flame,
gunner (mortar trooper), cart (mine cart), saucer, scorpion, boulder, arm_ball and
arm_claw (the waterfall boss's spiked arm).  Designs are original and fill each
sprite's role (tools/luxo3d/MODELS.md).

Live, through Blender MCP (builds into its own scene "contra_enemies", leaves
every other scene alone, lays the models out in a row for `look`):

    exec(compile(open(PATH).read(), PATH, "exec"), {"__file__": PATH, "LIVE": True})

Headless, to rebuild and export the GLBs into the pack's models/:

    blender -b --python docs/3d-view/sources/contra/contra_enemies.py [-- name ...]

Models with a facing (gunner, scorpion) face -Y; the others are seen from the
front (X-Z), because their groups have no facing.
"""

import math
import os
import subprocess
import sys

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Quaternion, Vector

HERE = os.path.dirname(os.path.abspath(globals().get("__file__", "contra_enemies.py")))
LIVE = bool(globals().get("LIVE"))
L = {"CONTRA_LIB_ONLY": True, "__file__": os.path.join(HERE, "contra_models.py")}
exec(compile(open(L["__file__"]).read(), L["__file__"], "exec"), L)
E_, B_, C_ = L["ellipsoid"], L["rbox"], L["cyl"]
pivot, make_clips, turn, shift, rot, RX, held = (L[k] for k in ("pivot", "make_clips", "turn", "shift", "rot", "RX", "held"))
finish = L["finish"]
RY = lambda d: rot((0, 1, 0), d)
RZ = lambda d: rot((0, 0, 1), d)
BLEND = os.path.join(HERE, "blend", "contra_enemies.blend")
rng = np.random.default_rng(7)

L["ATLAS"] = [
    ("red", (0.86, 0.13, 0.08), L["pat_smooth"]),
    ("white", (0.96, 0.95, 0.92), L["pat_smooth"]),
    ("steel", (0.62, 0.64, 0.68), L["pat_metal"]),
    ("dark", (0.13, 0.13, 0.16), L["pat_grain"]),
    ("rock", (0.62, 0.62, 0.62), L["pat_grain"]),
    ("rock_dark", (0.36, 0.36, 0.38), L["pat_grain"]),
    ("flame_o", (1.00, 0.42, 0.05), L["pat_smooth"]),
    ("flame_y", (1.00, 0.84, 0.22), L["pat_smooth"]),
    ("blue", (0.13, 0.22, 0.88), L["pat_weave"]),
    ("brass", (0.95, 0.72, 0.22), L["pat_metal"]),
    ("skin", (0.98, 0.70, 0.55), L["pat_skin"]),
    ("cart", (0.86, 0.26, 0.10), L["pat_metal"]),
    ("cart_dark", (0.56, 0.12, 0.05), L["pat_metal"]),
    ("magenta", (0.86, 0.20, 0.78), L["pat_grain"]),
    ("magenta_dark", (0.48, 0.08, 0.50), L["pat_grain"]),
    ("moss", (0.26, 0.56, 0.20), L["pat_grain"]),
]
L["N"] = 4


def cone(name, c, p0, p1, r0, r1, cell, segs=8):
    return C_(name, c, p0, p1, r0, r1, cell, segs)


def lump(name, c, centre, r, cell, rough=0.18, sub=2, seed=1):
    """A rock: an icosphere pushed in and out by a fixed random amount."""
    g = np.random.default_rng(seed)
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=sub, radius=1.0)
    for v in bm.verts:
        k = 1.0 + rough * (g.random() * 2 - 1)
        v.co = Vector((v.co.x * r[0] * k, v.co.y * r[1] * k, v.co.z * r[2] * k))
    bmesh.ops.translate(bm, verts=bm.verts, vec=Vector(centre))
    return finish(bm, name, c, cell, 20)


def taper_box(name, c, centre, size, cell, top=1.0, bottom=0.78, bevel=0.6):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        k = top if v.co.z > 0 else bottom
        v.co = Vector((v.co.x * size[0] * k, v.co.y * size[1] * (0.9 if v.co.z < 0 else 1.0), v.co.z * size[2]))
    bmesh.ops.bevel(bm, geom=bm.edges[:], offset=bevel, offset_type="OFFSET", segments=2, profile=0.5,
                    affect="EDGES", clamp_overlap=True)
    bmesh.ops.translate(bm, verts=bm.verts, vec=Vector(centre))
    return finish(bm, name, c, cell, 40)


# ----------------------------------------------------------------------------


def build_pod(c):
    """Flying weapon capsule, 24 x 14: a red drum with a white band, steel end caps and a
    cross badge on the front."""
    z = 7.0
    body = E_("pod_body", c, (0, 0, z), (9.6, 5.6, 6.2), "red")
    E_("pod_band", c, (0, 0, z), (2.4, 5.95, 6.55), "white")
    for s in (-1, 1):
        C_("pod_cap%d" % s, c, (s * 8.6, 0, z), (s * 11.8, 0, z), 3.0, 1.9, "steel", 12)
        E_("pod_tip%d" % s, c, (s * 11.9, 0, z), (1.1, 1.9, 1.9), "dark", segs=(10, 6))
        C_("pod_rib%d" % s, c, (s * 5.2, 0, z - 0.01), (s * 6.0, 0, z), 6.0, 5.6, "cart_dark", 16)
    C_("pod_badge", c, (0, -5.3, z), (0, -6.3, z), 3.3, 3.3, "white", 16)
    B_("pod_cross_h", c, (0, -6.45, z), (4.6, 0.5, 1.4), "red", 0.15)
    B_("pod_cross_v", c, (0, -6.45, z), (1.4, 0.5, 4.6), "red", 0.15)
    B_("pod_fin", c, (0, 0.5, z + 6.4), (5.0, 1.0, 1.6), "steel", 0.3)
    return body.name


def build_rock_ledge(c):
    """Floating rock platform, 32 x 28: a flat mossy slab over hanging stone teeth."""
    slab = E_("ledge_slab", c, (0, 0, 24.6), (15.6, 8.6, 3.0), "rock")
    C_("ledge_top", c, (0, 0, 25.6), (0, 0, 27.4), 14.6, 14.0, "rock", 14)
    for i, (x, y, r) in enumerate([(-9, 2, 2.2), (-3, -4, 1.8), (5, 3, 2.4), (10, -2, 1.7), (1, 5, 1.5)]):
        E_("ledge_moss%d" % i, c, (x, y, 27.5), (r, r * 0.8, 0.5), "moss", segs=(10, 6))
    teeth = [(0, 0, 9.0, 1.5), (-8.5, 1, 6.0, 9.5), (8.5, -1, 6.4, 8.0), (-3.5, 4, 5.0, 6.5), (4.0, -4, 5.2, 5.0),
             (-12, -1, 3.6, 15.0), (12.2, 1, 3.4, 14.0)]
    for i, (x, y, r, z0) in enumerate(teeth):
        cone("ledge_tooth%d" % i, c, (x, y, 24.0), (x * 0.9, y, z0), r, r * 0.16, "rock_dark" if i % 2 else "rock", 7)
        lump("ledge_knob%d" % i, c, (x, y, 22.0), (r * 0.95, r * 0.9, 2.6), "rock", 0.2, 1, 10 + i)
    return slab.name


def build_flame(c):
    """A fire, 16 x 16: three tongues that flicker."""
    piv = []
    tongues = [(0, 0, 5.4, 15.5, "flame_o"), (-4.6, 0.6, 3.4, 10.5, "flame_o"), (4.6, -0.6, 3.6, 11.5, "flame_o"),
               (0, -1.6, 3.4, 10.0, "flame_y"), (-2.6, -2.0, 2.0, 6.5, "flame_y"), (2.8, -2.2, 2.1, 7.2, "flame_y")]
    base = None
    for i, (x, y, r, h, cell) in enumerate(tongues):
        a = E_("flame_bulb%d" % i, c, (x, y, r * 0.95), (r, r * 0.8, r), cell, segs=(12, 8))
        b = cone("flame_tip%d" % i, c, (x, y, r * 1.35), (x * 1.15, y, h), r * 0.82, 0.15, cell, 10)
        piv.append(pivot("flame_p%d" % i, c, (x, y, 0), [a, b]))
        base = base or a

    def burn(ph):
        for i, p in enumerate(piv):
            k = 1.0 + 0.22 * math.sin(ph * math.pi / 2 + i * 2.1)
            p.scale = (1.0 / math.sqrt(k), 1.0, k)
            turn(p, RY(7 * math.sin(ph * math.pi / 2 + i * 1.3)))

    make_clips(piv, [("burn", [(i * 3, (lambda q: (lambda: burn(q)))(i)) for i in range(5)])])
    return base.name


def build_gunner(c):
    """Mortar trooper, 32 x 30, faces -Y: a field gun on a pedestal with a splinter shield,
    and a crouched trooper (red jacket, blue trousers) behind it."""
    post = C_("gun_post", c, (0, -4.5, 0.8), (0, -5.5, 19.5), 3.4, 2.5, "steel", 12)
    B_("gun_foot", c, (0, -4.5, 0.9), (10.5, 12.0, 1.8), "dark", 0.5)
    for s in (-1, 1):
        C_("gun_strut%d" % s, c, (s * 4.4, -9.5, 1.5), (s * 1.6, -6.0, 13.0), 0.8, 0.7, "dark", 8)
    C_("gun_tube", c, (0, 5.0, 23.0), (0, -17.0, 23.0), 2.9, 2.5, "steel", 14)
    C_("gun_muzzle", c, (0, -16.0, 23.0), (0, -18.2, 23.0), 3.3, 3.3, "dark", 14)
    C_("gun_breech", c, (0, 3.6, 23.0), (0, 6.6, 23.0), 3.3, 2.6, "dark", 14)
    B_("gun_cradle", c, (0, -5.4, 20.4), (5.2, 7.0, 2.6), "dark", 0.6)
    B_("gun_shield", c, (0, -10.4, 21.0), (11.0, 1.2, 10.0), "steel", 0.5, RX(-10))
    B_("gun_slit", c, (0, -11.1, 23.6), (5.0, 0.6, 1.4), "dark", 0.2, RX(-10))
    # the trooper
    E_("gnr_torso", c, (0, 6.4, 14.6), (4.6, 3.6, 5.6), "red", rot=RX(-18))
    E_("gnr_head", c, (0, 4.8, 22.6), (3.3, 3.4, 3.3), "skin")
    E_("gnr_helmet", c, (0, 5.1, 23.9), (3.9, 4.1, 2.9), "red")
    C_("gnr_brim", c, (0, 5.0, 23.0), (0, 5.0, 23.6), 4.5, 4.2, "red", 14)
    for s in (-1, 1):
        C_("gnr_arm%d" % s, c, (s * 4.4, 5.6, 18.6), (s * 2.6, 0.4, 21.6), 1.6, 1.4, "red", 8)
        E_("gnr_hand%d" % s, c, (s * 2.6, 0.2, 21.8), (1.3, 1.3, 1.3), "skin", segs=(8, 6))
        C_("gnr_thigh%d" % s, c, (s * 2.4, 7.0, 10.2), (s * 2.6, 1.6, 7.4), 2.2, 1.9, "blue", 10)
        C_("gnr_shin%d" % s, c, (s * 2.6, 1.6, 7.4), (s * 2.6, 5.4, 2.2), 1.8, 1.6, "blue", 10)
        B_("gnr_boot%d" % s, c, (s * 2.6, 4.2, 1.4), (3.2, 5.6, 2.8), "dark", 0.8)
    return post.name


def build_cart(c):
    """Mine cart, 32 x 22, seen from the side (its length along X): a tapered hopper with a
    rim and ribs on four spoked wheels that roll."""
    hop = taper_box("cart_hopper", c, (0, 0, 13.6), (30.0, 13.0, 12.4), "cart")
    B_("cart_rim", c, (0, 0, 20.2), (31.6, 14.6, 1.7), "cart_dark", 0.5)
    B_("cart_load", c, (0, 0, 19.2), (27.0, 11.0, 1.2), "dark", 0.3)
    for x in (-9.6, 0.0, 9.6):
        B_("cart_rib%d" % x, c, (x * 0.94, -6.25, 13.4), (1.5, 1.0, 11.2), "cart_dark", 0.3)
    B_("cart_band", c, (0, -6.3, 13.4), (25.0, 0.9, 1.5), "cart_dark", 0.3)
    B_("cart_frame", c, (0, 0, 6.4), (24.0, 9.0, 2.0), "dark", 0.5)
    piv = []
    for i, (x, y) in enumerate([(-8, -6.4), (8, -6.4), (-8, 6.4), (8, 6.4)]):
        w = [C_("cart_wheel%d" % i, c, (x, y - 0.9, 4.0), (x, y + 0.9, 4.0), 4.0, 4.0, "blue", 16),
             C_("cart_hub%d" % i, c, (x, y - 1.3, 4.0), (x, y + 1.3, 4.0), 1.4, 1.4, "brass", 10)]
        for k in range(3):
            w.append(B_("cart_spoke%d_%d" % (i, k), c, (x, y - (1.0 if y < 0 else -1.0), 4.0), (6.6, 0.5, 0.9), "white", 0.1,
                        RY(60 * k)))
        piv.append(pivot("cart_pw%d" % i, c, (x, y, 4.0), w))

    def roll(a):
        for p in piv:
            turn(p, RY(a))

    make_clips(piv, [("roll", [(i * 6, (lambda q: (lambda: roll(q)))(a)) for i, a in enumerate([0, 90, 180, 270, 360])])])
    return hop.name


def build_saucer(c):
    """Flying saucer, 24 x 14: a steel disc with a dome and a ring of red lamps that turns."""
    hull = E_("ufo_hull", c, (0, 0, 6.0), (12.0, 12.0, 2.8), "steel", segs=(24, 10))
    C_("ufo_skirt", c, (0, 0, 2.2), (0, 0, 4.6), 6.0, 9.6, "dark", 20)
    C_("ufo_foot", c, (0, 0, 0.9), (0, 0, 2.4), 3.4, 5.0, "steel", 14)
    E_("ufo_dome", c, (0, 0, 8.2), (6.0, 6.0, 4.8), "white", segs=(18, 10))
    C_("ufo_collar", c, (0, 0, 7.6), (0, 0, 8.6), 6.9, 6.3, "dark", 20)
    E_("ufo_cap", c, (0, 0, 12.6), (1.6, 1.6, 0.9), "red", segs=(10, 6))
    lamps = []
    for i in range(8):
        a = 2 * math.pi * i / 8
        lamps.append(E_("ufo_lamp%d" % i, c, (10.4 * math.cos(a), 10.4 * math.sin(a), 6.3), (1.5, 1.5, 1.5),
                        "red" if i % 2 == 0 else "brass", segs=(8, 6)))
    ring = pivot("ufo_ring", c, (0, 0, 6.3), lamps)
    make_clips([ring], [("spin", [(i * 4, (lambda q: (lambda: turn(ring, RZ(q))))(a)) for i, a in enumerate([0, 30, 60, 90])])])
    return hull.name


def build_scorpion(c):
    """Alien scorpion, 32 x 32, faces -Y: a plated body on six legs, two claws, and a tail
    that curls over its back to a stinger.  Legs step in two sets."""
    body = E_("scp_body", c, (0, 1.0, 7.4), (4.6, 7.6, 3.6), "magenta")
    for i in range(3):
        E_("scp_plate%d" % i, c, (0, -2.0 + i * 3.4, 9.6 - i * 0.3), (3.9, 2.2, 1.6), "magenta_dark", segs=(12, 6))
    E_("scp_head", c, (0, -7.6, 6.8), (3.3, 3.0, 2.7), "magenta")
    for s in (-1, 1):
        E_("scp_eye%d" % s, c, (s * 1.5, -10.0, 7.6), (0.8, 0.6, 0.8), "white", segs=(8, 6))
        C_("scp_claw_arm%d" % s, c, (s * 2.6, -8.6, 6.0), (s * 6.4, -13.2, 7.0), 1.0, 0.9, "magenta_dark", 8)
        E_("scp_claw%d" % s, c, (s * 6.6, -14.6, 7.2), (1.8, 2.8, 1.5), "magenta")
        cone("scp_pincer%d" % s, c, (s * 6.0, -16.0, 7.2), (s * 4.8, -18.6, 7.4), 0.9, 0.15, "white", 6)
    # tail: beads on an arc from the rump up and forward over the back, the sting hanging
    # over the head
    tail = []
    cy, cz, R = 2.0, 15.0, 8.2
    for i in range(7):
        t = i / 6
        a = math.radians(-42 + 192 * t)
        r = 2.7 - 1.1 * t
        tail.append(E_("scp_tail%d" % i, c, (0, cy + R * math.cos(a), cz + R * math.sin(a)), (r, r, r),
                       "magenta" if i % 2 == 0 else "magenta_dark", segs=(10, 6)))
    a = math.radians(150)
    tip = Vector((0, cy + R * math.cos(a), cz + R * math.sin(a)))
    tail.append(cone("scp_sting", c, tip + Vector((0, -0.4, -0.8)), tip + Vector((0, -3.4, -6.2)), 1.3, 0.1, "white", 8))
    p_tail = pivot("scp_p_tail", c, (0, 8.0, 8.0), tail)
    sets = [[], []]
    for s in (-1, 1):
        for i, y in enumerate((-4.0, 1.0, 6.0)):
            leg = [C_("scp_leg_a%d_%d" % (s, i), c, (s * 3.6, y, 7.0), (s * 9.4, y + (i - 1) * 2.0, 10.6), 0.9, 0.75, "magenta_dark", 6),
                   C_("scp_leg_b%d_%d" % (s, i), c, (s * 9.4, y + (i - 1) * 2.0, 10.6), (s * 12.4, y + (i - 1) * 3.2, 0.3), 0.75, 0.3, "magenta", 6),
                   E_("scp_knee%d_%d" % (s, i), c, (s * 9.4, y + (i - 1) * 2.0, 10.6), (1.0, 1.0, 1.0), "magenta", segs=(8, 6))]
            sets[(i + (s > 0)) % 2].append(pivot("scp_p_leg%d_%d" % (s, i), c, (s * 3.6, y, 7.0), leg))
    piv = [p_tail] + sets[0] + sets[1]

    def walk(ph):
        for p in sets[0]:
            turn(p, RZ(14 * ph))
        for p in sets[1]:
            turn(p, RZ(-14 * ph))
        turn(p_tail, RX(6 * ph))

    make_clips(piv, [("walk", [(i * 6, (lambda q: (lambda: walk(q)))(q)) for i, q in enumerate([0, 1, 0, -1, 0])])])
    return body.name


def build_boulder(c):
    """A falling boulder, 24 x 30: a craggy two-lobed rock that tumbles."""
    a = lump("bld_main", c, (0, 0, 14.0), (10.6, 9.6, 12.6), "rock", 0.16, 2, 3)
    b = lump("bld_lobe", c, (4.6, -2.0, 21.0), (6.6, 6.0, 6.4), "rock", 0.2, 2, 4)
    d = lump("bld_lobe2", c, (-4.8, 1.6, 7.6), (6.4, 6.0, 6.0), "rock_dark", 0.2, 2, 5)
    e = lump("bld_chip", c, (-5.6, -5.4, 18.4), (3.4, 3.0, 3.2), "rock_dark", 0.25, 1, 6)
    p = pivot("bld_p", c, (0, 0, 14.0), [a, b, d, e])
    make_clips([p], [("tumble", [(i * 8, (lambda q: (lambda: turn(p, RY(q))))(q)) for i, q in enumerate([0, 90, 180, 270, 360])])])
    return a.name


def spiked_ball(c, pre, cell, spike_cell, r, spikes, spike_len):
    ball = E_(pre + "ball", c, (0, 0, 8.0), (r, r, r), cell, segs=(18, 12))
    parts = [ball]
    for i in range(spikes):
        a = 2 * math.pi * i / spikes
        d = Vector((math.cos(a), 0, math.sin(a)))
        parts.append(cone(pre + "spike%d" % i, c, Vector((0, 0, 8.0)) + d * (r * 0.8),
                          Vector((0, 0, 8.0)) + d * (r + spike_len), r * 0.34, 0.12, spike_cell, 8))
    for s in (-1, 1):
        parts.append(cone(pre + "boss%d" % s, c, (0, s * r * 0.8, 8.0), (0, s * (r + spike_len * 0.7), 8.0), r * 0.42, 0.2, spike_cell, 8))
    parts.append(C_(pre + "belt", c, (0, -0.9, 8.0), (0, 0.9, 8.0), r * 1.03, r * 1.03, "dark", 18))
    p = pivot(pre + "p", c, (0, 0, 8.0), parts)
    make_clips([p], [("spin", [(i * 6, (lambda q: (lambda: turn(p, RY(q))))(q)) for i, q in enumerate([0, 15, 30, 45])])])
    return ball.name


def build_arm_ball(c):
    """A link of the waterfall boss's arm, 16 x 16: a steel ball with a ring of studs."""
    return spiked_ball(c, "arm_", "steel", "dark", 5.4, 8, 1.9)


def build_arm_claw(c):
    """The end of the boss's arm, 16 x 16: a red ball with long white spikes."""
    return spiked_ball(c, "claw_", "red", "white", 4.6, 8, 3.2)


BUILDERS = [("pod", build_pod), ("rock_ledge", build_rock_ledge), ("flame", build_flame), ("gunner", build_gunner),
            ("cart", build_cart), ("saucer", build_saucer), ("scorpion", build_scorpion), ("boulder", build_boulder),
            ("arm_ball", build_arm_ball), ("arm_claw", build_arm_claw)]
PIVOTS = {}


def tris(coll):
    t = 0
    for o in coll.all_objects:
        if o.type == "MESH":
            o.data.calc_loop_triangles()
            t += len(o.data.loop_triangles)
    return t


def build(only=None):
    if LIVE:
        # a scene of our own; drop what an earlier run put there, touch nothing else
        sc = bpy.data.scenes.get("contra_enemies") or bpy.data.scenes.new("contra_enemies")
        for o in list(sc.collection.all_objects):
            bpy.data.objects.remove(o)
        for col in list(sc.collection.children):
            bpy.data.collections.remove(col)
        bpy.context.window.scene = sc
    else:
        L["clean"]()
        sc = bpy.context.scene
    sc.render.fps = 24
    L["CELLS"].clear()
    L["MAT"] = L["make_atlas"]()
    for i, (name, fn) in enumerate(BUILDERS):
        if only and name not in only:
            continue
        col = bpy.data.collections.new("m_" + name)
        sc.collection.children.link(col)
        PIVOTS["m_" + name] = fn(col)
        print("contra_enemies: %-10s %5d triangles" % (name, tris(col)))
        if LIVE:  # a row for `look`: hang each model from an empty at its place
            stand = bpy.data.objects.new("layout_" + name, None)
            col.objects.link(stand)
            stand.location = ((i % 5) * 44 - 88, (i // 5) * 70, 0)
            for o in col.objects:
                if o.parent is None and o is not stand:
                    o.parent = stand
    sc.frame_start, sc.frame_end = 0, 24
    sc.frame_set(0)


def export_all(only=None):
    blender = bpy.app.binary_path or "blender"
    os.makedirs(L["MODELS_DIR"], exist_ok=True)
    os.makedirs(os.path.dirname(BLEND), exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=BLEND, copy=True)
    for col in bpy.data.collections:
        if not col.name.startswith("m_") or (only and col.name[2:] not in only):
            continue
        name = col.name[2:]
        cmd = [blender, "-b", BLEND, "--python", L["EXPORTER"], "--", "--out", os.path.join(L["MODELS_DIR"], name + ".glb"),
               "--collection", col.name, "--pivot", PIVOTS[col.name]]
        if any(o.animation_data for o in col.all_objects):
            cmd.append("--animations")
        r = subprocess.run(cmd, capture_output=True, text=True)
        line = [ln for ln in r.stdout.splitlines() if ln.startswith("luxo3d:")]
        print(line[0] if line else ("FAILED %s: %s %s" % (name, r.stdout[-900:], r.stderr[-900:])))


ONLY = [a for a in sys.argv[sys.argv.index("--") + 1:]] if (not LIVE and "--" in sys.argv) else None
build(ONLY)
if not LIVE:
    export_all(ONLY)
