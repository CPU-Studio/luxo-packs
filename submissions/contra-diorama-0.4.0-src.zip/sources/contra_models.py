"""Contra diorama pack: the character models (commando, soldier).

Rebuilds each model with its animation clips from an empty scene and exports
one GLB per model into ../../packs/contra-diorama/models/.  Headless:

    blender -b --python docs/3d-view/sources/contra/contra_models.py

Convention (tools/luxo3d/MODELS.md): 1 unit = 1 game pixel, Z up, the model
faces -Y, feet on Z = 0.  The game is seen from the side and the groups turn
the models east or west, so the camera sees each character's profile.

Designs are original and fill each sprite's role:
  commando   34 tall.  Jungle commando: bare arms, tan sleeveless vest with a
             leather bandolier, palette-coloured trousers (blue for player 1, red for
             player 2), a red headband, dark boots, a grey carbine.
  soldier    32 tall.  Enemy trooper: round helmet, palette-coloured uniform,
             pale gaiters, dark boots, a short rifle.

Parts are rigid and hang from empties (pivots); clips are NLA tracks, every
clip keys every pivot, strips have extrapolation Nothing.  Run loops are 24
frames with passing poses at 0 and 12.
Clips: stand, run, run_up, run_down, aim_up, aim_dup, aim_ddown, prone, jump,
wade, wade_up, wade_dup.
"""

import math
import os
import subprocess
import sys

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Quaternion, Vector

HERE = os.path.dirname(os.path.abspath(globals().get("__file__", "contra_models.py")))
REPO = os.path.normpath(os.path.join(HERE, "..", "..", "..", ".."))
PACK_DIR = os.path.join(REPO, "docs", "3d-view", "packs", "contra-diorama")
MODELS_DIR = os.path.join(PACK_DIR, "models")
BLEND = os.path.join(HERE, "blend", "contra_models.blend")
EXPORTER = os.path.join(REPO, "tools", "luxo3d", "blender_export.py")

rng = np.random.default_rng(1987)
WALK = 24
CELL = 64
N = 4
CELLS = {}


def clean():
    for c in (bpy.data.objects, bpy.data.meshes, bpy.data.materials, bpy.data.images,
              bpy.data.curves, bpy.data.lights, bpy.data.cameras, bpy.data.actions):
        for x in list(c):
            c.remove(x)
    for c in list(bpy.data.collections):
        bpy.data.collections.remove(c)


def collection(name):
    c = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(c)
    return c


def blur(a, r):
    for _ in range(r):
        a = (a + np.roll(a, 1, 0) + np.roll(a, -1, 0) + np.roll(a, 1, 1) + np.roll(a, -1, 1)) / 5
    return a


def noise(scale_px, n=CELL):
    return blur(rng.random((n, n)), scale_px)


def norm(a):
    a = a - a.min()
    return a / max(a.max(), 1e-6)


def pat_weave():
    y, x = np.mgrid[0:CELL, 0:CELL]
    w = 0.5 + 0.5 * np.sin(x * math.pi / 2) * np.sign(np.sin(y * math.pi / 4) + 1e-3)
    return 0.86 + 0.10 * w + 0.08 * (norm(noise(2)) - 0.5)


def pat_grain():
    return 0.80 + 0.28 * (norm(noise(1)) * 0.5 + norm(noise(4)) * 0.5)


def pat_skin():
    return 0.93 + 0.08 * norm(noise(3))


def pat_smooth():
    return 0.94 + 0.06 * norm(noise(5))


def pat_metal():
    y, x = np.mgrid[0:CELL, 0:CELL]
    brushed = norm(blur(rng.random((CELL, CELL)), 1).mean(axis=1, keepdims=True) + 0 * x)
    return 0.85 + 0.15 * brushed + 0.05 * norm(noise(3))


def pat_camo():
    return 0.78 + 0.30 * (norm(noise(6)) > 0.5) * 0.6 + 0.08 * norm(noise(2))


ATLAS = [
    ("skin", (1.00, 0.76, 0.56), pat_skin),
    ("hair", (0.16, 0.10, 0.07), pat_grain),
    ("vest", (0.80, 0.72, 0.50), pat_weave),
    ("leather", (0.36, 0.19, 0.07), pat_grain),
    ("boot", (0.10, 0.09, 0.09), pat_grain),
    ("gunmetal", (0.42, 0.44, 0.48), pat_metal),
    ("wood", (0.50, 0.27, 0.10), pat_grain),
    ("brass", (0.95, 0.72, 0.22), pat_metal),
    ("gaiter", (0.88, 0.86, 0.80), pat_weave),
    ("eye", (0.06, 0.05, 0.05), pat_smooth),
    ("helmet", (0.36, 0.40, 0.30), pat_camo),
    ("skin_enemy", (0.98, 0.70, 0.55), pat_skin),
    ("band", (0.80, 0.10, 0.08), pat_weave),
]
MAT = None
PALMATS = {}


def make_atlas():
    size = CELL * N
    img = np.ones((size, size, 4), dtype=np.float32)
    for i, (name, rgb, pat) in enumerate(ATLAS):
        CELLS[name] = i
        p = pat()
        cx, cy = i % N, i // N
        for k in range(3):
            img[cy * CELL:(cy + 1) * CELL, cx * CELL:(cx + 1) * CELL, k] = np.clip(rgb[k] * p, 0, 1)
    im = bpy.data.images.new("contra_chars", size, size, alpha=True)
    im.pixels.foreach_set(img.ravel())
    im.file_format = "PNG"
    im.pack()
    return tex_material("contra_chars", im)


def tex_material(name, im):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = next(n for n in nodes if n.type == "BSDF_PRINCIPLED")
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = im
    mat.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = 0.6
    return mat


def make_pal_materials():
    """pal1..pal3: the group's palette colour times a light grey cloth weave."""
    p = np.clip(pat_weave() * 1.05, 0, 1)
    img = np.ones((CELL, CELL, 4), dtype=np.float32)
    for k in range(3):
        img[:, :, k] = p
    im = bpy.data.images.new("cloth_grey", CELL, CELL, alpha=True)
    im.pixels.foreach_set(img.ravel())
    im.file_format = "PNG"
    im.pack()
    for n in (1, 2, 3):
        PALMATS["pal%d" % n] = tex_material("pal%d" % n, im)


def cell_uv(bm, cell):
    uv = bm.loops.layers.uv.verify()
    lo = Vector([min(v.co[k] for v in bm.verts) for k in range(3)])
    hi = Vector([max(v.co[k] for v in bm.verts) for k in range(3)])
    span = [max(hi[k] - lo[k], 1e-4) for k in range(3)]
    if cell in PALMATS:
        u0, v0, m, w = 0.0, 0.0, 0.0, 1.0
    else:
        i = CELLS[cell]
        u0, v0 = (i % N) / N, (i // N) / N
        m, w = 4 / (CELL * N), (CELL - 8) / (CELL * N)
    for f in bm.faces:
        n = f.normal
        ax = max(range(3), key=lambda k: abs(n[k]))
        a, b = [(1, 2), (0, 2), (0, 1)][ax]
        for loop in f.loops:
            co = loop.vert.co
            loop[uv].uv = (u0 + m + (co[a] - lo[a]) / span[a] * w, v0 + m + (co[b] - lo[b]) / span[b] * w)


def finish(bm, name, coll, cell, smooth_angle=60):
    bm.normal_update()
    cell_uv(bm, cell)
    lim = math.radians(smooth_angle)
    for f in bm.faces:
        f.smooth = True
    for e in bm.edges:
        e.smooth = len(e.link_faces) != 2 or e.calc_face_angle(0) < lim
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    me.materials.append(PALMATS.get(cell, MAT))
    ob = bpy.data.objects.new(name, me)
    coll.objects.link(ob)
    return ob


def ellipsoid(name, coll, c, r, cell, segs=(18, 10), rot=None):
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=segs[0], v_segments=segs[1], radius=1.0)
    for v in bm.verts:
        v.co = Vector((v.co.x * r[0], v.co.y * r[1], v.co.z * r[2]))
    if rot:
        bmesh.ops.rotate(bm, verts=bm.verts, cent=(0, 0, 0), matrix=rot.to_matrix())
    bmesh.ops.translate(bm, verts=bm.verts, vec=Vector(c))
    return finish(bm, name, coll, cell)


def rbox(name, coll, c, size, cell, bevel=0.5, rot=None):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co = Vector((v.co.x * size[0], v.co.y * size[1], v.co.z * size[2]))
    if bevel > 0:
        bmesh.ops.bevel(bm, geom=bm.edges[:], offset=bevel, offset_type="OFFSET", segments=2, profile=0.5,
                        affect="EDGES", clamp_overlap=True)
    if rot:
        bmesh.ops.rotate(bm, verts=bm.verts, cent=(0, 0, 0), matrix=rot.to_matrix())
    bmesh.ops.translate(bm, verts=bm.verts, vec=Vector(c))
    return finish(bm, name, coll, cell, 40)


def cyl(name, coll, p0, p1, r0, r1, cell, segs=12):
    p0, p1 = Vector(p0), Vector(p1)
    d = p1 - p0
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=segs, radius1=r0, radius2=r1, depth=d.length)
    q = Vector((0, 0, 1)).rotation_difference(d.normalized())
    bmesh.ops.rotate(bm, verts=bm.verts, cent=(0, 0, 0), matrix=q.to_matrix())
    bmesh.ops.translate(bm, verts=bm.verts, vec=(p0 + p1) / 2)
    return finish(bm, name, coll, cell, 50)


def limb(name, coll, p0, p1, r0, r1, cell):
    """A capsule: a tapered cylinder with a ball at each end."""
    a = cyl(name, coll, p0, p1, r0, r1, cell)
    b = ellipsoid(name + "_a", coll, p0, (r0, r0, r0), cell, segs=(12, 8))
    c = ellipsoid(name + "_b", coll, p1, (r1, r1, r1), cell, segs=(12, 8))
    return [a, b, c]


def rot(axis, deg):
    return Quaternion(Vector(axis), math.radians(deg))


RX = lambda deg: rot((1, 0, 0), deg)


def pivot(name, coll, at, children):
    e = bpy.data.objects.new(name, None)
    coll.objects.link(e)
    e.rotation_mode = "QUATERNION"
    e.location = at
    bpy.context.view_layer.update()
    for o in children:
        world = o.matrix_world.copy()
        o.parent = e
        o.matrix_parent_inverse = e.matrix_world.inverted()
        o.matrix_world = world
    return e


def turn(p, q, about=None):
    pt = p.matrix_world.translation.copy() if about is None else Vector(about)
    p.matrix_world = Matrix.Translation(pt) @ q.to_matrix().to_4x4() @ Matrix.Translation(-pt) @ p.matrix_world
    bpy.context.view_layer.update()


def shift(p, v):
    p.matrix_world = Matrix.Translation(Vector(v)) @ p.matrix_world
    bpy.context.view_layer.update()


def make_clips(pivots, clips):
    rest = {p.name: p.matrix_basis.copy() for p in pivots}
    for p in pivots:
        p.animation_data_create()

    def reset():
        for p in pivots:
            p.matrix_basis = rest[p.name]
        bpy.context.view_layer.update()

    for name, keys in clips:
        for frame, fn in keys:
            reset()
            fn()
            bpy.context.view_layer.update()
            for p in pivots:
                p.keyframe_insert("location", frame=frame)
                p.keyframe_insert("rotation_quaternion", frame=frame)
                p.keyframe_insert("scale", frame=frame)
        start, end = keys[0][0], keys[-1][0]
        for p in pivots:
            action = p.animation_data.action
            action.name = "%s_%s" % (name, p.name)
            track = p.animation_data.nla_tracks.new()
            track.name = name
            strip = track.strips.new(name, start, action)
            strip.extrapolation = "NOTHING"
            strip.frame_end = end
            p.animation_data.action = None
    reset()


def held(frame, fn):
    return [(frame, fn), (frame + 1, fn)]


# ----------------------------------------------------------------------------
# The trooper body, shared by the commando and the soldier.


def build_trooper(c, pre, kind):
    """kind: 'commando' or 'soldier'.  Returns the object name to centre the export on."""
    commando = kind == "commando"
    H = 1.0 if commando else 0.94          # the soldier sprite is a little shorter
    skin = "skin" if commando else "skin_enemy"
    cloth = "pal2"  # trousers / uniform follow the sprite palette
    legx = 2.5
    hip_z, knee_z = 16.0 * H, 9.0 * H
    sh_z = 26.0 * H                        # shoulder height
    head_z = 30.6 * H

    # --- legs
    def leg(side, s):
        thigh = limb(pre + "thigh" + side, c, (s * legx, 0, hip_z), (s * legx, -0.3, knee_z), 2.5, 2.1, cloth)
        shin = limb(pre + "shin" + side, c, (s * legx, -0.3, knee_z), (s * legx, 0, 3.4), 2.0,
                    1.7, cloth if commando else "gaiter")
        boot = [rbox(pre + "boot" + side, c, (s * legx, -1.0, 1.7), (3.6, 6.2, 3.4), "boot", 0.9),
                rbox(pre + "cuff" + side, c, (s * legx, 0, 3.8), (3.9, 4.2, 1.4), "boot" if commando else "leather", 0.5)]
        pt = pivot(pre + "p_thigh" + side, c, (s * legx, 0, hip_z), thigh)
        ps = pivot(pre + "p_shin" + side, c, (s * legx, -0.3, knee_z), shin + boot)
        return pt, ps

    thL, shL = leg("L", -1)
    thR, shR = leg("R", 1)

    # --- torso
    torso = []
    pelvis = rbox(pre + "pelvis", c, (0, 0, hip_z + 0.6), (9.4, 5.6, 4.4), cloth, 1.4)
    torso.append(pelvis)
    torso.append(rbox(pre + "belt", c, (0, 0, hip_z + 2.6), (9.8, 6.0, 1.5), "leather", 0.5))
    torso.append(rbox(pre + "buckle", c, (0, -3.0, hip_z + 2.6), (2.2, 0.8, 1.7), "brass", 0.3))
    chest_mat = "vest" if commando else cloth
    torso.append(rbox(pre + "chest", c, (0, -0.2, 22.6 * H), (10.6, 6.6, 7.8 * H), chest_mat, 2.0))
    torso.append(ellipsoid(pre + "shoulders", c, (0, 0, sh_z - 0.4), (6.4, 3.4, 2.6), chest_mat))
    if commando:
        # leather bandolier across the chest, brass rounds on it
        torso.append(rbox(pre + "strap", c, (0, -0.2, 22.8), (13.6, 7.2, 1.7), "leather", 0.4, rot((0, 1, 0), 42)))
        for i in range(4):
            t = (i - 1.5) * 2.2
            torso.append(cyl(pre + "round%d" % i, c, (t * 0.74, -3.9, 22.8 + t * 0.67 - 0.9),
                             (t * 0.74, -3.9, 22.8 + t * 0.67 + 0.9), 0.55, 0.45, "brass", 8))
        torso.append(cyl(pre + "neck", c, (0, 0, sh_z + 0.5), (0, -0.2, sh_z + 2.6), 1.9, 1.8, skin))
    else:
        torso.append(rbox(pre + "pack", c, (0, 4.0, 22.4 * H), (7.4, 3.0, 6.6), "leather", 0.9))
        torso.append(rbox(pre + "pouch", c, (3.2, -3.4, hip_z + 2.2), (2.6, 1.6, 2.6), "leather", 0.5))
        torso.append(cyl(pre + "neck", c, (0, 0, sh_z + 0.3), (0, -0.2, sh_z + 2.2), 1.9, 1.8, skin))
    p_torso = pivot(pre + "p_torso", c, (0, 0, hip_z + 1.0), torso)

    # --- head
    head = [ellipsoid(pre + "head", c, (0, -0.4, head_z), (3.7, 3.9, 3.9), skin)]
    head.append(ellipsoid(pre + "nose", c, (0, -4.2, head_z - 0.5), (0.9, 1.0, 0.9), skin, segs=(8, 6)))
    for s in (-1, 1):
        head.append(ellipsoid(pre + "eye%d" % s, c, (s * 1.5, -3.6, head_z + 0.5), (0.65, 0.5, 0.8), "eye", segs=(8, 6)))
        head.append(ellipsoid(pre + "ear%d" % s, c, (s * 3.6, 0.2, head_z - 0.2), (0.7, 1.0, 1.2), skin, segs=(8, 6)))
    head.append(rbox(pre + "jaw", c, (0, -1.6, head_z - 2.6), (5.0, 4.6, 2.4), skin, 1.0))
    if commando:
        head.append(ellipsoid(pre + "hair", c, (0, 0.5, head_z + 1.3), (3.95, 4.1, 3.3), "hair"))
        head.append(rbox(pre + "quiff", c, (0, -2.6, head_z + 3.3), (5.2, 3.0, 1.8), "hair", 0.7, RX(-18)))
        # headband with a knot and two tails at the back
        head.append(cyl(pre + "band", c, (0, 0, head_z + 0.9), (0, 0, head_z + 2.5), 4.25, 4.2, "band", 18))
        head.append(ellipsoid(pre + "knot", c, (0, 4.4, head_z + 1.6), (1.1, 0.9, 1.1), "band", segs=(8, 6)))
        head.append(rbox(pre + "tail1", c, (0.9, 6.2, head_z + 0.6), (1.3, 3.6, 0.7), "band", 0.25, RX(-25)))
        head.append(rbox(pre + "tail2", c, (-0.9, 6.0, head_z + 1.9), (1.3, 3.4, 0.7), "band", 0.25, RX(10)))
    else:
        head.append(ellipsoid(pre + "helmet", c, (0, 0.2, head_z + 1.5), (4.5, 4.9, 3.5), "helmet"))
        head.append(cyl(pre + "brim", c, (0, 0.1, head_z + 0.6), (0, 0.1, head_z + 1.3), 5.2, 4.9, "helmet", 18))
        head.append(rbox(pre + "chin", c, (0, -1.0, head_z - 1.6), (7.7, 0.9, 0.7), "leather", 0.2))
    p_head = pivot(pre + "p_head", c, (0, 0, sh_z + 1.6), head)

    # --- arms and the rifle, one rigid part hung from the shoulders
    gun_z = sh_z - 3.2
    arm = []
    # rear (right) arm: shoulder -> elbow back -> hand on the grip
    arm += limb(pre + "uarmR", c, (5.6, 0, sh_z - 0.6), (6.0, 1.6, gun_z - 1.2), 2.0, 1.7, skin if commando else cloth)
    arm += limb(pre + "farmR", c, (6.0, 1.6, gun_z - 1.2), (3.2, -3.6, gun_z - 0.4), 1.7, 1.5, skin)
    # front (left) arm reaches the fore-end
    arm += limb(pre + "uarmL", c, (-5.6, 0, sh_z - 0.6), (-5.4, -3.6, gun_z - 0.8), 2.0, 1.7, skin if commando else cloth)
    arm += limb(pre + "farmL", c, (-5.4, -3.6, gun_z - 0.8), (-1.8, -8.6, gun_z - 0.2), 1.7, 1.5, skin)
    if commando:
        for s, x in ((1, 5.9), (-1, -5.6)):
            arm.append(cyl(pre + "wrist%d" % s, c, (x * 0.62, -3.0 if s > 0 else -7.0, gun_z - 0.5),
                           (x * 0.5, -3.7 if s > 0 else -7.9, gun_z - 0.4), 1.75, 1.7, "leather", 10))
    # rifle along -Y at chest height, a little to the right of centre
    gx = 1.6
    L = 19.0 if commando else 15.0
    arm.append(rbox(pre + "receiver", c, (gx, -5.0, gun_z), (2.0, 8.0, 2.6), "gunmetal", 0.5))
    arm.append(cyl(pre + "barrel", c, (gx, -8.5, gun_z + 0.4), (gx, -L, gun_z + 0.4), 0.8, 0.7, "gunmetal", 10))
    arm.append(cyl(pre + "muzzle", c, (gx, -L + 0.4, gun_z + 0.4), (gx, -L - 1.2, gun_z + 0.4), 1.05, 1.05, "gunmetal", 10))
    arm.append(rbox(pre + "foreend", c, (gx, -10.2, gun_z - 0.3), (2.2, 5.0, 2.0), "wood", 0.5))
    arm.append(rbox(pre + "stock", c, (gx, 1.2, gun_z - 0.6), (1.8, 5.4, 2.8), "wood", 0.6, RX(-10)))
    arm.append(rbox(pre + "mag", c, (gx, -5.6, gun_z - 2.6), (1.5, 2.2, 3.6), "gunmetal", 0.4, RX(14)))
    arm.append(rbox(pre + "sight", c, (gx, -4.0, gun_z + 1.7), (0.7, 3.0, 0.9), "gunmetal", 0.2))
    p_arm = pivot(pre + "p_arm", c, (0, 0, sh_z - 0.6), arm)

    pivots = [p_torso, p_head, p_arm, thL, shL, thR, shR]
    upper = [p_torso, p_head, p_arm]
    legs = [thL, shL, thR, shR]
    hip = (0, 0, hip_z)
    sh = (0, 0, sh_z - 0.6)

    def leg_pose(th, sn, thigh_deg, knee_deg):
        h = th.matrix_world.translation.copy()
        turn(th, RX(thigh_deg), h)
        turn(sn, RX(thigh_deg), h)
        turn(sn, RX(knee_deg))  # about the knee, where the shin's pivot now is

    def aim(deg):
        """deg > 0 raises the rifle."""
        s = p_arm.matrix_world.translation.copy()
        turn(p_arm, RX(-deg), s)
        turn(p_head, RX(-deg * 0.25))

    def lean(deg):
        for p in upper:
            turn(p, RX(deg), hip)

    def all_turn(q, about):
        for p in pivots:
            turn(p, q, about)

    def all_shift(v):
        for p in pivots:
            shift(p, v)

    def run(ph, aim_deg=0):
        # ph: 0 passing (rest), 1 left leg forward, -1 right leg forward
        lean(7)
        if ph == 0:
            leg_pose(thL, shL, -8, 14)
            leg_pose(thR, shR, 6, 10)
        else:
            f, b = (thL, shL), (thR, shR)
            if ph < 0:
                f, b = b, f
            leg_pose(f[0], f[1], -44, 22)
            leg_pose(b[0], b[1], 30, 52)
            all_shift((0, 0, -0.8))
        aim(aim_deg)

    def run_keys(aim_deg):
        q = WALK // 4
        return [(i * q, (lambda p: (lambda: run(p, aim_deg)))(p)) for i, p in enumerate([0, 1, 0, -1, 0])]

    def stand(aim_deg=0):
        leg_pose(thL, shL, -10, 6)
        leg_pose(thR, shR, 10, 4)
        aim(aim_deg)

    def prone():
        # lying on the belly along -Y, propped on the elbows, rifle forward
        all_turn(RX(90), hip)
        all_shift((0, 2.0, -hip_z + 3.2))
        s = p_arm.matrix_world.translation.copy()
        turn(p_arm, RX(-88), s)
        shift(p_arm, (0, 0, 0.6))
        turn(p_head, RX(-60))

    def tuck(spin):
        leg_pose(thL, shL, -112, 124)
        leg_pose(thR, shR, -104, 120)
        lean(34)
        s = p_arm.matrix_world.translation.copy()
        turn(p_arm, RX(40), s)
        centre = Vector((0, -3.0, hip_z + 5.0))
        all_turn(RX(spin), centre)
        all_shift((0, 3.0, -(hip_z + 5.0) + 8.5))

    def wade(aim_deg):
        for p in legs:
            p.scale = (0.001, 0.001, 0.001)
        all_shift((0, 0, -(hip_z + 0.5)))
        aim(aim_deg)

    clips = [
        ("stand", held(0, lambda: stand(0))),
        ("run", [(f + 10, fn) for f, fn in run_keys(0)]),
        ("run_up", [(f + 40, fn) for f, fn in run_keys(45)]),
        ("run_down", [(f + 70, fn) for f, fn in run_keys(-38)]),
        ("aim_up", held(100, lambda: stand(88))),
        ("aim_dup", held(104, lambda: stand(45))),
        ("aim_ddown", held(108, lambda: stand(-38))),
        ("prone", held(112, prone)),
        ("jump", [(120 + i * 6, (lambda a: (lambda: tuck(a)))(a)) for i, a in enumerate([0, 90, 180, 270, 360])]),
        ("wade", held(150, lambda: wade(0))),
        ("wade_up", held(154, lambda: wade(88))),
        ("wade_dup", held(158, lambda: wade(45))),
    ]
    make_clips(pivots, clips)
    return pelvis.name


BUILDERS = [
    ("commando", lambda c: build_trooper(c, "cmd_", "commando")),
    ("soldier", lambda c: build_trooper(c, "sol_", "soldier")),
]
PIVOTS = {}


def coll_tris(coll):
    t = 0
    for o in coll.all_objects:
        if o.type == "MESH":
            o.data.calc_loop_triangles()
            t += len(o.data.loop_triangles)
    return t


def build(only=None):
    global MAT
    clean()
    bpy.context.scene.render.fps = 24
    MAT = make_atlas()
    make_pal_materials()
    for name, fn in BUILDERS:
        if only and name not in only:
            continue
        c = collection("m_" + name)
        PIVOTS["m_" + name] = fn(c)
        print("contra_models: %-10s %5d triangles" % (name, coll_tris(c)))
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 0, 170
    sc.frame_set(0)


def export_all(only=None):
    blender = bpy.app.binary_path or "blender"
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(BLEND), exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=BLEND, copy=True)
    for c in bpy.data.collections:
        if not c.name.startswith("m_") or (only and c.name[2:] not in only):
            continue
        name = c.name[2:]
        cmd = [blender, "-b", BLEND, "--python", EXPORTER, "--", "--out",
               os.path.join(MODELS_DIR, name + ".glb"), "--collection", c.name, "--animations",
               "--pivot", PIVOTS[c.name]]
        r = subprocess.run(cmd, capture_output=True, text=True)
        line = [ln for ln in r.stdout.splitlines() if ln.startswith("luxo3d:")]
        print(line[0] if line else ("FAILED %s: %s %s" % (name, r.stdout[-900:], r.stderr[-900:])))


if not globals().get("CONTRA_LIB_ONLY"):  # contra_enemies.py loads this file for its helpers
    ONLY = [a for a in sys.argv[sys.argv.index("--") + 1:]] if "--" in sys.argv else None
    build(ONLY)
    if os.environ.get("CONTRA_NO_EXPORT") != "1":
        export_all(ONLY)
