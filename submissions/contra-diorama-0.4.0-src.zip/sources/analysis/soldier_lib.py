import json,glob,collections,sys
from poses import norm,draw_atlas
def cluster_at(sp,x,y):
    near=[t for t in sp if abs(t["x"]+4-x)<=14 and abs(t["y"]+4-y)<=22]
    if not near: return None
    near.sort(key=lambda t:abs(t["x"]+4-x)+abs(t["y"]+4-y))
    comp=[near[0]]; rest=[t for t in sp if t is not near[0]]; ch=True
    while ch:
        ch=False
        for t in list(rest):
            if any(abs(t["x"]-u["x"])<=8 and abs(t["y"]-u["y"])<=8 for u in comp): comp.append(t); rest.remove(t); ch=True
    return comp
