import json,glob,collections,sys,os
from png import *
def norm(c):
    # c: list of tiles; returns (sig, mirrored)
    x0=min(t["x"] for t in c); y0=min(t["y"] for t in c); x1=max(t["x"] for t in c)
    nf=sum(1 for t in c if t["hflip"])
    mir=nf*2>len(c)
    if mir: sig=tuple(sorted((x1-t["x"],t["y"]-y0,t["key"],not t["hflip"],t["vflip"]) for t in c))
    else: sig=tuple(sorted((t["x"]-x0,t["y"]-y0,t["key"],t["hflip"],t["vflip"]) for t in c))
    return sig,mir
def player_cluster(d,g,rad=(22,30)):
    px,py=g(0x334),g(0x31a)
    sp=[t for t in d["tiles"] if t["layer"]=="sprite" and abs(t["x"]+4-px)<=rad[0] and abs(t["y"]+4-py)<=rad[1]]
    if not sp: return None
    # connected component containing tile nearest the player's centre
    sp.sort(key=lambda t:abs(t["x"]+4-px)+abs(t["y"]+4-py))
    comp=[sp[0]]; rest=sp[1:]; ch=True
    while ch:
        ch=False
        for t in list(rest):
            if any(abs(t["x"]-u["x"])<=8 and abs(t["y"]-u["y"])<=8 for u in comp): comp.append(t); rest.remove(t); ch=True
    return comp
def draw_atlas(items,path,COLS=16,S=2,cw=64,chh=100):
    rows=(len(items)+COLS-1)//COLS
    img=[[(40,40,70)]*(COLS*cw) for _ in range(rows*chh)]
    for i,tiles in enumerate(items):
        ox=(i%COLS)*cw+2; oy=(i//COLS)*chh+2
        for (dx,dy,p,pal,hf,vf) in tiles:
            for y in range(8):
                for x in range(8):
                    c=int(p[(7-y if vf else y)*8+(7-x if hf else x)],16)
                    if not c: continue
                    col=hexrgb(pal[c]); col=(24,24,24) if col==(0,0,0) else col
                    if dx+x<30 and dy+y<48 and dx+x>=0:
                        for sy in range(S):
                            for sx in range(S): img[oy+(dy+y)*S+sy][ox+(dx+x)*S+sx]=col
    write_png(path,COLS*cw,rows*chh,img)
if __name__=="__main__":
    cnt=collections.Counter(); first={}; when=collections.defaultdict(collections.Counter)
    seqs=json.load(open("in/poses_seq.json")) if os.path.exists("in/poses_seq.json") else None
    for f in sorted(glob.glob(sys.argv[1])):
        d=json.load(open(f)); r=d["ram"]; g=lambda i:int(r[i*2:i*2+2],16)
        if g(0x2c)!=4: continue
        c=player_cluster(d,g)
        if not c: continue
        sig,mir=norm(c); cnt[sig]+=1
        fr=d["frame"]
        if seqs:
            lab=next((l for a,b,l in seqs if a<=fr<b),"?"); when[sig][lab]+=1
        if sig not in first:
            pix={s["key"]:s["pixels"] for s in d["shapes"]}; pal={t["key"]:d["palettes"][t["pal"]] for t in c}
            first[sig]=[(t[0],t[1],pix[t[2]],pal[t[2]],t[3],t[4]) for t in sig]
    top=[k for k,_ in cnt.most_common()]
    draw_atlas([first[k] for k in top],sys.argv[2])
    json.dump([{"i":i,"sig":k,"n":cnt[k],"when":when[k].most_common(3)} for i,k in enumerate(top)],open(sys.argv[2].replace(".png",".json"),"w"))
    for i,k in enumerate(top): print(i,cnt[k],len(k),when[k].most_common(3))
