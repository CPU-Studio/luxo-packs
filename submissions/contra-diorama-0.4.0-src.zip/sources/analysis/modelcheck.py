import json,glob,sys,collections
tot=0;ok=0;miss=[]
for f in sorted(glob.glob(sys.argv[1]+"/*.json")):
    d=json.load(open(f)); tot+=1
    m=[x for x in d.get("models",[]) if x.get("object")==sys.argv[2]]
    if m: ok+=1
    else: miss.append(d["frame"])
print(ok,"of",tot,"frames show the model; first misses:",miss[:40])
