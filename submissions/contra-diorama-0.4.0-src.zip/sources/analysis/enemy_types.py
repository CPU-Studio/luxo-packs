import json,glob,collections,sys,pickle
from poses import norm,draw_atlas
from soldier_lib import cluster_at
stat={}
for f in sorted(glob.glob("dumps/st[0-7]/*.json")):
    d=json.load(open(f)); r=d["ram"]; g=lambda i:int(r[i*2:i*2+2],16)
    if g(0x2c)!=4: continue
    L=g(0x30)
    sp=[t for t in d["tiles"] if t["layer"]=="sprite" and not (t["y"]<30 and t["x"]<70)]
    pix=None
    for s in range(16):
        ty=g(0x528+s)
        if g(0x4b8+s)==0: continue
        x,y=g(0x33e+s),g(0x324+s)
        c=cluster_at(sp,x,y)
        key=(L,ty)
        st=stat.setdefault(key,{"n":0,"nosprite":0,"sigs":collections.Counter(),"draw":{}})
        st["n"]+=1
        if not c or len(c)>40: st["nosprite"]+=1; continue
        sig,mir=norm(c); st["sigs"][sig]+=1
        if sig not in st["draw"]:
            pix=pix or {s_["key"]:s_["pixels"] for s_ in d["shapes"]}
            pal={t["key"]:d["palettes"][t["pal"]] for t in c}
            st["draw"][sig]=[(t[0],t[1],pix[t[2]],pal[t[2]],t[3],t[4]) for t in sig]
pickle.dump(stat,open("scratch/etypes.pkl","wb"))
items=[]
for (L,ty),st in sorted(stat.items()):
    top=st["sigs"].most_common(2)
    print("stage",L+1,"type",ty,"n",st["n"],"nosprite",st["nosprite"],"sigs",len(st["sigs"]),[(c,len(s),max(t[0] for t in s)+8,max(t[1] for t in s)+8) for s,c in top])
    for s,c in top[:2]:
        if c>=3: items.append(((L,ty,c),st["draw"][s]))
draw_atlas([d for k,d in items],"scratch/etypes.png",COLS=16,S=2,cw=64,chh=100)
print([k for k,d in items])
