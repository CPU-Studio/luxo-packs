#!/usr/bin/env python3
"""cap.py NAME OUTSUB key=value...  -> runs capture, prints short summary"""
import sys, json, subprocess, os, re
W=os.path.dirname(os.path.abspath(__file__))
R=os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","..","..","..",".."))
name=sys.argv[1]; out=sys.argv[2]
a={"rom":R+"/roms/Contra (USA).nes","name":name,"out":os.path.join(W,out)}
for kv in sys.argv[3:]:
    k,v=kv.split("=",1)
    if k in("frames","every"): v=int(v)
    elif k in("poke","ram","save_at"): v=[x for x in v.split(",") if x]; 
    elif k=="sheet": v=True
    elif k in("state","inputs") and not v.startswith("/"): v=os.path.join(W,v)
    if k=="save_at": v=[int(x) for x in v]
    if k=="poke": v=[x.replace(":","=") for x in v]
    a[k]=v
os.makedirs(a["out"],exist_ok=True)
r=subprocess.run(["python3",R+"/tools/luxo3d/luxo3d_mcp.py","call","capture",json.dumps(a)],capture_output=True,text=True)
o=r.stdout+r.stderr
q=os.environ.get("Q")
for l in o.splitlines():
    if q and re.match(r"^\S+_\d{6}:",l): continue
    l=l.replace(W+"/","")
    print(l[:300])
