import pickle,json
items=pickle.load(open("scratch/soldiers.pkl","rb"))
G=[];rep=[]
for (ty,sig),v in items:
    n=len(sig); w=max(t[0] for t in sig)+8; h=max(t[1] for t in sig)+8
    px=v["px"].most_common(1)[0][0]; py=v["py"].most_common(1)[0][0]
    if n<6 or n>11 or w>26: continue
    if ty==5:
        if h!=32 or w!=16: continue
        clip="run"
    else:
        if w<=16: continue
        if h<=16: clip="prone"
        elif h>=38: clip="aim_dup"
        else:
            # rifle tip: lit pixels in the 6 rightmost columns
            ys=[]
            for (dx,dy,p,pal,hf,vf) in v["draw"]:
                for y in range(8):
                    for x in range(8):
                        if p[(7-y if vf else y)*8+(7-x if hf else x)]!="0" and dx+x>=w-6: ys.append(dy+y)
            m=sum(ys)/max(len(ys),1)
            clip="stand" if w<=16 else ("aim_ddown" if m>16 else "stand")
            rep.append(("tip",n,w,h,round(m,1),v["n"]))
    at=[px,py+17] if clip!="prone" else [w//2,h]
    for facing in ("east","west"):
        ts=sorted(sig,key=lambda t:(t[1],t[0]))
        if facing=="west": ts=sorted([(w-8-t[0],t[1],t[2],not t[3],t[4]) for t in sig],key=lambda t:(t[1],t[0]))
        ax,ay=ts[0][0],ts[0][1]; mx=at[0] if facing=="east" else w-at[0]
        G.append({"id":"soldier_%s_%d_%s"%(clip,len(rep),facing[0]),"object":"soldier" if ty==5 else "rifleman","facing":facing,"layer":"sprite","model":"soldier","clip":clip,
                  "model_at":[mx-ax,at[1]-ay],"tiles":[{"dx":t[0]-ax,"dy":t[1]-ay,"key":t[2],"hflip":t[3],"vflip":t[4]} for t in ts]})
    rep.append((ty,clip,v["n"],n,w,h,at))
G.sort(key=lambda g:-len(g["tiles"]))
json.dump(G,open("soldier_groups.json","w"),indent=1)
for r in rep: print(r)
