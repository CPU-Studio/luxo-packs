import zlib,struct
def write_png(path,w,h,px):  # px: list of rows of (r,g,b)
    raw=b"".join(b"\x00"+bytes(c for p in row for c in p) for row in px)
    def ch(t,d): return struct.pack(">I",len(d))+t+d+struct.pack(">I",zlib.crc32(t+d)&0xffffffff)
    open(path,"wb").write(b"\x89PNG\r\n\x1a\n"+ch(b"IHDR",struct.pack(">IIBBBBB",w,h,8,2,0,0,0))+ch(b"IDAT",zlib.compress(raw,6))+ch(b"IEND",b""))
def hexrgb(s): return (int(s[1:3],16),int(s[3:5],16),int(s[5:7],16))
