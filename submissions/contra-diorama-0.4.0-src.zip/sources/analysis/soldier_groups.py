import json,glob,collections,sys
from poses import norm,draw_atlas
def cluster_at(sp,x,y):
    near=[t for t in sp if abs(t["x"]+4-x)<=14 and abs(t["y"]+4-y)<=22]
    if not near: return None
    near.sort(key=lambda t:abs(t["x"]+4-x)+abs(t["y"]+4-y))
    comp=[near[0]]; rest=[t for t in sp if t is not near[0]]; ch=True
    while ch:
        ch=False
        for t in list(rest):
            if any(abs(t["x"]-u["x"])<=8 and abs(t["y"]-u["y"])<=8 for u in comp): comp.append(t); rest.remove(t); ch=True
    return comp
stat={}
for f in sorted(glob.glob("dumps/st[024567]/*.json")+glob.glob("dumps/pose*/*.json")):
    d=json.load(open(f)); r=d["ram"]; g=lambda i:int(r[i*2:i*2+2],16)
    if g(0x2c)!=4: continue
    sp=[t for t in d["tiles"] if t["layer"]=="sprite" and not (t["y"]<30 and t["x"]<70)]
    pix=None
    for s in range(16):
        ty=g(0x528+s)
        if ty not in (5,6) or g(0x4b8+s)==0: continue
        x,y=g(0x33e+s),g(0x324+s)
        c=cluster_at(sp,x,y)
        if not c or len(c)>14: continue
        x0=min(t["x"] for t in c); x1=max(t["x"] for t in c)+8; y0=min(t["y"] for t in c)
        if x1-x0>40 or max(t["y"] for t in c)+8-y0>48: continue
        sig,mir=norm(c)
        st=stat.setdefault((ty,sig),{"n":0,"px":collections.Counter(),"py":collections.Counter(),"stages":set()})
        st["n"]+=1; st["px"][(x-x0) if not mir else (x1-x)]+=1; st["py"][y-y0]+=1; st["stages"].add(f.split("/")[1])
        if "draw" not in st:
            pix=pix or {s_["key"]:s_["pixels"] for s_ in d["shapes"]}
            pal={t["key"]:d["palettes"][t["pal"]] for t in c}
            st["draw"]=[(t[0],t[1],pix[t[2]],pal[t[2]],t[3],t[4]) for t in sig]
            st["pal"]=d["palettes"][c[0]["pal"]]
items=sorted(stat.items(),key=lambda kv:(kv[0][0],-kv[1]["n"]))
items=[it for it in items if it[1]["n"]>=3]
draw_atlas([v["draw"] for k,v in items],"scratch/soldiers.png",COLS=16)
for i,(k,v) in enumerate(items):
    w=max(t[0] for t in k[1])+8; h=max(t[1] for t in k[1])+8
    print(i,"type",k[0],"n",v["n"],"tiles",len(k[1]),"box",w,h,"pos",v["px"].most_common(1)[0][0],v["py"].most_common(1)[0][0],sorted(v["stages"]),v["pal"] if i%8==0 else "")
import pickle; pickle.dump(items,open("scratch/soldiers.pkl","wb"))
