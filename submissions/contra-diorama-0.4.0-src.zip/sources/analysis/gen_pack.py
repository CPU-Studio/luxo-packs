import json,collections,os
from classify import stats,roles
PACK=os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","..","..","packs","contra-diorama","pack.json"))
old=json.load(open("base_pack_010.json"))
NAMES=["stage1","stage2","stage3","stage4","stage5","stage6","stage7","stage8"]
VIEW={}
p=dict(old); p["version"]="0.4.0"; p["authors"]=["kienct","Claude"]
p["scenes"]=[{"id":NAMES[L],"view":VIEW.get(L,"side"),"when":"ram[0x0018] == 5 && ram[0x002c] in [4, 9] && ram[0x0030] == %d"%L} for L in range(8)]
tiles=[t for t in old["tiles"]]
have={(t["key"],t.get("pal"),t.get("scene")) for t in tiles}
ov=json.load(open("overrides.json")) if os.path.exists("overrides.json") else {}
WATER={0:'blue',2:'cyan',4:'blue'}
for L in range(8):
    cnt,pix=stats("st%d"%L,vertical=(L==2))
    ro=roles(cnt,pix,water=WATER.get(L),force=("background" if L in (1,3) else None)); sc=NAMES[L]
    for (k,pal),(r,n,c) in sorted(ro.items(),key=lambda kv:-kv[1][1]):
        o=ov.get(sc,{}).get("%s/%d"%(k,pal)) or ov.get(sc,{}).get(k)
        if (k,pal,sc) in have:
            if o:
                for t in tiles:
                    if (t["key"],t.get("pal"),t.get("scene"))==(k,pal,sc): t.clear(); t.update({"key":k,"pal":pal,"scene":sc}); t.update(o if isinstance(o,dict) else {"role":o})
            continue
        t={"key":k,"pal":pal,"scene":sc}
        t.update(o if isinstance(o,dict) else {"role":o or r}); tiles.append(t)
p["tiles"]=tiles
p["hud"]=[]
p["groups"]=[{"id":"medal","object":"hud_medal","layer":"sprite","role":"hud","tiles":[{"dx":0,"dy":0,"key":"820cf21fbe17b5f0"},{"dx":0,"dy":8,"key":"20be503b2a44c03f"}]}]+json.load(open("player_groups.json"))+json.load(open("soldier_groups.json"))+json.load(open("enemy_groups.json"))+json.load(open("groups.json"))+[g for g in p["groups"] if g["id"] not in("medal","bullet")]
for g in p["groups"]: g.pop("scene",None)
for e in p["effects"]: e.pop("scene",None)
for e in p["effects"]:
    if e["id"]=="bullet_sparks": e["do"][0]["count"]=4
p["effects"].append({"id":"pickup_glow","on":"disappear","object":"pickup","do":[{"preset":"particles","kind":"sparks","count":12,"color":"#ffe060","speed":60,"life_ms":400,"size":1},{"preset":"light","color":"#ffe080","radius":48,"intensity":1.2,"ms":220}]})
p["models"]={"commando":{"file":"models/commando.glb","scale":0.96,"clip":"stand","clip_px":28},"soldier":{"file":"models/soldier.glb","scale":0.93,"clip":"stand","clip_px":26},
 "pod":{"file":"models/pod.glb","scale":0.93},"rock_ledge":{"file":"models/rock_ledge.glb","scale":1.0},
 "flame":{"file":"models/flame.glb","scale":1.0,"clip":"burn"},"gunner":{"file":"models/gunner.glb","scale":1.12},
 "cart":{"file":"models/cart.glb","scale":1.0,"clip":"roll","clip_px":25},"saucer":{"file":"models/saucer.glb","scale":1.0,"clip":"spin"},
 "scorpion":{"file":"models/scorpion.glb","scale":1.1,"clip":"walk","clip_px":16},"boulder":{"file":"models/boulder.glb","scale":1.1,"clip":"tumble"},
 "arm_ball":{"file":"models/arm_ball.glb","scale":1.05,"clip":"spin"},"arm_claw":{"file":"models/arm_claw.glb","scale":1.02,"clip":"spin"}}
json.dump(p,open(PACK,"w"),indent=1)
print(len(tiles),"tile rules")
