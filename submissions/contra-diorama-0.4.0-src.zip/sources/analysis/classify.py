import json,glob,collections,sys
from coll import load,code
def stats(st,ntmode=1,dy=-16,vertical=False,step=1):
    cnt=collections.defaultdict(collections.Counter); pix={}; global PALS; PALS={}
    for f in sorted(glob.glob("dumps/%s/*.json"%st))[::step]:
        d=load(f); g=d["g"]
        if g(0x2c)!=4: continue
        for s in d["shapes"]: pix[s["key"]]=s["pixels"]
        for t in d["tiles"]:
            if t["layer"]!="bg": continue
            if vertical:
                wy=t["y"]-g(0x65) ; wx=t["x"]
                nt=(g(0x64)+(wy//240))&1; wy%=240
                c=code(g,nt,(wx&255)>>4,wy>>4)
            else:
                wx=t["x"]+g(0x65); wy=t["y"]+dy
                if wy<0: c=0
                else:
                    nt=((g(0x64)+(wx>>8))&1)^ntmode
                    c=code(g,nt,(wx&255)>>4,wy>>4)
            cnt[(t["key"],t["pal"])][c]+=1; PALS[(t["key"],t["pal"])]=d["palettes"][t["pal"]]
    return cnt,pix
def waterish(k,p,pix,mode):
    pal=PALS[(k,p)]; lit=[int(ch,16) for ch in pix[k] if ch!="0"]
    if len(lit)<32: return False
    ok=0
    for c in lit:
        r,g,b=int(pal[c][1:3],16),int(pal[c][3:5],16),int(pal[c][5:7],16)
        if mode=="cyan": ok+= (r<90 and b>120 and g>100) 
        else: ok+= (r<70 and g<130 and b>150)
    return ok/len(lit)>=0.85
def roles(cnt,pix,water=None,force=None):
    out={}
    for (k,p),c in cnt.items():
        n=sum(c.values()); f=lambda x:c[x]/n
        empty=pix[k].count("0")/64
        if force: r=force
        elif f(3)>=0.3: r="solid"
        elif f(1)>=0.3: r="platform"
        elif f(2)>=0.3: r="water"
        elif water and waterish(k,p,pix,water): r="water"
        elif empty>=0.9: r="sky"
        else: r="background"
        out[(k,p)]=(r,n,dict(c))
    return out
if __name__=="__main__":
    for st in sys.argv[1:]:
        cnt,pix=stats(st,step=3); ro=roles(cnt,pix)
        print(st,len(ro),collections.Counter(r for r,_,_ in ro.values()), "tile-weighted",{r:sum(n for rr,n,_ in ro.values() if rr==r) for r in set(x[0] for x in ro.values())})
