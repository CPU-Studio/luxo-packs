#!/usr/bin/env python3
# greedy climber for the waterfall stage: tries input macros from a state, keeps the best
import json, subprocess, os, sys, random, shutil
W=os.path.dirname(os.path.abspath(__file__)); R=os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","..","..","..",".."))
ROM=R+"/roms/Contra (USA).nes"
def run(state, lines, frames, name):
    inp=os.path.join(W,"scratch/climb_"+os.path.basename(sys.argv[3]),name+".txt"); open(inp,"w").write("\n".join(lines)+"\n")
    a={"rom":ROM,"name":name,"out":os.path.join(W,"scratch/climb_"+os.path.basename(sys.argv[3])),"state":state,"inputs":inp,"frames":frames,"every":frames,
       "poke":["0xb0=200","0x32=9","0xaa=0x13"]}
    subprocess.run(["python3",R+"/tools/luxo3d/luxo3d_mcp.py","call","capture",json.dumps(a)],capture_output=True,text=True)
    d=json.load(open(os.path.join(W,"scratch/climb_"+os.path.basename(sys.argv[3]),"%s_%06d.json"%(name,frames))))
    r=d["ram"]; g=(lambda i:int(r[i*2:i*2+2],16)) if isinstance(r,str) else (lambda i:r[i])
    return g(0x64),g(0x65),g(0x31a),g(0x334),g(0x2c), os.path.join(W,"scratch/climb_"+os.path.basename(sys.argv[3]),name+"_last.state")
def macro(kind,n):
    d,j=kind
    L=[]
    for f in range(0,n,4):
        b=[d] if d else []
        if (f//4)%2==0: b.append("B")
        if j and f<j: b.append("A")
        if b: L.append("%d-%d %s"%(f,f+3,"+".join(b)))
    return L or ["0 B"]
os.makedirs(os.path.join(W,"scratch/climb_"+os.path.basename(sys.argv[3])),exist_ok=True)
state=sys.argv[1]; steps=int(sys.argv[2]); out=sys.argv[3]

def seq(wd,wn,jd,up=False):
    L=[]
    for f in range(0,wn,4):
        b=[wd]+(["B"] if (f//4)%2==0 else []); L.append("%d-%d %s"%(f,f+3,"+".join(b)))
    for f in range(wn,wn+64,4):
        b=([jd] if jd else [])+(["B"] if (f//4)%2==0 else [])+(["A"] if f<wn+20 else [])
        if b: L.append("%d-%d %s"%(f,f+3,"+".join(b)))
    return L, wn+64
from concurrent.futures import ThreadPoolExecutor
ex=ThreadPoolExecutor(12)
def score(s): return (s[0]*240+s[1])+(240-s[2])
cur=state; total=[]; last=None; stuck=0
for i in range(steps):
    cands=[(wd,wn,jd) for wd in ("LEFT","RIGHT") for wn in (0,12,24,40,56,80) for jd in ("LEFT","RIGHT","")]
    res=list(ex.map(lambda t:(t[1],run(cur,seq(*t[1])[0],seq(*t[1])[1],"c%d"%t[0])),enumerate(cands)))
    res.sort(key=lambda r:-score(r[1]))
    pick=res[0] if stuck<2 else random.choice(res[:10])
    c,s=pick; sc=score(s); stuck=stuck+1 if (last is not None and sc<=last) else 0; last=sc
    keep=os.path.join(W,"scratch/climb_"+os.path.basename(sys.argv[3]),"step%03d.state"%i); shutil.copy(s[5],keep); cur=keep
    total.append(c); print(i,c,"screen",s[0],s[1],"y",s[2],"x",s[3],"rt",s[4],flush=True)
    if s[4]!=4: break
L=[];off=0
for c in total:
    ls,n=seq(*c)
    for l in ls:
        fr,b=l.split(" ",1); a,e=fr.split("-"); L.append("%d-%d %s"%(int(a)+off,int(e)+off,b))
    off+=n
open(out,"w").write("\n".join(L)+"\n"); print("frames",off)
