import json,glob,collections,sys
from poses import player_cluster,norm
seqs=json.load(open("in/poses_seq.json"))
stat={}
for f in sorted(glob.glob("dumps/pose/*.json")+glob.glob("dumps/pose2/*.json")+glob.glob("dumps/st[024567]/*.json")):
    d=json.load(open(f)); r=d["ram"]; g=lambda i:int(r[i*2:i*2+2],16)
    if g(0x2c)!=4: continue
    c=player_cluster(d,g)
    if not c: continue
    sig,mir=norm(c)
    x0=min(t["x"] for t in c); x1=max(t["x"] for t in c)+8; y0=min(t["y"] for t in c)
    px=g(0x334)-x0 if not mir else x1-g(0x334)
    s=stat.setdefault(sig,{"n":0,"px":collections.Counter(),"py":collections.Counter(),"lab":collections.Counter(),"ay":collections.Counter(),"ja":0,"st":0})
    s["n"]+=1; s["ja"]+=g(0xa0)!=0; s["st"]+=("/st" in f); s["ay"][g(0x31a)]+=1; s["px"][px]+=1; s["py"][g(0x31a)-y0]+=1
    if "pix" not in s:
        _p={q["key"]:q["pixels"] for q in d["shapes"]}; s["pix"]=[(t[0],t[1],_p[t[2]],t[3],t[4]) for t in sig]
    s["lab"][next((l for a,b,l in seqs if a<=d["frame"]<b),"?")]+=1
J=json.load(open("scratch/poseatlas.json"))
ripple={t[2] for t in J[1]["sig"]}
G=[]; rep=[]
PK=set()
for sig_,s_ in stat.items():
    if s_['st']==0 and s_['n']>=3: PK|={t[2] for t in sig_}
EXK={t['key'] for g in json.load(open('groups.json')) for t in g['tiles']}
for sig,s in sorted(stat.items(),key=lambda kv:(-len(kv[0]),-kv[1]["n"])):
    if s["n"]<2: continue
    keys={t[2] for t in sig}
    w=max(t[0] for t in sig)+8; h=max(t[1] for t in sig)+8
    lab=collections.Counter()
    for l,n in s["lab"].items():
        fl=frozenset(x for x in l.replace("*","").split("+") if x)
        lab[fl]+=n
    top=lab.most_common(1)[0][0]
    up="UP" in top; dn="DOWN" in top; mv=("LEFT" in top) or ("RIGHT" in top)
    water=bool(keys&ripple) or s['ay'].most_common(1)[0][0]>=205
    px=s["px"].most_common(1)[0][0]; py=s["py"].most_common(1)[0][0]
    if keys&EXK: continue
    jumping=s['ja']*2>s['n'] and len(sig)<=7
    fallback=s['st']*2>s['n'] and not jumping
    if fallback:
        if not (s['n']>=4 and 8<=len(sig)<=11 and w<=28 and 36<=h<=56 and len(keys&PK)*2>=len(keys)): continue
    if jumping and not (keys&ripple): clip='jump'; at=[px,py+9]
    elif water:
        if keys<=ripple or len(sig)<=2: continue
        clip="wade_dup" if (up and mv) else "wade_up" if up else "wade"; at=[px,h-8]
    elif h<=16 and w>=24: clip="prone"; at=[px,h-2]
    elif w<=16 and h<=24 and len(sig)<=4: clip="jump"; at=[w//2,h]
    else:
        if fallback:
            ys=[dy+y for (dx,dy,p,hf,vf) in s["pix"] for y in range(8) for x in range(8) if p[(7-y if vf else y)*8+(7-x if hf else x)]!="0" and dx+x>=px+8]
            m=(sum(ys)/len(ys)-py) if ys else None
            up=(m is None and h>=50) or (m is not None and m<-12); dn=m is not None and m>1; mv=m is not None
        clip="run_up" if (up and mv) else "run_down" if (dn and mv) else "aim_up" if up else "run" if mv else "stand"
        at=[px,py+17]
    for facing in ("east","west"):
        ts=sorted(sig,key=lambda t:(-t[1],t[0]))
        if facing=="west": ts=sorted([(w-8-t[0],t[1],t[2],not t[3],t[4]) for t in sig],key=lambda t:(-t[1],t[0]))
        ax,ay=ts[0][0],ts[0][1]
        mx=at[0] if facing=="east" else w-at[0]
        G.append({"id":"player_%s_%d_%s"%(clip,len(rep),facing[0]),"object":"player","facing":facing,"layer":"sprite","model":"commando","clip":clip,
                  "model_at":[mx-ax,at[1]-ay],"tiles":[{"dx":t[0]-ax,"dy":t[1]-ay,"key":t[2],"hflip":t[3],"vflip":t[4]} for t in ts]})
    rep.append((clip,s["n"],len(sig),w,h,at,dict(lab.most_common(2))))
json.dump(G,open("player_groups.json","w"),indent=1)
for r in rep: print(r)
print(len(G))
