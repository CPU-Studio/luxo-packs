import pickle,json,collections
stat=pickle.load(open("scratch/etypes.pkl","rb"))
EXK={t['key'] for g in json.load(open('groups.json')) if g["object"]=="explosion" for t in g['tiles']}
PK={t['key'] for g in json.load(open('player_groups.json'))+json.load(open('soldier_groups.json')) for t in g['tiles']}
# model: (types by stage index or None for any stage, tiles range, box w range, box h range, facing?, clip, object)
SPEC={
 "pod":       ([(None,3)],            (6,6),  (24,24),(16,16), False, None,     "pod"),
 "rock_ledge":([(2,16)],              (12,14),(32,32),(28,32), False, None,     "platform_rock"),
 "flame":     ([(2,17)],              (4,4),  (16,16),(16,16), False, "burn",   "fire"),
 "gunner":    ([(4,14),(5,14),(6,14)],(12,14),(30,32),(30,32), True,  None,     "gunner"),
 "cart":      ([(6,20),(6,21)],       (10,10),(32,32),(22,22), False, "roll",   "cart"),
 "saucer":    ([(4,21)],              (6,6),  (24,24),(16,16), False, "spin",   "saucer"),
 "scorpion":  ([(7,20),(7,21),(7,17)],(12,12),(32,32),(32,32), True,  "walk",   "scorpion"),
 "boulder":   ([(2,18),(2,19)],       (12,12),(24,24),(32,32), False, "tumble", "boulder"),
}
G=[];rep=[]
for model,(types,nt,bw,bh,facing,clip,obj) in SPEC.items():
    sigs=collections.Counter()
    for (L,ty),st in stat.items():
        if not any((a is None or a==L) and b==ty for a,b in types): continue
        for sig,c in st["sigs"].items(): sigs[sig]+=c
    k=0
    for sig,c in sigs.most_common():
        n=len(sig); w=max(t[0] for t in sig)+8; h=max(t[1] for t in sig)+8; keys={t[2] for t in sig}
        if c<2 or not (nt[0]<=n<=nt[1] and bw[0]<=w<=bw[1] and bh[0]<=h<=bh[1]) or keys&EXK or keys&PK: continue
        for f in ("east","west"):
            ts=sorted(sig,key=lambda t:(t[1],t[0]))
            if f=="west": ts=sorted([(w-8-t[0],t[1],t[2],not t[3],t[4]) for t in sig],key=lambda t:(t[1],t[0]))
            ax,ay=ts[0][0],ts[0][1]
            g={"id":"%s_%d_%s"%(model,k,f[0]),"object":obj,"layer":"sprite","model":model,
               "tiles":[{"dx":t[0]-ax,"dy":t[1]-ay,"key":t[2],"hflip":t[3],"vflip":t[4]} for t in ts]}
            if facing: g["facing"]=f if model!="gunner" else ("west" if f=="east" else "east")  # the gunner's art faces left
            if clip: g["clip"]=clip
            if sorted(json.dumps(x["tiles"]) for x in G if x["model"]==model).count(json.dumps(g["tiles"])): continue
            G.append(g)
        k+=1; rep.append((model,c,n,w,h))
def ball(id,obj,model,k1,k2):
    return {"id":id,"object":obj,"layer":"sprite","model":model,"clip":"spin","tiles":[
        {"dx":0,"dy":0,"key":k1,"hflip":False},{"dx":0,"dy":8,"key":k2,"hflip":False},
        {"dx":8,"dy":0,"key":k1,"hflip":True},{"dx":8,"dy":8,"key":k2,"hflip":True}]}
G.append(ball("arm_ball","boss_arm","arm_ball","4b08652e6af820cb","cd40edf331f85af1"))
G.append(ball("arm_claw","boss_arm","arm_claw","ffe66794d3585666","d31e2fb3b31fe890"))
G.sort(key=lambda g:-len(g["tiles"]))
json.dump(G,open("enemy_groups.json","w"),indent=1)
for r in rep: print(r)
print(len(G))
