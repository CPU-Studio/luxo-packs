import json,glob,collections,sys
def load(f):
    d=json.load(open(f)); r=d["ram"]; d["g"]=lambda i:int(r[i*2:i*2+2],16); return d
def code(g,nt,cx,cy):
    b=g(0x680+nt*0x40+(cy&15)*4+(cx>>2)); return (b>>(6-2*(cx&3)))&3
if __name__=="__main__":
    st=sys.argv[1]; fs=sorted(glob.glob("dumps/%s/*.json"%st))[::7]
    ds=[load(f) for f in fs]; ds=[d for d in ds if d["g"](0x2c)==4]
    best=[]
    for ntmode in (0,1):
      for dx in range(0,16,1):
        for dy in range(0,16,2):
            cnt=collections.defaultdict(collections.Counter)
            for d in ds:
                g=d["g"]; sc=g(0x65); scr=g(0x64)
                for t in d["tiles"]:
                    if t["layer"]!="bg": continue
                    wx=t["x"]+sc+dx; wy=t["y"]+dy
                    nt=((scr+(wx>>8))&1)^ntmode
                    c=code(g,nt,(wx&255)>>4,wy>>4)
                    cnt[t["key"]][c]+=1
            pur=sum(max(c.values()) for c in cnt.values())/sum(sum(c.values()) for c in cnt.values())
            nz=sum(sum(v for k,v in c.items() if k) for c in cnt.values())
            best.append((pur,nz,ntmode,dx,dy))
    best.sort(reverse=True); print(best[:8])
