# Contra pack sources

Everything in `docs/3d-view/packs/contra-diorama` is rebuilt from these.

| File | Rebuilds |
|---|---|
| `contra_models.py` | The character models with their clips: `commando` (player) and `soldier` (`blender -b --python contra_models.py`). Saves `blend/contra_models.blend` and exports the GLBs into the pack's `models/`. |
| `contra_enemies.py` | The enemy and prop models: `pod`, `rock_ledge`, `flame`, `gunner`, `cart`, `saucer`, `scorpion`, `boulder`, `arm_ball`, `arm_claw`. Drawn in a live Blender through Blender MCP (the script builds into its own scene there, for `look`); the same script rebuilds and exports them headless (`blender -b --python contra_enemies.py`), saving `blend/contra_enemies.blend`. |
| `analysis/gen_pack.py` | `pack.json`: scenes, tile rules, groups, models table, effects. Starts from `base_pack_010.json` (the hand-made stage 1 rules of version 0.1.0). |
| `analysis/classify.py`, `coll.py` | Tile roles from the game's collision table in RAM (`0x680`, 2 bits per 16x16 cell: 1 floor, 2 water, 3 solid). |
| `analysis/player_groups.py`, `poses.py` | Player pose groups: sprites around the player's position (`ram[0x334]`, `ram[0x31a]`), named by the inputs held in the pose session (`inputs/poses.txt`). |
| `analysis/soldier_groups.py`, `soldier_emit.py` | Soldier groups from the enemy table (type `0x528+slot`, x `0x33e+slot`, y `0x324+slot`; type 5 runner, 6 rifleman). |
| `analysis/enemy_types.py`, `enemy_emit.py` | Groups for the enemy and prop models, from the enemy table per stage and type (pod 3; stage 3: rock ledge 16, flame 17, boulder 18/19, boss arm 21; gunner 14; stage 7 cart 20/21; stage 5 saucer 21; stage 8 scorpion 20/21). |
| `analysis/cap.py`, `seg.sh`, `climb.py` | Capture helpers: warp to stage L screen N (poke `0x30`, `0x64` from power-on), the waterfall climbing bot. |

The analysis scripts read scene dumps captured with `luxo3d capture`; their paths point at
the folder they were run in (a scratch folder), so set the paths before rerunning. Dumps
hold the game's art and are not kept here.

Models are original designs that fill each sprite's role (`tools/luxo3d/MODELS.md`).
