"""Reduce the saved model .blend files to their own Luxo scene.

build_models.py runs inside the person's live Blender, so `save_as_mainfile`
copies every scene in that file.  This script opens each model .blend, keeps
the `Luxo_*` scene, drops the person's scene and every linked library, purges
orphans and saves it again.  Run it once after building:

    blender -b --factory-startup --python clean_blends.py
"""

import glob
import os

import bpy

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else \
    "/home/kienct/luxo-tools/my-packs/jackal-nes/sources"


def purge():
    for coll in (bpy.data.objects, bpy.data.meshes, bpy.data.materials,
                 bpy.data.images, bpy.data.cameras, bpy.data.lights,
                 bpy.data.worlds, bpy.data.node_groups, bpy.data.collections):
        for idb in list(coll):
            if idb.users == 0:
                coll.remove(idb)


def clean(path):
    bpy.ops.wm.open_mainfile(filepath=path, load_ui=False, use_scripts=False)
    keep = next((s for s in bpy.data.scenes if s.name.startswith("Luxo_")), None)
    if keep is None:
        raise RuntimeError("no Luxo scene in " + path)
    for s in list(bpy.data.scenes):
        if s is not keep:
            bpy.data.scenes.remove(s)
    # Everything outside the kept scene's collection is no longer needed.
    keep_objects = set(keep.collection.all_objects)
    for ob in list(bpy.data.objects):
        if ob not in keep_objects:
            bpy.data.objects.remove(ob, do_unlink=True)
    # Linked libraries can run code when the file is opened; drop them.
    for name in [l.name for l in bpy.data.libraries]:
        lib = bpy.data.libraries.get(name)
        if lib is not None:
            bpy.data.libraries.remove(lib)
    for _ in range(4):
        purge()
    if bpy.context.window is not None:
        bpy.context.window.scene = keep
    bpy.ops.wm.save_as_mainfile(filepath=path)
    print("cleaned %s: scenes %s, objects %d, texts %d, libraries %d" % (
        path, [s.name for s in bpy.data.scenes], len(bpy.data.objects),
        len(bpy.data.texts), len(bpy.data.libraries)))


def main():
    for path in sorted(glob.glob(os.path.join(HERE, "blend", "*.blend"))):
        clean(path)


if __name__ == "__main__":
    main()
