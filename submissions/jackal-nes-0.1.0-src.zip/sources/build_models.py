"""Jackal 3D pack: rebuild every model from scratch.

Run inside Blender (the live session, or `blender -b --python build_models.py`).
Each model is built in a scene of its own at 1 Blender unit = 1 game pixel,
Z up, facing -Y (front view), and saved as its own .blend in ./blend/.
Export with tools/luxo3d/blender_export.py; see README.md.

The designs are original: a desert scout buggy (hero), a dune raider
(infantry), an iron-beetle light tank and a concrete gun emplacement.
They keep each sprite's role, size, silhouette and main colours.

Textures are generated here with numpy and packed into the .blend / GLB.
"""

import math
import os

import bmesh
import bpy
import numpy as np
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else \
    "/home/kienct/luxo-tools/my-packs/jackal-nes/sources"
N = 256


# ---------------------------------------------------------------------------
# scene / material helpers

def begin_model(name):
    """Build in a scene of its own, so the person's open scene is untouched."""
    sc = bpy.data.scenes.new("Luxo_" + name)
    bpy.context.window.scene = sc
    world = bpy.data.worlds.new("LuxoWorld_" + name)
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg is not None:
        bg.inputs[0].default_value = (0.15, 0.16, 0.18, 1)
        bg.inputs[1].default_value = 1.0
    sc.world = world
    sc.render.film_transparent = False
    return sc


def save_blend(name, sc):
    blend_dir = os.path.join(HERE, "blend")
    os.makedirs(blend_dir, exist_ok=True)
    path = os.path.join(blend_dir, name + ".blend")
    bpy.ops.wm.save_as_mainfile(filepath=path, copy=True)
    print("saved", path)


def close_model(sc):
    for o in list(sc.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.data.scenes.remove(sc)


def tri_count(sc=None):
    sc = sc or bpy.context.scene
    n = 0
    for o in sc.objects:
        if o.type == "MESH":
            o.data.calc_loop_triangles()
            n += len(o.data.loop_triangles)
    return n


def rgba_image(name, rgb):
    img = bpy.data.images.new(name, N, N, alpha=True)
    rgba = np.ones((N, N, 4), dtype=np.float32)
    rgba[..., :3] = np.clip(rgb, 0, 1)[::-1]
    img.pixels.foreach_set(rgba.ravel())
    img.file_format = "PNG"
    img.pack()
    return img


def make_mat(name, image, roughness=0.6, metallic=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = next(n for n in nodes if n.type == "BSDF_PRINCIPLED")
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = image
    tex.interpolation = "Linear"
    mat.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    return mat


def solid_mat(name, rgb, roughness=0.7, metallic=0.0):
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = rgb
    return make_mat(name, rgba_image(name + "_tex", img), roughness, metallic)


# ---------------------------------------------------------------------------
# texture painting

def _blur(a, r):
    out = a.copy()
    for _ in range(r):
        out = (out + np.roll(out, 1, 0) + np.roll(out, -1, 0)
               + np.roll(out, 1, 1) + np.roll(out, -1, 1)) / 5
    return out


def _noise(rng, scale):
    a = _blur(rng.random((N, N)), scale)
    a -= a.min()
    return a / max(a.max(), 1e-6)


def paint_texture(base, dirt, seed, star=False):
    """Weathered vehicle paint: dust, seams, rivets and optional white star."""
    rng = np.random.default_rng(seed)
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = base
    n = _noise(rng, 9)
    m = np.clip((n - 0.45) * 3.2, 0, 1)[..., None]
    img = img * (1 - 0.34 * m) + np.array(dirt) * 0.34 * m
    # scratches
    for _ in range(26):
        x, y = rng.integers(0, N, 2)
        ln = rng.integers(4, 26)
        horiz = rng.random() < 0.5
        for t in range(ln):
            xx = (x + t) % N if horiz else x
            yy = y if horiz else (y + t) % N
            img[yy, xx] *= 0.72
    # panel seams
    for y in (42, 128, 214):
        img[y:y + 2, :] *= 0.68
    for x in (42, 128, 214):
        img[:, x:x + 2] *= 0.68
    # rivets
    for y in range(18, N, 40):
        for x in range(18, N, 40):
            img[y:y + 3, x:x + 3] *= 1.22
    if star:
        yy, xx = np.mgrid[0:N, 0:N]
        cx = cy = N / 2
        ang = np.arctan2(yy - cy, xx - cx)
        rad = np.hypot(yy - cy, xx - cx)
        star_r = N * 0.22 * (0.55 + 0.45 * np.cos(5 * (ang - math.pi / 2)))
        mask = rad < star_r
        img[mask] = np.array((0.93, 0.93, 0.88))
    return np.clip(img, 0, 1)


def metal_texture(seed, base=(0.38, 0.40, 0.42)):
    rng = np.random.default_rng(seed)
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = base
    n = _noise(rng, 8)
    img *= (0.78 + 0.34 * n[..., None])
    for _ in range(40):
        x, y = rng.integers(0, N, 2)
        img[y:y + rng.integers(2, 12), x:x + 2] *= 0.6
    return np.clip(img, 0, 1)


def rubber_texture(seed):
    rng = np.random.default_rng(seed)
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = (0.075, 0.072, 0.068)
    n = _noise(rng, 6)
    img *= (0.75 + 0.45 * n[..., None])
    for y in range(0, N, 16):
        img[y:y + 5, :] *= 1.9
    return np.clip(img, 0, 1)


def cloth_texture(seed, base=(0.55, 0.48, 0.33), weave=0.10):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:N, 0:N]
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = base
    w = (np.sin(xx * math.pi / 2) * np.sin(yy * math.pi / 2)) * weave
    img *= (1.0 + w[..., None])
    n = _noise(rng, 7)
    img *= (0.85 + 0.28 * n[..., None])
    img *= (0.96 + 0.08 * rng.random((N, N, 1)))
    return np.clip(img, 0, 1)


def concrete_texture(seed):
    rng = np.random.default_rng(seed)
    img = np.zeros((N, N, 3), dtype=np.float32)
    img[:] = (0.60, 0.58, 0.53)
    n = _noise(rng, 10)
    img *= (0.66 + 0.55 * n[..., None])
    # gravel specks
    for _ in range(500):
        x, y = rng.integers(0, N, 2)
        img[y:y + 2, x:x + 2] *= rng.uniform(0.55, 1.4)
    # cracks
    for _ in range(14):
        x, y = rng.integers(0, N, 2)
        for t in range(rng.integers(10, 40)):
            x = (x + rng.integers(-1, 2)) % N
            y = (y + 1) % N
            img[y, x] = (0.22, 0.21, 0.19)
    return np.clip(img, 0, 1)


# ---------------------------------------------------------------------------
# geometry helpers

def box(name, size, loc, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return o


def cyl(name, r, depth, loc, rot=(0, 0, 0), verts=20, r2=None):
    if r2 is None:
        bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=r, depth=depth,
                                            location=loc, rotation=rot)
    else:
        bpy.ops.mesh.primitive_cone_add(vertices=verts, radius1=r, radius2=r2,
                                        depth=depth, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    return o


def sphere(name, r, loc, segs=18, rings=10):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segs, ring_count=rings, radius=r, location=loc)
    o = bpy.context.active_object
    o.name = name
    return o


def box_map(obj, density):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    uv = bm.loops.layers.uv.verify()
    for f in bm.faces:
        n = f.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        a, b = [(1, 2), (0, 2), (0, 1)][ax]
        for loop in f.loops:
            co = loop.vert.co
            loop[uv].uv = (co[a] * density, co[b] * density)
    bm.transform(obj.matrix_world.inverted())
    bm.to_mesh(obj.data)
    bm.free()


def finish(obj, mat, density, bevel=0.0, segments=2, smooth=False):
    obj.data.materials.append(mat)
    if bevel > 0:
        m = obj.modifiers.new("bevel", "BEVEL")
        m.width = bevel
        m.segments = segments
        m.limit_method = "ANGLE"
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(modifier=m.name)
    box_map(obj, density)
    if smooth:
        for p in obj.data.polygons:
            p.use_smooth = True
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        for e in bm.edges:
            if len(e.link_faces) == 2:
                try:
                    if e.calc_face_angle() > math.radians(38):
                        e.smooth = False
                except ValueError:
                    pass
        bm.to_mesh(obj.data)
        bm.free()
    return obj


def taper(obj, ztop, fx, fy):
    """Taper vertices above a world-space height."""
    zloc = obj.location.z
    for v in obj.data.vertices:
        if v.co.z + zloc > ztop - 1e-4:
            v.co.x *= fx
            v.co.y *= fy


def slope_front(obj, zmin, dy):
    """Slope the front (local -Y) top edge back, by world-space height."""
    zloc = obj.location.z
    for v in obj.data.vertices:
        if v.co.z + zloc > zmin and v.co.y < 0:
            v.co.y += dy


def star_mesh(name, r, loc):
    """A flat five-point star, slightly extruded."""
    verts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * 0.42
        verts.append((rr * math.cos(a), rr * math.sin(a), 0))
    bm = bmesh.new()
    vs = [bm.verts.new(v) for v in verts]
    f = bm.faces.new(vs)
    bmesh.ops.triangulate(bm, faces=[f])
    # give it a tiny thickness
    ret = bmesh.ops.extrude_face_region(bm, geom=list(bm.faces))
    for v in [e for e in ret["geom"] if isinstance(e, bmesh.types.BMVert)]:
        v.co.z += 0.12
    bm.to_mesh(bpy.data.meshes.new(name))
    me = bpy.data.meshes.new(name + "_me")
    bm.to_mesh(me)
    bm.free()
    o = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(o)
    o.location = loc
    return o



def spin(objects, degrees, pivot=(0, 0, 0)):
    """Rotate objects about a vertical pivot, to cant a turret."""
    from mathutils import Matrix
    M = Matrix.Rotation(math.radians(degrees), 4, "Z")
    p = Vector(pivot)
    T = Matrix.Translation(p) @ M @ Matrix.Translation(-p)
    for o in objects:
        o.matrix_world = T @ o.matrix_world


def camera_and_lights(name):
    """A camera that frames every mesh, from the top-view game direction."""
    sc = bpy.context.scene
    lo = [1e30, 1e30, 1e30]
    hi = [-1e30, -1e30, -1e30]
    for o in sc.objects:
        if o.type != "MESH":
            continue
        for corner in o.bound_box:
            w = o.matrix_world @ Vector(corner)
            for k in range(3):
                lo[k] = min(lo[k], w[k])
                hi[k] = max(hi[k], w[k])
    center = Vector(((lo[0] + hi[0]) / 2,
                                             (lo[1] + hi[1]) / 2,
                                             (lo[2] + hi[2]) / 2))
    size = max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2], 4.0)
    # top view looks down at 58 degrees: from -Y and above
    d = Vector((0, -0.53, 0.85)).normalized()
    cam_loc = center + d * size * 2.1
    bpy.ops.object.camera_add(location=cam_loc)
    cam = bpy.context.active_object
    cam.name = name + "_cam"
    cam.data.lens = 50
    cam.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
    sc.camera = cam
    bpy.ops.object.light_add(type="SUN", location=(-14, -18, 30),
                             rotation=(math.radians(42), math.radians(10), math.radians(-32)))
    bpy.context.active_object.data.energy = 4.0
    bpy.ops.object.light_add(type="AREA", location=(16, 14, 20),
                             rotation=(math.radians(40), 0, math.radians(140)))
    bpy.context.active_object.data.energy = 420
    bpy.context.active_object.data.size = 22
    sc.render.resolution_x = 640
    sc.render.resolution_y = 640
    try:
        sc.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        sc.render.engine = "BLENDER_EEVEE"


# ---------------------------------------------------------------------------
# hero: desert scout buggy (24 long x 16 wide, front at -Y)

def build_hero():
    sc = begin_model("hero_jeep")
    paint = make_mat("jeep_paint", rgba_image("jeep_paint", paint_texture(
        (0.10, 0.42, 0.07), (0.45, 0.38, 0.20), 7711)), 0.62, 0.05)
    metal = make_mat("jeep_metal", rgba_image("jeep_metal", metal_texture(7712)), 0.38, 0.72)
    rubber = make_mat("jeep_rubber", rgba_image("jeep_rubber", rubber_texture(7713)), 0.88, 0.0)
    canvas = make_mat("jeep_canvas", rgba_image("jeep_canvas", cloth_texture(
        7714, (0.42, 0.36, 0.23))), 0.82, 0.0)
    glass = solid_mat("jeep_glass", (0.66, 0.78, 0.80), 0.16, 0.0)
    white = solid_mat("jeep_white", (0.92, 0.92, 0.86), 0.55, 0.0)
    lamp = solid_mat("jeep_lamp", (1.0, 0.92, 0.62), 0.25, 0.0)
    skin = solid_mat("jeep_skin", (0.72, 0.52, 0.36), 0.7, 0.0)

    D_P, D_M, D_R, D_C = 1 / 6.0, 1 / 3.0, 1 / 3.0, 1 / 2.5

    # wheels
    for sx in (-1, 1):
        for sy, nm in ((-7.2, "front"), (7.2, "rear")):
            w = cyl("wheel_%s_%d" % (nm, sx), 2.35, 1.9, (sx * 7.05, sy, 2.35),
                    rot=(0, math.pi / 2, 0), verts=20)
            finish(w, rubber, D_R, bevel=0.45, segments=3, smooth=True)
            hub = cyl("hub_%s_%d" % (nm, sx), 1.05, 1.98, (sx * 7.05, sy, 2.35),
                      rot=(0, math.pi / 2, 0), verts=14)
            finish(hub, metal, D_M, bevel=0.15, segments=2)

    # chassis and body
    ch = box("chassis", (12.4, 21.0, 2.2), (0, 0, 3.5))
    finish(ch, paint, D_P, bevel=0.55, segments=3, smooth=True)
    hood = box("hood", (11.0, 7.2, 2.0), (0, -6.4, 5.6))
    finish(hood, paint, D_P, bevel=0.5, segments=3, smooth=True)
    slope_front(hood, 6.0, 0.9)
    grille = box("grille", (8.6, 0.6, 1.5), (0, -10.0, 5.3))
    finish(grille, metal, D_M, bevel=0.12)
    for sx in (-1, 1):
        hl = cyl("headlight_%d" % sx, 0.75, 0.5, (sx * 3.8, -10.15, 5.6),
                 rot=(math.pi / 2, 0, 0), verts=14)
        finish(hl, lamp, 0.4, bevel=0.12, smooth=True)
    bumper = box("bumper", (12.2, 1.0, 1.1), (0, -11.15, 3.6))
    finish(bumper, metal, D_M, bevel=0.16)
    winch = cyl("winch", 1.0, 4.2, (0, -11.3, 4.5), rot=(0, math.pi / 2, 0), verts=14)
    finish(winch, metal, D_M, bevel=0.12)

    # fenders and side steps
    for sx in (-1, 1):
        f = box("fender_%d" % sx, (2.6, 19.6, 0.7), (sx * 6.6, 0, 4.9))
        finish(f, paint, D_P, bevel=0.24, segments=2)
        step = box("step_%d" % sx, (1.5, 5.0, 0.4), (sx * 6.9, 0.5, 3.2))
        finish(step, metal, D_M, bevel=0.1)

    # cockpit tub
    for sx in (-1, 1):
        side = box("cockpit_side_%d" % sx, (1.1, 8.6, 2.6), (sx * 5.3, 0.9, 5.9))
        finish(side, paint, D_P, bevel=0.2)
    rear = box("cockpit_rear", (10.0, 1.1, 2.6), (0, 5.1, 5.9))
    finish(rear, paint, D_P, bevel=0.2)
    dash = box("dash", (10.2, 1.0, 1.8), (0, -3.3, 6.3))
    finish(dash, paint, D_P, bevel=0.18)

    # seats
    for sx, nm in ((-2.5, "driver"), (2.5, "gunner")):
        seat = box("seat_" + nm, (3.4, 3.0, 1.0), (sx, 0.9, 6.6))
        finish(seat, canvas, D_C, bevel=0.28, segments=3, smooth=True)
        back = box("seatback_" + nm, (3.4, 0.8, 3.0), (sx, 2.7, 8.0),
                   rot=(math.radians(-10), 0, 0))
        finish(back, canvas, D_C, bevel=0.25, segments=3, smooth=True)

    # roll cage
    for sx in (-1, 1):
        for sy in (-3.9, 3.9):
            post = cyl("cage_post_%d_%d" % (sx, sy), 0.22, 6.0,
                       (sx * 5.4, sy, 9.6), verts=10)
            finish(post, metal, D_M, bevel=0.08, smooth=True)
    for sy in (-3.9, 3.9):
        rail = cyl("cage_rail_%d" % sy, 0.22, 11.2, (0, sy, 12.55),
                   rot=(0, math.pi / 2, 0), verts=10)
        finish(rail, metal, D_M, bevel=0.08, smooth=True)

    # folded windshield
    frame = box("windshield_frame", (10.0, 0.45, 0.55), (0, -3.55, 11.7),
                rot=(math.radians(24), 0, 0))
    finish(frame, white, D_M, bevel=0.1)
    pane = box("windshield", (9.2, 0.16, 2.2), (0, -3.35, 9.9),
               rot=(math.radians(24), 0, 0))
    finish(pane, glass, 0.5, bevel=0.12)
    for sx in (-1, 1):
        post = cyl("windshield_post_%d" % sx, 0.18, 3.4, (sx * 4.9, -3.4, 10.1),
                   rot=(math.radians(24), 0, 0), verts=8)
        finish(post, metal, D_M, bevel=0.05)

    # pintle gun, right seat
    post = cyl("gun_post", 0.5, 3.2, (2.5, -1.2, 8.4), verts=12)
    finish(post, metal, D_M, bevel=0.1, smooth=True)
    cradle = box("gun_cradle", (1.6, 1.4, 1.0), (2.5, -1.2, 10.1))
    finish(cradle, metal, D_M, bevel=0.18)
    body = box("gun_body", (1.3, 4.6, 1.35), (2.5, -3.4, 10.25))
    finish(body, metal, D_M, bevel=0.16, smooth=True)
    barrel = cyl("gun_barrel", 0.24, 7.0, (2.5, -8.8, 10.3), rot=(math.pi / 2, 0, 0), verts=10)
    finish(barrel, metal, D_M, bevel=0.04, smooth=True)
    muzzle = cyl("gun_muzzle", 0.42, 1.1, (2.5, -12.4, 10.3), rot=(math.pi / 2, 0, 0), verts=10)
    finish(muzzle, metal, D_M, bevel=0.06, smooth=True)
    ammo = box("ammo_box", (1.5, 1.8, 1.2), (0.8, -1.7, 9.35))
    finish(ammo, paint, D_P, bevel=0.16)

    # rear cargo: spare wheel, cans, tarp
    spare = cyl("spare", 2.2, 1.5, (0, 11.0, 5.9), rot=(math.pi / 2, 0, 0), verts=20)
    finish(spare, rubber, D_R, bevel=0.4, segments=3, smooth=True)
    for sx in (-1, 1):
        can = box("jerrycan_%d" % sx, (1.5, 1.2, 2.7), (sx * 4.4, 9.7, 5.8))
        finish(can, paint, D_P, bevel=0.18)
        cap = cyl("jerrycap_%d" % sx, 0.28, 0.4, (sx * 4.4, 9.7, 7.3), verts=8)
        finish(cap, metal, D_M, bevel=0.05)
    roll = cyl("tarp", 1.15, 7.0, (0, 8.0, 7.4), rot=(0, math.pi / 2, 0), verts=12)
    finish(roll, canvas, D_C, bevel=0.25, smooth=True)
    rear_b = box("rear_bumper", (11.8, 0.8, 0.9), (0, 10.9, 3.7))
    finish(rear_b, metal, D_M, bevel=0.14)

    # antenna and exhaust
    ant = cyl("antenna", 0.11, 11.0, (-5.0, 8.8, 9.5), verts=6)
    finish(ant, metal, D_M)
    tip = sphere("antenna_tip", 0.24, (-5.0, 8.8, 15.0), segs=8, rings=6)
    finish(tip, white, 0.4)
    exh = cyl("exhaust", 0.38, 3.0, (-5.9, 6.4, 3.3), rot=(0, math.pi / 2, 0), verts=8)
    finish(exh, metal, D_M, bevel=0.06)

    # hood star (white marking)
    st = star_mesh("hood_star", 2.2, (0, -6.4, 6.62))
    finish(st, white, 0.4)

    # driver silhouette: helmet and shoulders (adds life from above)
    helm = sphere("driver_helmet", 1.5, (-2.5, 0.6, 8.6), segs=14, rings=8)
    finish(helm, paint, D_P, bevel=0.2, smooth=True)
    shoulders = box("driver_shoulders", (3.3, 2.3, 1.2), (-2.5, 0.4, 7.7))
    finish(shoulders, canvas, D_C, bevel=0.3, smooth=True)
    gunner = sphere("gunner_helmet", 1.4, (2.5, 0.6, 8.5), segs=14, rings=8)
    finish(gunner, paint, D_P, bevel=0.2, smooth=True)
    skinpatch = sphere("driver_face", 0.8, (-2.5, -0.35, 8.7), segs=10, rings=6)
    finish(skinpatch, skin, 0.4)

    camera_and_lights("hero")
    print("hero_jeep triangles", tri_count(sc))
    save_blend("hero_jeep", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# infantry: dune raider (8 wide x 16 tall, front at -Y)

def build_raider():
    sc = begin_model("raider")
    uniform = make_mat("raider_uniform", rgba_image("raider_uniform", cloth_texture(
        7811, (0.66, 0.34, 0.10), 0.12)), 0.86, 0.0)
    webbing = make_mat("raider_webbing", rgba_image("raider_webbing", cloth_texture(
        7812, (0.82, 0.80, 0.70), 0.08)), 0.8, 0.0)
    leather = make_mat("raider_leather", rgba_image("raider_leather", cloth_texture(
        7813, (0.18, 0.13, 0.09), 0.05)), 0.72, 0.0)
    metal = make_mat("raider_metal", rgba_image("raider_metal", metal_texture(7814)), 0.35, 0.7)
    scarf = make_mat("raider_scarf", rgba_image("raider_scarf", cloth_texture(
        7815, (0.62, 0.10, 0.07), 0.16)), 0.85, 0.0)
    skin = solid_mat("raider_skin", (0.66, 0.45, 0.29), 0.72, 0.0)
    helmmat = make_mat("raider_helmet", rgba_image("raider_helmet", cloth_texture(
        7816, (0.26, 0.23, 0.12), 0.1)), 0.78, 0.0)
    wood = solid_mat("raider_wood", (0.34, 0.20, 0.10), 0.7, 0.0)

    D_U, D_W, D_L, D_M = 1 / 2.5, 1 / 2.0, 1 / 2.0, 1 / 2.0

    # legs and boots
    for sx in (-1, 1):
        leg = box("leg_%d" % sx, (2.0, 2.4, 6.8), (sx * 1.7, 0.2, 5.0))
        finish(leg, uniform, D_U, bevel=0.45, segments=3, smooth=True)
        boot = box("boot_%d" % sx, (2.3, 3.4, 2.0), (sx * 1.7, -0.4, 1.0))
        finish(boot, leather, D_L, bevel=0.4, segments=3, smooth=True)
        knee = box("knee_%d" % sx, (2.1, 1.4, 1.3), (sx * 1.7, -1.0, 6.2))
        finish(knee, webbing, D_W, bevel=0.25)

    # torso, belt, chest rig
    torso = box("torso", (6.0, 3.8, 7.0), (0, 0, 11.0))
    finish(torso, uniform, D_U, bevel=0.7, segments=3, smooth=True)
    taper(torso, 13.9, 0.82, 0.82)
    belt = box("belt", (6.2, 4.0, 0.8), (0, 0, 8.0))
    finish(belt, leather, D_L, bevel=0.18)
    buckle = box("buckle", (1.0, 0.25, 0.6), (0, -2.05, 8.0))
    finish(buckle, metal, D_M, bevel=0.08)
    rig = box("chest_rig", (5.4, 0.8, 3.4), (0, -1.95, 11.6))
    finish(rig, webbing, D_W, bevel=0.2)
    for i, sx in enumerate((-1.6, 0, 1.6)):
        pouch = box("pouch_%d" % i, (1.3, 0.7, 1.6), (sx, -2.35, 11.0))
        finish(pouch, leather, D_L, bevel=0.18)

    # backpack and bedroll
    pack = box("backpack", (4.6, 2.2, 4.2), (0, 2.4, 11.2))
    finish(pack, webbing, D_W, bevel=0.45, segments=3, smooth=True)
    bed = cyl("bedroll", 1.0, 4.8, (0, 2.3, 13.7), rot=(0, math.pi / 2, 0), verts=12)
    finish(bed, uniform, D_U, bevel=0.2, smooth=True)

    # shoulders, arms, hands
    for sx in (-1, 1):
        sh = sphere("shoulder_%d" % sx, 1.5, (sx * 3.2, 0, 13.4), segs=12, rings=8)
        finish(sh, uniform, D_U, bevel=0.2, smooth=True)
    # arms reach down and across to the rifle
    upper = cyl("arm_r", 1.05, 4.4, (3.3, -1.6, 11.9), rot=(math.radians(38), 0, math.radians(14)), verts=10)
    finish(upper, uniform, D_U, bevel=0.2, smooth=True)
    handr = sphere("hand_r", 0.95, (2.3, -2.9, 10.5), segs=10, rings=6)
    finish(handr, skin, 0.5)
    upper2 = cyl("arm_l", 1.0, 4.4, (-3.3, -1.4, 11.9), rot=(math.radians(36), 0, math.radians(-12)), verts=10)
    finish(upper2, uniform, D_U, bevel=0.2, smooth=True)
    handl = sphere("hand_l", 0.9, (-2.4, -2.9, 10.5), segs=10, rings=6)
    finish(handl, skin, 0.5)

    # head: neck, scarf, face, helmet with brim
    neck = cyl("neck", 0.9, 1.4, (0, 0, 14.7), verts=10)
    finish(neck, skin, 0.5)
    scarfm = cyl("scarf", 2.25, 1.1, (0, 0, 15.0), verts=14)
    finish(scarfm, scarf, 0.5, bevel=0.35, segments=3, smooth=True)
    head = sphere("head", 2.0, (0, -0.7, 16.2), segs=16, rings=10)
    finish(head, skin, 0.5, smooth=True)
    # tilt the face up to the camera by flattening the back of the skull
    for v in head.data.vertices:
        if v.co.y > 0:
            v.co.z -= 0.35
    helm = sphere("helmet", 2.35, (0, 0.10, 17.35), segs=16, rings=10)
    # keep only the dome above the head
    bm = bmesh.new()
    bm.from_mesh(helm.data)
    bmesh.ops.bisect_plane(bm, geom=list(bm.verts) + list(bm.edges) + list(bm.faces),
                           plane_co=(0, 0, 0), plane_no=(0, 0, 1), clear_inner=True)
    bm.to_mesh(helm.data)
    bm.free()
    finish(helm, helmmat, 0.5, bevel=0.12, smooth=True)
    brim = cyl("helmet_brim", 2.75, 0.35, (0, 0.1, 17.15), verts=18)
    finish(brim, helmmat, 0.5, bevel=0.12, smooth=True)
    for ob in (helm, brim):
        ob.rotation_euler.x = math.radians(-16)
    hband = cyl("helmet_band", 2.42, 0.38, (0, 0.10, 17.30), verts=18)
    finish(hband, webbing, 0.5, bevel=0.06)
    hband.rotation_euler.x = math.radians(-16)
    # white shoulder pads read from the game camera
    for sx in (-1, 1):
        pad = box("shoulder_pad_%d" % sx, (1.9, 2.2, 0.45), (sx * 3.35, -0.15, 14.75))
        finish(pad, webbing, D_W, bevel=0.25, segments=3, smooth=True)
    # eyes / face shadow
    for sx in (-1, 1):
        eye = sphere("eye_%d" % sx, 0.22, (sx * 0.65, -1.9, 16.5), segs=8, rings=6)
        finish(eye, leather, 0.6)

    # rifle held across the chest, as the sprite's white bar reads
    stock = box("rifle_stock", (3.3, 0.85, 0.95), (-4.4, -2.9, 10.1))
    finish(stock, wood, D_M, bevel=0.16)
    body = box("rifle_body", (4.2, 0.8, 0.85), (-1.0, -2.9, 10.15))
    finish(body, metal, D_M, bevel=0.12)
    barrel = cyl("rifle_barrel", 0.2, 3.4, (4.3, -2.9, 10.2), rot=(0, math.pi / 2, 0), verts=8)
    finish(barrel, metal, D_M, bevel=0.03, smooth=True)
    mag = box("rifle_mag", (0.6, 0.9, 1.9), (-0.6, -2.9, 9.15), rot=(math.radians(12), 0, 0))
    finish(mag, metal, D_M, bevel=0.1)
    sight = box("rifle_sight", (0.5, 0.55, 0.5), (0.6, -2.9, 10.75))
    finish(sight, metal, D_M, bevel=0.06)

    camera_and_lights("raider")
    print("raider triangles", tri_count(sc))
    save_blend("raider", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# enemy tank: iron beetle (16 wide x 24 long, front at -Y)

def build_tank():
    sc = begin_model("enemy_tank")
    armor = make_mat("tank_armor", rgba_image("tank_armor", paint_texture(
        (0.44, 0.45, 0.41), (0.58, 0.46, 0.30), 7911)), 0.58, 0.25)
    steel = make_mat("tank_steel", rgba_image("tank_steel", metal_texture(
        7912, (0.24, 0.25, 0.26))), 0.4, 0.75)
    track = make_mat("tank_track", rgba_image("tank_track", rubber_texture(7913)), 0.72, 0.25)
    canvas = make_mat("tank_canvas", rgba_image("tank_canvas", cloth_texture(
        7914, (0.36, 0.33, 0.22))), 0.85, 0.0)
    white = solid_mat("tank_white", (0.90, 0.90, 0.84), 0.5, 0.0)
    turret_armor = make_mat("tank_turret", rgba_image("tank_turret", paint_texture(
        (0.52, 0.53, 0.48), (0.60, 0.48, 0.30), 7915)), 0.55, 0.2)
    lamp = solid_mat("tank_lamp", (0.95, 0.85, 0.55), 0.3, 0.0)
    gun = solid_mat("tank_gun", (0.10, 0.10, 0.11), 0.5, 0.2)

    D_A, D_S, D_T, D_C = 1 / 5.0, 1 / 3.0, 1 / 3.0, 1 / 2.5

    # tracks
    for sx in (-1, 1):
        band = box("track_%d" % sx, (3.4, 21.4, 3.6), (sx * 6.3, 0, 2.6))
        finish(band, track, D_T, bevel=0.7, segments=3, smooth=True)
        for i in range(6):
            wheel = cyl("roadwheel_%d_%d" % (sx, i), 1.55, 0.8,
                        (sx * 7.65, -8.2 + i * 3.3, 2.2), rot=(0, math.pi / 2, 0), verts=14)
            finish(wheel, steel, D_S, bevel=0.15, smooth=True)
        for i in range(8):
            link = box("tread_%d_%d" % (sx, i), (0.5, 1.8, 3.4),
                       (sx * 8.05, -8.8 + i * 2.5, 2.5))
            finish(link, steel, D_S, bevel=0.1)
        skirt = box("skirt_%d" % sx, (0.7, 19.6, 3.0), (sx * 6.7, 0, 4.7))
        finish(skirt, armor, D_A, bevel=0.2)

    # lower hull and glacis
    hull = box("hull", (11.6, 20.2, 3.2), (0, 0, 4.2))
    finish(hull, armor, D_A, bevel=0.6, segments=3, smooth=True)
    glacis = box("glacis", (10.6, 7.0, 2.6), (0, -8.6, 5.9))
    finish(glacis, armor, D_A, bevel=0.45, segments=3, smooth=True)
    slope_front(glacis, 5.0, 1.6)
    deck = box("rear_deck", (10.8, 6.8, 1.8), (0, 7.4, 6.2))
    finish(deck, armor, D_A, bevel=0.4, segments=3, smooth=True)
    for sx in (-1, 1):
        fender = box("track_fender_%d" % sx, (2.6, 20.4, 0.55), (sx * 6.1, 0, 6.7))
        finish(fender, armor, D_A, bevel=0.18)

    # hull details: headlights, driver hatch, exhausts
    for sx in (-1, 1):
        hl = cyl("tank_light_%d" % sx, 0.65, 0.4, (sx * 3.9, -10.4, 6.4),
                 rot=(math.pi / 2, 0, 0), verts=12)
        finish(hl, lamp, 0.4, bevel=0.1, smooth=True)
    hatch = cyl("driver_hatch", 1.8, 0.5, (-2.3, -5.4, 7.5), verts=12)
    finish(hatch, armor, D_A, bevel=0.2, smooth=True)
    for sx in (-1, 1):
        ex = cyl("exhaust_%d" % sx, 0.55, 2.2, (sx * 3.6, 10.2, 6.6),
                 rot=(math.pi / 2, 0, 0), verts=10)
        finish(ex, steel, D_S, bevel=0.08, smooth=True)

    # turret: octagonal, mantlet and long gun
    tur = cyl("turret", 5.4, 5.6, (0, -0.6, 10.2), verts=8)
    finish(tur, turret_armor, D_A, bevel=0.8, segments=3, smooth=True)
    roof = cyl("turret_roof", 4.4, 0.5, (0, -0.6, 13.05), verts=8)
    finish(roof, turret_armor, D_A, bevel=0.2, smooth=True)
    band = cyl("turret_band", 5.5, 0.45, (0, -0.6, 12.2), verts=8)
    finish(band, white, 0.5)
    cupola = cyl("cupola", 1.8, 1.6, (1.9, 0.8, 13.55), verts=12)
    finish(cupola, steel, D_S, bevel=0.25, smooth=True)
    hatch2 = cyl("cupola_hatch", 1.55, 0.35, (1.9, 0.8, 14.45), verts=12)
    finish(hatch2, armor, D_A, bevel=0.12)
    mantlet = box("mantlet", (3.6, 2.0, 2.8), (0, -5.4, 10.4))
    finish(mantlet, turret_armor, D_A, bevel=0.4, segments=3, smooth=True)
    barrel = cyl("cannon", 0.95, 11.0, (0, -11.2, 11.6), rot=(math.radians(70), 0, 0), verts=14)
    finish(barrel, gun, D_S, bevel=0.12, smooth=True)
    brake = cyl("muzzle_brake", 1.3, 1.7, (0, -16.4, 13.0), rot=(math.radians(70), 0, 0), verts=10)
    finish(brake, white, 0.5, bevel=0.15, smooth=True)
    stripe = cyl("barrel_stripe", 1.02, 0.6, (0, -15.2, 12.5), rot=(math.radians(70), 0, 0), verts=12)
    finish(stripe, white, 0.5)
    mg = cyl("coax_mg", 0.2, 3.6, (2.4, -8.0, 9.4), rot=(math.pi / 2, 0, 0), verts=8)
    finish(mg, steel, D_S, bevel=0.04)

    # white recognition bars on the hull top
    for sx in (-1, 1):
        wb = box("hull_stripe_%d" % sx, (1.2, 3.6, 0.16), (sx * 3.0, -7.8, 7.85))
        finish(wb, white, 0.6)
    # white recognition chevrons on the turret sides
    for sx in (-1, 1):
        ch = box("chevron_%d" % sx, (0.16, 4.6, 0.8), (sx * 5.25, -0.6, 10.4),
                 rot=(0, 0, math.radians(28)))
        finish(ch, white, 0.6)

    # stowage
    can = box("jerrycan", (1.5, 1.2, 2.7), (-4.0, 9.6, 7.4))
    finish(can, canvas, D_C, bevel=0.18)
    roll = cyl("tarp_roll", 1.2, 6.0, (1.8, 8.6, 7.6), rot=(0, math.pi / 2, 0), verts=12)
    finish(roll, canvas, D_C, bevel=0.25, smooth=True)
    boxx = box("stow_box", (3.0, 2.4, 1.8), (-3.0, 7.6, 7.6))
    finish(boxx, armor, D_A, bevel=0.25)
    ant = cyl("tank_antenna", 0.09, 8.0, (-4.4, 4.8, 9.0), verts=6)
    finish(ant, steel, D_S)

    parts = [bpy.data.objects[n] for n in (
        "turret", "turret_roof", "turret_band", "cupola", "cupola_hatch", "mantlet",
        "cannon", "muzzle_brake", "barrel_stripe", "coax_mg", "chevron_-1", "chevron_1")]
    spin(parts, -28, (0, -0.6, 0))
    camera_and_lights("tank")
    print("enemy_tank triangles", tri_count(sc))
    save_blend("enemy_tank", sc)
    close_model(sc)


# ---------------------------------------------------------------------------
# gun turret: concrete emplacement (24 wide x 20 deep, front at -Y)

def build_turret():
    sc = begin_model("gun_turret")
    concrete = make_mat("turret_concrete", rgba_image("turret_concrete", concrete_texture(8111)), 0.9, 0.0)
    steel = make_mat("turret_steel", rgba_image("turret_steel", metal_texture(
        8112, (0.36, 0.37, 0.38))), 0.52, 0.25)
    sandbag = make_mat("turret_sandbag", rgba_image("turret_sandbag", cloth_texture(
        8113, (0.66, 0.58, 0.40), 0.14)), 0.92, 0.0)
    white = solid_mat("turret_white", (0.88, 0.87, 0.80), 0.6, 0.0)
    red = solid_mat("turret_red", (0.58, 0.12, 0.08), 0.7, 0.0)
    gun = solid_mat("turret_gun", (0.55, 0.56, 0.56), 0.5, 0.2)
    dark = solid_mat("turret_dark", (0.08, 0.08, 0.09), 0.55, 0.2)

    D_C, D_S, D_B = 1 / 5.0, 1 / 3.0, 1 / 2.5

    # octagonal concrete base, 24 x 20
    base = cyl("base", 11.0, 5.4, (0, 0, 2.7), verts=8)
    finish(base, concrete, D_C, bevel=0.7, segments=3, smooth=True)
    for v in base.data.vertices:
        v.co.y *= 0.86
    ring = cyl("ring", 8.4, 1.2, (0, 0, 5.8), verts=8)
    finish(ring, concrete, D_C, bevel=0.4, segments=2, smooth=True)
    for v in ring.data.vertices:
        v.co.y *= 0.88
    # entry step at the back
    step = box("step", (5.0, 2.2, 1.1), (0, 9.3, 1.1))
    finish(step, concrete, D_C, bevel=0.25)

    # sandbags around the front half
    import random
    rng = random.Random(8114)
    for i in range(9):
        a = math.radians(-160 + i * 20)
        x = 10.2 * math.sin(a)
        y = -8.8 * math.cos(a)
        sb = box("sandbag_%d" % i, (4.4, 3.0, 2.1), (x, y, 1.05),
                 rot=(0, 0, a))
        finish(sb, sandbag, D_B, bevel=0.9, segments=4, smooth=True)
    for i in range(7):
        a = math.radians(-150 + i * 22)
        x = 9.4 * math.sin(a)
        y = -8.0 * math.cos(a)
        sb = box("sandbag2_%d" % i, (4.0, 2.7, 1.9), (x, y, 2.8),
                 rot=(0, 0, a))
        finish(sb, sandbag, D_B, bevel=0.8, segments=4, smooth=True)

    # armored cupola
    cup = cyl("cupola", 5.2, 5.2, (0, -0.4, 8.4), verts=8)
    finish(cup, steel, D_S, bevel=0.8, segments=3, smooth=True)
    top = cyl("cupola_top", 4.6, 0.6, (0, -0.4, 11.2), verts=8)
    finish(top, steel, D_S, bevel=0.3, smooth=True)
    visor = box("visor", (6.0, 0.7, 1.2), (0, -4.9, 9.6))
    finish(visor, steel, D_S, bevel=0.18)
    # white painted band and red warning square
    band = cyl("band", 5.35, 0.5, (0, -0.4, 10.7), verts=8)
    finish(band, white, 0.5)
    warn = box("warn", (1.8, 1.8, 0.22), (-1.8, 0.6, 11.55))
    finish(warn, red, 0.5)

    # cannon and shield
    shield = box("shield", (7.4, 0.8, 5.2), (0, -5.6, 9.4),
                 rot=(math.radians(-8), 0, 0))
    finish(shield, steel, D_S, bevel=0.5, segments=3, smooth=True)
    barrel = cyl("cannon", 1.1, 13.0, (0, -11.4, 11.6), rot=(math.radians(70), 0, 0), verts=14)
    finish(barrel, gun, D_S, bevel=0.14, smooth=True)
    brake = cyl("muzzle", 1.45, 2.0, (0, -17.5, 13.7), rot=(math.radians(70), 0, 0), verts=10)
    finish(brake, dark, 0.5, bevel=0.18, smooth=True)
    mg = cyl("coax", 0.22, 4.0, (2.6, -8.4, 9.2), rot=(math.pi / 2, 0, 0), verts=8)
    finish(mg, steel, D_S, bevel=0.04)

    # roof hatch and periscope
    hatch = cyl("hatch", 1.7, 0.5, (-1.6, 1.2, 11.6), verts=12)
    finish(hatch, steel, D_S, bevel=0.2, smooth=True)
    peri = box("periscope", (0.9, 0.9, 1.1), (1.6, 1.0, 11.8))
    finish(peri, steel, D_S, bevel=0.12)
    ant = cyl("antenna", 0.08, 7.0, (-4.0, 3.0, 13.0), verts=6)
    finish(ant, steel, D_S)

    parts = [bpy.data.objects[n] for n in (
        "cupola", "cupola_top", "visor", "band", "warn", "shield", "cannon",
        "muzzle", "coax", "hatch", "periscope", "antenna")]
    spin(parts, -35, (0, -0.4, 0))
    camera_and_lights("turret")
    print("gun_turret triangles", tri_count(sc))
    save_blend("gun_turret", sc)
    close_model(sc)


# ---------------------------------------------------------------------------

def main():
    original = bpy.context.window.scene
    build_hero()
    build_raider()
    build_tank()
    build_turret()
    bpy.context.window.scene = original
    print("done")


if __name__ == "__main__":
    main()
