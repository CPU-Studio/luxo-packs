# Jackal: Beachhead in Depth — sources

This folder rebuilds every model in the pack from scratch. The pack's rules
live in `../pack.json`; the models are four original designs that fill each
sprite's role.

## Models

| model | role | size (w x h x d, game px) | triangles | textures |
|---|---|---|---|---|
| `hero_jeep` | player scout buggy | 16 x 15 x 25 | 10,188 | paint, metal, rubber, canvas, glass, white, lamp, skin |
| `raider` | enemy infantry | 12 x 20 x 7 | 5,776 | uniform, webbing, leather, metal, scarf, skin, helmet, wood |
| `enemy_tank` | enemy light tank | 17 x 14 x 27 | 8,328 | armour, turret paint, steel, track, canvas, white, lamp, gun |
| `gun_turret` | concrete gun emplacement | 23 x 16 x 29 | 7,372 | concrete, steel, sandbag, white, red, gun, dark |

All are original designs: a desert scout buggy with a white star and pintle
gun, a dune raider with a pith helmet and white webbing, an iron-beetle light
tank, and a sandbagged concrete gun nest. They keep each sprite's size,
silhouette, main colours and held items.

## Rebuild

Inside the running Blender (or any interactive Blender):

```python
exec(open("sources/build_models.py").read())
main()
```

`build_models.py` makes one scene per model and saves it in `sources/blend/`.
It builds in a scene of its own and restores the open scene afterwards.

When it runs in a busy Blender file, `save_as_mainfile` copies every scene in
the file.  Strip the other scenes and any linked libraries before sharing:

```sh
blender -b --factory-startup --python sources/clean_blends.py
```

Then export each model with the pack's exporter:

```sh
for m in hero_jeep raider enemy_tank gun_turret; do
  blender -b "sources/blend/$m.blend" --python tools/luxo3d/blender_export.py \
      -- --out "models/$m.glb"
done
```

The exporter applies transforms, puts the feet at the origin and checks the
20,000-triangle budget.  All models face -Y in Blender (the exporter turns
that into +Y up, facing +Z); one model serves every facing in the pack.

## Textures

Every texture is generated with numpy inside `build_models.py` and packed into
the .blend / GLB: weathered paint with dust and rivets, treaded rubber, woven
cloth, mottled concrete, scratched steel.  The white star on the jeep hood is
modelled geometry, not a decal.  No external image is used.

## Captures

`inputs/` holds the controller scripts used for the captures.  The dumps and
save states are work files outside the pack (`my-packs/_jackal-work/`).
Interesting states:

| state | shows |
|---|---|
| `title_last.state` | title / play select (flat) |
| `route_000400.state` | stage briefing (flat) |
| `continue_000300.state` | field start: coast, water, sand, first infantry |
| `level1b_000700.state` | palms, boulder, enemy infantry, jeep side-on |
| `combat_000900.state` | concrete gun turret and explosion |
| `combat_001200.state` | enemy tank, coastal wall, palm line |
| `poses2_000230.state` | explosion appears (effect check) |
| `poses2_000240.state` | explosion disappears |
| `level1d_002400.state` | continue screen (flat) |

The field was played through with `inputs/advance6k.txt` and
`inputs/long_drive.txt`; the four facings were checked with
`inputs/walk.txt` (every frame had the hero model).

## Checks

```sh
python3 tools/luxo3d/luxo3d_mcp.py call validate_pack '{"pack_dir":"my-packs/jackal-nes"}'
python3 tools/luxo3d/luxo3d_mcp.py call coverage \
  '{"pack":"my-packs/jackal-nes","dumps":"my-packs/_jackal-work/dumps"}'
```

Coverage on the field: 100% of background tiles have a rule and 100% are
handled; the remaining ungrouped sprites are HUD digits, bullets and the
cut-scene cast.

## Share

```sh
python3 tools/luxo3d/luxo3d_mcp.py call package_pack \
  '{"pack_dir":"my-packs/jackal-nes","out":"jackal-nes-0.1.0.zip"}'
python3 tools/luxo3d/pack_sources.py my-packs/jackal-nes \
  --out jackal-nes-0.1.0-src.zip
python3 tools/luxo3d/registry_check.py jackal-nes-0.1.0.zip \
  jackal-nes-0.1.0-src.zip --blender blender
```
