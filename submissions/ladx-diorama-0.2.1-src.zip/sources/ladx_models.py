"""Builds every model of the ladx-diorama pack (Link's Awakening DX, Game Boy Color).

All designs are original: characters fill the roles of the game's sprites (size, silhouette,
main colours, held items) without copying their art; scenery is generic (pots, beds, trees).

In the live Blender (Blender MCP):
    exec(open(".../sources/ladx/ladx_models.py").read()); build("hero")
Headless, one model per .blend:
    blender -b --python ladx_models.py -- --model hero --blend hero.blend
    blender -b hero.blend --python tools/luxo3d/blender_export.py -- --out hero.glb \
        --pivot hero_torso --animations

Convention: 1 unit = 1 game pixel, Z up, the model faces -Y, feet on Z = 0.
Characters: chunky, big-headed (the Game Boy sprites are 16x16), head tilted back so the
face reads from the 60-degree top camera.  Each has a "walk" clip (frames 0-24, rests at
0 and 12) on pivots hip_L/R, shoulder_L/R and body.
"""

import math
import sys

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Quaternion, Vector

N = 128
_rng = np.random.default_rng(1993)


# ----------------------------------------------------------------------------- textures

def _blur(a, r):
    for _ in range(r):
        a = (a + np.roll(a, 1, 0) + np.roll(a, -1, 0) + np.roll(a, 1, 1) + np.roll(a, -1, 1)) / 5
    return a


def _noise(r):
    a = _blur(_rng.random((N, N)), r)
    a -= a.min()
    return a / max(a.max(), 1e-6)


def tex_cloth():
    y, x = np.mgrid[0:N, 0:N]
    weave = 0.9 + 0.1 * ((x // 2 + y // 2) % 2)
    g = weave * (0.92 + 0.08 * _noise(3))
    return g


def tex_skin():
    return 0.95 + 0.05 * _noise(6)


def tex_hair():
    s = _blur(_rng.random((N, N)), 1)
    s = np.repeat(s.mean(axis=0, keepdims=True), N, axis=0)   # strands along y
    return 0.8 + 0.25 * (s - s.min()) / max(np.ptp(s), 1e-6)


def tex_wood():
    y, x = np.mgrid[0:N, 0:N]
    ring = np.sin((x + 6 * _noise(8)) * 0.55)
    g = 0.78 + 0.12 * ring + 0.1 * _noise(2)
    g[(y % 32) < 1] *= 0.6       # plank seams
    return g


def tex_clay():
    return 0.86 + 0.14 * _noise(4)


def tex_leaf():
    n = _noise(2)
    g = 0.75 + 0.35 * n
    g[n > 0.75] = 1.15            # light leaf tips
    return g


def tex_shingle():
    y, x = np.mgrid[0:N, 0:N]
    row = y // 16
    g = 0.95 - 0.35 * ((y % 16) < 2) - 0.25 * (((x + row * 8) % 16) < 1)
    return g * (0.9 + 0.1 * _noise(2))


def tex_stone():
    y, x = np.mgrid[0:N, 0:N]
    row = y // 16
    g = 0.9 + 0.1 * _noise(3)
    g[(y % 16) < 1] = 0.55
    g[((x + (row % 2) * 12) % 24) < 1] = 0.55
    return g


TEXTURES = {"cloth": tex_cloth, "skin": tex_skin, "hair": tex_hair, "wood": tex_wood,
            "clay": tex_clay, "leaf": tex_leaf, "shingle": tex_shingle, "stone": tex_stone}


def image(kind):
    name = "ladx_tex_" + kind
    if name in bpy.data.images:
        return bpy.data.images[name]
    g = np.clip(TEXTURES[kind](), 0, 1).astype(np.float32)
    img = bpy.data.images.new(name, N, N, alpha=True)
    rgba = np.ones((N, N, 4), dtype=np.float32)
    rgba[..., 0] = rgba[..., 1] = rgba[..., 2] = g[::-1]
    img.pixels.foreach_set(rgba.ravel())
    img.file_format = "PNG"
    img.pack()
    return img


def mat(name, rgb, tex=None, rough=0.7, metal=0.0):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = next(n for n in nt.nodes if n.type == "BSDF_PRINCIPLED")
    col = tuple(c / 255 for c in rgb) + (1,)
    bsdf.inputs["Roughness"].default_value = rough
    bsdf.inputs["Metallic"].default_value = metal
    if tex:
        t = nt.nodes.new("ShaderNodeTexImage")
        t.image = image(tex)
        t.interpolation = "Linear"
        mix = nt.nodes.new("ShaderNodeMix")
        mix.data_type = "RGBA"
        mix.blend_type = "MULTIPLY"
        mix.inputs["Factor"].default_value = 1.0
        mix.inputs[6].default_value = col
        nt.links.new(t.outputs["Color"], mix.inputs[7])
        nt.links.new(mix.outputs[2], bsdf.inputs["Base Color"])
    bsdf.inputs["Base Color"].default_value = col
    m.diffuse_color = col
    return m


# ----------------------------------------------------------------------------- geometry

def box_map(obj, density=0.25):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    uv = bm.loops.layers.uv.verify()
    for f in bm.faces:
        n = f.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        a, b = [(1, 2), (0, 2), (0, 1)][ax]
        for loop in f.loops:
            co = loop.vert.co
            loop[uv].uv = (co[a] * density, co[b] * density)
    bm.transform(obj.matrix_world.inverted())
    bm.to_mesh(obj.data)
    bm.free()


def _active(o):
    bpy.context.view_layer.objects.active = o
    o.select_set(True)


def _apply(o, mod):
    _active(o)
    bpy.ops.object.modifier_apply(modifier=mod.name)


def finish(o, material, bevel=0.0, segs=2, subsurf=0, smooth=True, density=0.25):
    o.data.materials.clear()
    o.data.materials.append(material)
    if bevel > 0:
        m = o.modifiers.new("bevel", "BEVEL")
        m.width = bevel
        m.segments = segs
        m.limit_method = "ANGLE"
        _apply(o, m)
    if subsurf:
        m = o.modifiers.new("sub", "SUBSURF")
        m.levels = subsurf
        m.render_levels = subsurf
        _apply(o, m)
    box_map(o, density)
    for p in o.data.polygons:
        p.use_smooth = smooth
    return o


def _new(name):
    o = bpy.context.active_object
    o.name = name
    o.data.name = name
    return o


def box(name, size, loc, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rot)
    o = _new(name)
    o.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return o


def cyl(name, r, depth, loc, rot=(0, 0, 0), verts=20, r2=None):
    if r2 is None:
        bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=r, depth=depth, location=loc, rotation=rot)
    else:
        bpy.ops.mesh.primitive_cone_add(vertices=verts, radius1=r, radius2=r2, depth=depth, location=loc,
                                        rotation=rot)
    return _new(name)


def ball(name, r, loc, scale=(1, 1, 1), seg=20, rings=12):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=seg, ring_count=rings, radius=r, location=loc)
    o = _new(name)
    o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return o


def torus(name, R, r, loc, rot=(0, 0, 0), scale=(1, 1, 1)):
    bpy.ops.mesh.primitive_torus_add(major_radius=R, minor_radius=r, major_segments=24, minor_segments=8,
                                     location=loc, rotation=rot)
    o = _new(name)
    o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return o


def cut_below(o, z):
    """Removes the part of a mesh below z (local = world here: no rotation applied yet)."""
    bm = bmesh.new()
    bm.from_mesh(o.data)
    bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=(0, 0, z),
                           plane_no=(0, 0, 1), clear_inner=True)
    bm.to_mesh(o.data)
    bm.free()


def rotate_about(objs, point, axis, deg):
    q = Quaternion(axis, math.radians(deg))
    M = Matrix.Translation(point) @ q.to_matrix().to_4x4() @ Matrix.Translation(-Vector(point))
    for o in objs:
        o.matrix_world = M @ o.matrix_world
    bpy.context.view_layer.update()


def clear():
    for c in (bpy.data.objects, bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.actions):
        for x in list(c):
            c.remove(x)


def tris():
    t = 0
    for o in bpy.data.objects:
        if o.type == "MESH":
            o.data.calc_loop_triangles()
            t += len(o.data.loop_triangles)
    return t


# ----------------------------------------------------------------------------- walk clip

def _pivot(name, at, children):
    e = bpy.data.objects.new(name, None)
    bpy.context.scene.collection.objects.link(e)
    e.rotation_mode = "QUATERNION"
    e.location = at
    bpy.context.view_layer.update()
    for o in children:
        w = o.matrix_world.copy()
        o.parent = e
        o.matrix_parent_inverse = e.matrix_world.inverted()
        o.matrix_world = w
    return e


def add_walk(prefix, legs, arms, hip_z, shoulder_z, hip_x, shoulder_x, leg_swing=30, arm_swing=22, bob=0.5):
    """legs/arms: {-1: [objs], 1: [objs]}.  Everything else hangs from 'body'."""
    hips = {s: _pivot("%s_hip_%s" % (prefix, "LR"[s > 0]), Vector((s * hip_x, 0, hip_z)), legs[s]) for s in (-1, 1)}
    shs = {s: _pivot("%s_shoulder_%s" % (prefix, "LR"[s > 0]), Vector((s * shoulder_x, 0, shoulder_z)), arms[s])
           for s in (-1, 1)}
    taken = set(o.name for v in list(legs.values()) + list(arms.values()) for o in v)
    rest = [o for o in bpy.context.scene.objects
            if o.type == "MESH" and o.parent is None and o.name not in taken]
    body = _pivot("%s_body" % prefix, Vector((0, 0, hip_z)), rest + list(shs.values()))
    pivots = list(hips.values()) + list(shs.values()) + [body]
    for p in pivots:
        p.animation_data_create()
    rest_m = {p.name: p.matrix_basis.copy() for p in pivots}
    for i, f in enumerate(range(0, 25, 6)):
        phase = [0, 1, 0, -1, 0][i]
        for p in pivots:
            p.matrix_basis = rest_m[p.name]
        for s in (-1, 1):
            hips[s].rotation_quaternion = Quaternion((1, 0, 0), math.radians(-leg_swing * s * phase))
            shs[s].rotation_quaternion = Quaternion((1, 0, 0), math.radians(arm_swing * s * phase))
        body.location.z = hip_z + bob * abs(phase)
        for p in pivots:
            p.keyframe_insert("location", frame=f)
            p.keyframe_insert("rotation_quaternion", frame=f)
            p.keyframe_insert("scale", frame=f)
    for p in pivots:
        act = p.animation_data.action
        act.name = "walk_" + p.name
        tr = p.animation_data.nla_tracks.new()
        tr.name = "walk"
        st = tr.strips.new("walk", 0, act)
        st.extrapolation = "NOTHING"
        st.frame_end = 24
        p.animation_data.action = None
        p.matrix_basis = rest_m[p.name]
    bpy.context.scene.frame_set(0)


# ----------------------------------------------------------------------------- people

SKIN = (247, 196, 160)
EYE = (40, 30, 30)


def person(p, *, tunic, trousers, boots, hair, hair_style, skin=SKIN, size=1.0, belly=0.0,
           skirt=False, sleeves=None, hair_len=0.0):
    """A chibi figure.  Returns the parts dict.  size scales everything (kids < 1)."""
    s = size
    M = {
        "skin": mat(p + "_skin", skin, "skin", 0.6),
        "tunic": mat(p + "_tunic", tunic, "cloth", 0.85),
        "trousers": mat(p + "_trousers", trousers, "cloth", 0.85),
        "boots": mat(p + "_boots", boots, "clay", 0.5),
        "hair": mat(p + "_hair", hair, "hair", 0.55),
        "eye": mat(p + "_eye", EYE, None, 0.3),
        "sleeve": mat(p + "_sleeve", sleeves or tunic, "cloth", 0.85),
    }
    parts = {"legs": {-1: [], 1: []}, "arms": {-1: [], 1: []}}
    hip_z = 4.6 * s
    # legs and boots
    for side in (-1, 1):
        x = side * 1.9 * s
        leg = finish(cyl("%s_leg_%d" % (p, side), 1.45 * s, hip_z - 1.0 * s, (x, 0, (hip_z + 1.0 * s) / 2)),
                     M["trousers"], bevel=0.3 * s)
        boot = finish(box("%s_boot_%d" % (p, side), (2.9 * s, 4.0 * s, 2.0 * s), (x, -0.5 * s, 1.0 * s)),
                      M["boots"], bevel=0.8 * s, segs=3)
        parts["legs"][side] += [leg, boot]
    # torso: a flared tunic (or skirt), belt
    tz0, tz1 = hip_z - (2.6 * s if skirt else 1.2 * s), hip_z + 6.0 * s
    torso = cyl(p + "_torso", (5.4 if skirt else 4.3) * s + belly, tz1 - tz0, (0, 0, (tz0 + tz1) / 2),
                r2=3.3 * s + belly * 0.5, verts=24)
    torso.scale = (1, 0.82, 1)
    bpy.ops.object.transform_apply(scale=True)
    finish(torso, M["tunic"], bevel=0.6 * s, segs=3)
    if belly:
        tum = finish(ball(p + "_belly", 3.2 * s + belly * 0.6, (0, -1.0 * s, hip_z + 2.4 * s), (1.15, 0.9, 1.0)),
                     M["tunic"], subsurf=0)
    belt = finish(torus(p + "_belt", 3.75 * s + belly * 0.8, 0.45 * s, (0, 0, hip_z + 1.0 * s),
                        scale=(1, 0.85, 1)), M["boots"])
    # arms
    sh_z = tz1 - 1.0 * s
    for side in (-1, 1):
        x = side * (3.9 * s + belly * 0.5)
        arm = finish(cyl("%s_arm_%d" % (p, side), 1.2 * s, 4.6 * s, (x, 0, sh_z - 2.1 * s), rot=(0, side * 0.18, 0)),
                     M["sleeve"], bevel=0.3 * s)
        hand = finish(ball("%s_hand_%d" % (p, side), 1.25 * s, (x + side * 0.4 * s, 0, sh_z - 4.7 * s)),
                      M["skin"])
        parts["arms"][side] += [arm, hand]
    # head (tilted back) with face and hair
    hz = tz1 + 4.6 * s
    hr = 5.0 * s
    head = finish(ball(p + "_head", hr, (0, 0, hz), (1.0, 0.95, 0.95), seg=28, rings=16), M["skin"])
    eyes = []
    for side in (-1, 1):
        e = finish(ball("%s_eye_%d" % (p, side), 0.75 * s, (side * 1.8 * s, -hr * 0.88, hz - 0.2 * s),
                        (0.8, 0.5, 1.3), seg=12, rings=8), M["eye"])
        eyes.append(e)
    nose = finish(ball(p + "_nose", 0.7 * s, (0, -hr * 0.97, hz - 1.3 * s), seg=10, rings=6), M["skin"])
    ears = [finish(ball("%s_ear_%d" % (p, side), 1.0 * s, (side * hr * 0.98, 0.2 * s, hz - 0.4 * s),
                        (0.5, 0.8, 1.0), seg=10, rings=6), M["skin"]) for side in (-1, 1)]
    hair_parts = []
    cap = ball(p + "_hair", hr * 1.08, (0, 0.35 * s, hz + 0.3 * s), (1.02, 1.0, 1.0), seg=28, rings=16)
    # hair covers the top and back; open the face
    bm = bmesh.new()
    bm.from_mesh(cap.data)
    # (vertex coordinates are local to the cap's centre)
    kill = [v for v in bm.verts if v.co.y < -hr * 0.35 and v.co.z < hr * 0.3]
    kill += [v for v in bm.verts if v.co.z < -hr * (0.2 + hair_len) and v not in kill]
    bmesh.ops.delete(bm, geom=kill, context="VERTS")
    bm.to_mesh(cap.data)
    bm.free()
    sol = cap.modifiers.new("thick", "SOLIDIFY")
    sol.thickness = 0.6 * s
    _apply(cap, sol)
    finish(cap, M["hair"], subsurf=1)
    hair_parts.append(cap)
    # fringe: a few rounded locks over the forehead
    for i, dx in enumerate((-2.6, -0.9, 0.9, 2.6)):
        lock = finish(ball("%s_lock_%d" % (p, i), 1.4 * s, (dx * s, -hr * 0.78, hz + hr * 0.45),
                           (1.0, 0.7, 0.9), seg=12, rings=8), M["hair"])
        hair_parts.append(lock)
    head_objs = [head, nose] + eyes + ears + hair_parts
    parts.update(M=M, hip_z=hip_z, sh_z=sh_z, hz=hz, hr=hr, torso=torso, head=head_objs,
                 shoulder_x=3.9 * s + belly * 0.5, hip_x=1.9 * s, s=s)
    return parts


def tilt_head(parts, deg=-22, extra=()):
    rotate_about(parts["head"] + list(extra), Vector((0, 0, parts["hz"] - parts["hr"] * 0.8)), (1, 0, 0), deg)


def build_hero():
    p = "hero"
    P = person(p, tunic=(46, 150, 92), trousers=(236, 222, 190), boots=(120, 72, 40), hair=(150, 92, 48),
               hair_style="short", sleeves=(46, 150, 92))
    M = P["M"]
    s, hz, hr = P["s"], P["hz"], P["hr"]
    green_dark = mat(p + "_hood", (30, 112, 70), "cloth", 0.85)
    # A soft hood lying back on the shoulders, with a long tail down the back
    hood = finish(torus(p + "_hoodroll", 3.4, 1.3, (0, 1.6, P["sh_z"] + 1.2), rot=(0.35, 0, 0), scale=(1.15, 1, 0.9)),
                  green_dark)
    tail = finish(cyl(p + "_hoodtail", 1.6, 5.0, (0, 3.9, P["sh_z"] - 1.0), rot=(0.45, 0, 0), r2=0.4, verts=12),
                  green_dark, subsurf=1)
    # A soft green slouch cap worn on the back of the head (hair and face show in front),
    # with a short tassel: green from above, like the sprite, but not its pointed cap
    green = mat(p + "_cap", (52, 168, 100), "cloth", 0.85)
    cap = finish(ball(p + "_cap", hr * 0.98, (0, 1.4, hz + hr * 0.55), (1.12, 1.15, 0.62), seg=28, rings=14),
                 green)
    rotate_about([cap], Vector((0, 1.4, hz + hr * 0.55)), (1, 0, 0), 18)
    band = finish(torus(p + "_band", hr * 1.0, 0.55, (0, 1.0, hz + hr * 0.3), rot=(0.32, 0, 0),
                        scale=(1.05, 1.0, 1.0)), green_dark)
    knot = finish(ball(p + "_tassel", 1.3, (0, hr + 1.8, hz + 0.4), seg=12, rings=8), mat(p + "_tasselc", (240, 210, 90), "cloth"))
    tilt_head(P, -22, extra=[cap, band, knot])
    # Satchel on the back, strap across the chest
    leather = mat(p + "_leather", (150, 96, 54), "clay", 0.6)
    bag = finish(box(p + "_satchel", (3.4, 1.8, 2.8), (-1.6, 3.1, P["hip_z"] + 2.6)), leather, bevel=0.5, segs=2)
    strap = finish(torus(p + "_strap", 4.3, 0.3, (0, 0, P["hip_z"] + 4.0), rot=(0, 0.6, 0), scale=(0.95, 0.88, 1.0)),
                   leather)
    # Round wooden shield with a metal rim and boss on the left arm, turned out and tipped back
    wood = mat(p + "_shieldwood", (170, 110, 60), "wood", 0.7)
    steel = mat(p + "_steel", (190, 190, 200), None, 0.35, 0.8)
    red = mat(p + "_emblem", (200, 50, 50), "cloth", 0.6)
    sx = -(P["shoulder_x"] + 1.6)
    sz = P["sh_z"] - 3.4
    shield = finish(cyl(p + "_shield", 3.6, 0.8, (sx, -1.2, sz), rot=(math.pi / 2, 0, 0), verts=28), wood, bevel=0.2)
    rim = finish(torus(p + "_shieldrim", 3.6, 0.35, (sx, -1.2, sz), rot=(math.pi / 2, 0, 0)), steel)
    boss = finish(ball(p + "_shieldboss", 1.0, (sx, -1.7, sz), (1, 0.6, 1)), steel)
    emb = finish(cyl(p + "_shieldemblem", 2.4, 0.2, (sx, -1.65, sz), rot=(math.pi / 2, 0, 0), verts=3), red)
    shield_parts = [shield, rim, boss, emb]
    rotate_about(shield_parts, Vector((sx, -1.2, sz)), (0, 0, 1), -35)     # turn outwards
    rotate_about(shield_parts, Vector((sx, -1.2, sz)), (1, 0, 0), -25)     # tip back to show its face
    P["arms"][-1] += shield_parts
    # A short sword in its sheath on the right hip (the sprite carries none yet; keeps it simple)
    add_walk(p, P["legs"], P["arms"], P["hip_z"], P["sh_z"], P["hip_x"], P["shoulder_x"])
    return "hero_torso"


def build_marin():
    p = "marin"
    P = person(p, tunic=(236, 120, 70), trousers=(236, 120, 70), boots=(150, 70, 50), hair=(196, 72, 40),
               hair_style="long", skirt=True, hair_len=0.55, sleeves=(250, 238, 214))
    s, hz, hr = P["s"], P["hz"], P["hr"]
    white = mat(p + "_apron", (250, 238, 214), "cloth", 0.85)
    apron = finish(box(p + "_apron", (5.6, 0.6, 5.8), (0, -3.4, P["hip_z"] + 0.6), rot=(0.12, 0, 0)), white,
                   bevel=0.25)
    collar = finish(torus(p + "_collar", 2.6, 0.5, (0, 0, P["sh_z"] + 1.0), scale=(1, 0.9, 1)), white)
    # Long hair falling down the back, and a flower over one ear
    hairmat = P["M"]["hair"]
    back = finish(ball(p + "_hairback", 4.2, (0, 2.6, hz - 4.0), (1.05, 0.55, 1.4), seg=20, rings=12), hairmat)
    petal = mat(p + "_flower", (255, 230, 90), None, 0.5)
    pink = mat(p + "_flowerheart", (230, 70, 110), None, 0.5)
    fl = [finish(ball(p + "_petal_%d" % i, 0.9, (hr * 0.75 + math.cos(i * 1.257) * 1.0, -1.2,
                                                   hz + 2.4 + math.sin(i * 1.257) * 1.0), (1, 0.5, 1), 10, 6), petal)
          for i in range(5)]
    fl.append(finish(ball(p + "_flowerc", 0.6, (hr * 0.75, -1.6, hz + 2.4), seg=10, rings=6), pink))
    tilt_head(P, -22, extra=[back] + fl)
    add_walk(p, P["legs"], P["arms"], P["hip_z"], P["sh_z"], P["hip_x"], P["shoulder_x"], leg_swing=20)
    return "marin_torso"


def build_tarin():
    p = "tarin"
    P = person(p, tunic=(220, 60, 60), trousers=(110, 80, 60), boots=(70, 50, 40), hair=(40, 34, 34),
               hair_style="short", belly=1.2, sleeves=(245, 240, 225))
    s, hz, hr = P["s"], P["hz"], P["hr"]
    # Bushy moustache and a round nose; a white shirt collar under the red vest
    tash = finish(ball(p + "_moustache", 1.5, (0, -hr * 0.95, hz - 2.0), (2.0, 0.7, 0.7), seg=16, rings=8),
                  P["M"]["hair"])
    nose = finish(ball(p + "_bignose", 1.25, (0, -hr * 1.02, hz - 1.0), seg=12, rings=8),
                  mat(p + "_nosecol", (240, 160, 130), "skin", 0.6))
    white = mat(p + "_shirt", (245, 240, 225), "cloth", 0.85)
    collar = finish(torus(p + "_collar", 2.6, 0.6, (0, 0, P["sh_z"] + 1.0), scale=(1, 0.9, 1)), white)
    buttons = [finish(ball(p + "_button_%d" % i, 0.45, (0, -4.6, P["hip_z"] + 1.6 + i * 1.6), seg=8, rings=6),
                      mat(p + "_btn", (250, 210, 80), None, 0.4, 0.5)) for i in range(3)]
    tilt_head(P, -34, extra=[tash, nose])
    add_walk(p, P["legs"], P["arms"], P["hip_z"], P["sh_z"], P["hip_x"], P["shoulder_x"], leg_swing=22)
    return "tarin_torso"


def build_kid():
    p = "kid"
    P = person(p, tunic=(60, 160, 90), trousers=(240, 220, 180), boots=(110, 70, 40), hair=(36, 30, 30),
               hair_style="bowl", size=0.85, sleeves=(240, 220, 180))
    tilt_head(P, -24)
    add_walk(p, P["legs"], P["arms"], P["hip_z"], P["sh_z"], P["hip_x"], P["shoulder_x"])
    return "kid_torso"


# ----------------------------------------------------------------------------- animals

def build_hen():
    p = "hen"
    body_m = mat(p + "_feather", (246, 178, 150), "cloth", 0.9)
    wing_m = mat(p + "_wing", (236, 120, 70), "cloth", 0.9)
    red = mat(p + "_comb", (225, 60, 60), None, 0.5)
    yel = mat(p + "_beak", (245, 180, 60), None, 0.5)
    eye = mat(p + "_eye", EYE, None, 0.3)
    body = finish(ball(p + "_torso", 4.0, (0, 0.8, 5.0), (1.0, 1.25, 0.95)), body_m)
    tail = finish(cyl(p + "_tail", 2.2, 4.0, (0, 4.8, 7.0), rot=(-0.7, 0, 0), r2=0.6, verts=10), wing_m, subsurf=1)
    wings = [finish(ball("%s_wing_%d" % (p, s), 2.3, (s * 3.6, 1.2, 5.2), (0.4, 1.0, 0.7)), wing_m) for s in (-1, 1)]
    head = finish(ball(p + "_head", 2.3, (0, -2.8, 8.3)), body_m)
    comb = [finish(ball("%s_comb_%d" % (p, i), 0.8, (0, -3.0 + i * 0.9, 10.6 - abs(i - 1) * 0.3)), red) for i in range(3)]
    beak = finish(cyl(p + "_beak", 0.7, 1.6, (0, -5.4, 8.2), rot=(math.pi / 2, 0, 0), r2=0.1, verts=8), yel)
    wattle = finish(ball(p + "_wattle", 0.6, (0, -4.6, 7.0), (0.7, 0.7, 1.2)), red)
    eyes = [finish(ball("%s_eye_%d" % (p, s), 0.45, (s * 1.6, -4.0, 8.9)), eye) for s in (-1, 1)]
    legs = [finish(cyl("%s_leg_%d" % (p, s), 0.35, 2.4, (s * 1.4, 0.4, 1.4), verts=8), yel) for s in (-1, 1)]
    feet = [finish(box("%s_foot_%d" % (p, s), (1.4, 2.2, 0.5), (s * 1.4, -0.3, 0.25)), yel, bevel=0.2) for s in (-1, 1)]
    return "hen_torso"


def build_fox():
    p = "fox"
    fur = mat(p + "_fur", (238, 128, 56), "hair", 0.8)
    cream = mat(p + "_cream", (250, 236, 210), "hair", 0.8)
    dark = mat(p + "_dark", (60, 40, 36), None, 0.5)
    body = finish(ball(p + "_torso", 3.6, (0, 1.0, 5.2), (0.9, 1.5, 0.9)), fur)
    chest = finish(ball(p + "_chest", 2.4, (0, -2.4, 5.2), (1.0, 0.8, 1.1)), cream)
    head = finish(ball(p + "_head", 3.2, (0, -3.6, 9.0), (1.0, 0.95, 0.9)), fur)
    snout = finish(cyl(p + "_snout", 1.5, 3.0, (0, -6.6, 8.2), rot=(math.pi / 2 + 0.2, 0, 0), r2=0.5, verts=12), cream)
    nose = finish(ball(p + "_nose", 0.55, (0, -8.1, 8.0)), dark)
    ears = [finish(cyl("%s_ear_%d" % (p, s), 1.4, 3.2, (s * 1.9, -3.2, 12.2), rot=(0, s * 0.3, 0), r2=0.1, verts=4),
                   fur, bevel=0.2) for s in (-1, 1)]
    eyes = [finish(ball("%s_eye_%d" % (p, s), 0.5, (s * 1.4, -6.0, 9.6)), dark) for s in (-1, 1)]
    tail = finish(cyl(p + "_tail", 2.4, 7.0, (0, 6.6, 6.8), rot=(-1.0, 0, 0), r2=1.0, verts=14), fur, subsurf=1)
    tip = finish(ball(p + "_tailtip", 1.6, (0, 9.6, 8.8)), cream)
    legs = [finish(cyl("%s_leg_%d_%d" % (p, s, f), 0.9, 3.4, (s * 1.7, f * 2.8 + 0.6, 1.7), verts=10), dark, bevel=0.2)
            for s in (-1, 1) for f in (-1, 1)]
    return "fox_torso"


def build_pup():
    p = "pup"
    fur = mat(p + "_fur", (246, 190, 170), "hair", 0.85)
    ear = mat(p + "_earfur", (200, 120, 110), "hair", 0.85)
    dark = mat(p + "_dark", (50, 36, 36), None, 0.4)
    body = finish(ball(p + "_torso", 3.6, (0, 1.2, 4.6), (1.0, 1.4, 0.95)), fur)
    head = finish(ball(p + "_head", 3.6, (0, -3.0, 8.6)), fur)
    muzzle = finish(ball(p + "_muzzle", 1.8, (0, -6.0, 7.7), (1.0, 0.9, 0.8)), fur)
    nose = finish(ball(p + "_nose", 0.6, (0, -7.6, 8.2)), dark)
    eyes = [finish(ball("%s_eye_%d" % (p, s), 0.5, (s * 1.5, -6.0, 9.6)), dark) for s in (-1, 1)]
    ears = [finish(ball("%s_ear_%d" % (p, s), 1.6, (s * 3.5, -2.6, 8.4), (0.45, 0.9, 1.5)), ear) for s in (-1, 1)]
    legs = [finish(cyl("%s_leg_%d_%d" % (p, s, f), 1.0, 3.2, (s * 2.0, f * 2.6 + 0.8, 1.6), verts=10), fur, bevel=0.3)
            for s in (-1, 1) for f in (-1, 1)]
    tail = finish(cyl(p + "_tail", 0.6, 3.0, (0, 6.0, 6.4), rot=(-0.8, 0, 0), r2=0.3, verts=8), fur)
    return "pup_torso"


# ----------------------------------------------------------------------------- scenery

def build_pot():
    """A round clay pot, 16 px footprint: the tile pair it replaces is 16x16."""
    p = "pot"
    clay = mat("pal2", (235, 235, 235), "clay", 0.8)          # colour 2: the pot's brown
    dark = mat("pal3", (235, 235, 235), None, 0.9)       # colour 3: dark inside
    band = mat("pal1", (235, 235, 235), "clay", 0.8)      # colour 1: light band
    bodyo = cyl(p + "_body", 6.4, 9.0, (0, 0, 4.5), verts=32)
    for v in bodyo.data.vertices:
        z = v.co.z + 4.5
        k = 0.78 + 0.25 * math.sin(min(max(z / 9.0, 0), 1) * math.pi * 0.85)
        v.co.x *= k
        v.co.y *= k
    finish(bodyo, clay, bevel=0.5, segs=2, subsurf=1)
    lip = finish(torus(p + "_lip", 4.6, 0.9, (0, 0, 9.0)), band)
    mouth = finish(cyl(p + "_mouth", 4.2, 0.4, (0, 0, 9.1), verts=24), dark)
    stripe = finish(torus(p + "_stripe", 6.55, 0.4, (0, 0, 5.4)), band)
    return "pot_body"


def build_bed():
    """A wooden bed for 16x32 tiles (head at the back, -Y is the foot end)."""
    p = "bed"
    wood = mat(p + "_wood", (176, 110, 64), "wood", 0.7)
    sheet = mat(p + "_sheet", (250, 244, 220), "cloth", 0.9)
    blanket = mat(p + "_blanket", (120, 130, 150), "cloth", 0.9)
    frame = finish(box(p + "_frame", (15, 30, 3.2), (0, 0, 2.6)), wood, bevel=0.5)
    for sx in (-1, 1):
        for sy in (-1, 1):
            finish(box("%s_leg_%d_%d" % (p, sx, sy), (1.6, 1.6, 2.0), (sx * 6.6, sy * 14.0, 1.0)), wood, bevel=0.3)
    head = finish(box(p + "_headboard", (15.4, 1.6, 9.0), (0, 14.4, 4.5)), wood, bevel=0.5)
    foot = finish(box(p + "_footboard", (15.4, 1.4, 5.5), (0, -14.4, 2.75)), wood, bevel=0.5)
    matt = finish(box(p + "_mattress", (13.6, 27.6, 2.2), (0, 0, 4.9)), sheet, bevel=0.8, segs=3)
    pillow = finish(box(p + "_pillow", (10, 4.5, 2.0), (0, 10.8, 6.8)), sheet, bevel=0.9, segs=3)
    blank = finish(box(p + "_blanket", (14.2, 17, 1.2), (0, -4.6, 6.2)), blanket, bevel=0.5, segs=3)
    return "bed_frame"


def build_table():
    """A plank table for 32x16 tiles."""
    p = "table"
    wood = mat("pal2", (235, 235, 235), "wood", 0.7)
    dark = mat("pal3", (235, 235, 235), "wood", 0.7)
    top = finish(box(p + "_top", (31, 15, 2.0), (0, 0, 8.0)), wood, bevel=0.5)
    for sx in (-1, 1):
        for sy in (-1, 1):
            finish(box("%s_leg_%d_%d" % (p, sx, sy), (1.8, 1.8, 7.0), (sx * 13.0, sy * 5.0, 3.5)), dark, bevel=0.3)
    finish(box(p + "_rail", (26, 1.0, 1.2), (0, 0, 5.0)), dark, bevel=0.2)
    return "table_top"


def build_dresser():
    """A chest of drawers for a 16x16 tile block."""
    p = "dresser"
    wood = mat("pal2", (235, 235, 235), "wood", 0.7)
    face = mat("pal3", (235, 235, 235), "wood", 0.7)
    knob = mat(p + "_knob", (230, 200, 90), None, 0.35, 0.7)
    body = finish(box(p + "_body", (15, 13, 14), (0, 0, 7)), wood, bevel=0.5)
    for i in range(3):
        z = 3.0 + i * 4.2
        finish(box("%s_drawer_%d" % (p, i), (13, 0.8, 3.4), (0, -6.6, z)), face, bevel=0.3)
        finish(ball("%s_knob_%d" % (p, i), 0.6, (0, -7.2, z)), knob)
    return "dresser_body"


def build_stool():
    """A three-legged stool for 16x16 tiles."""
    p = "stool"
    wood = mat("pal2", (235, 235, 235), "wood", 0.7)
    leg = mat("pal3", (235, 235, 235), "wood", 0.7)
    seat = finish(cyl(p + "_seat", 6.0, 1.8, (0, 0, 7.0), verts=28), wood, bevel=0.5)
    for i in range(3):
        a = i * 2 * math.pi / 3 + 0.5
        finish(cyl("%s_leg_%d" % (p, i), 0.8, 6.6, (math.cos(a) * 3.8, math.sin(a) * 3.8, 3.2),
                   rot=(math.sin(a) * -0.15, math.cos(a) * 0.15, 0), verts=10), leg)
    return "stool_seat"


def build_tree():
    """A round broadleaf tree for its 32x32 block of tiles (canopy over a short trunk)."""
    p = "tree"
    leaf = mat("pal2", (235, 235, 235), "leaf", 0.85)       # colour 2 of the canopy tiles: green
    leaf_l = mat("pal2.001", (255, 255, 255), "leaf", 0.85)
    bark = mat(p + "_bark", (120, 76, 46), "wood", 0.9)
    trunk = finish(cyl(p + "_trunk", 3.6, 14, (0, 2, 7), r2=2.6, verts=14), bark, bevel=0.3)
    roots = [finish(cyl("%s_root_%d" % (p, i), 1.4, 5, (math.cos(a) * 3.6, 2 + math.sin(a) * 3.6, 1.2),
                        rot=(math.sin(a) * 1.2, -math.cos(a) * 1.2, 0), r2=0.4, verts=8), bark)
             for i, a in enumerate((0.3, 2.2, 4.0, 5.3))]
    blobs = [((0, 0, 20), 11.0, leaf), ((-6, 3, 17), 7.5, leaf), ((6, 3, 17), 7.5, leaf),
             ((-3, -5, 19), 7.0, leaf_l), ((4, -4, 22), 6.5, leaf_l), ((0, 5, 25), 6.5, leaf_l)]
    for i, (loc, r, m) in enumerate(blobs):
        finish(ball("%s_crown_%d" % (p, i), r, loc, (1.0, 1.0, 0.85), seg=24, rings=14), m)
    return "tree_trunk"


def build_bush():
    """A low round shrub for a 16x16 block."""
    p = "bush"
    leaf = mat("pal2", (235, 235, 235), "leaf", 0.85)
    leaf_l = mat("pal2.001", (255, 255, 255), "leaf", 0.85)
    for i, (loc, r, m) in enumerate([((0, 0, 4.2), 5.6, leaf), ((-3.2, -1.5, 4.6), 3.6, leaf_l),
                                     ((3.0, -1.2, 5.0), 3.4, leaf_l), ((0, 2.5, 6.2), 3.6, leaf)]):
        o = finish(ball("%s_clump_%d" % (p, i), r, loc, (1.15, 1.15, 0.85), seg=20, rings=12), m)
        cut_below(o, 0)
    return "bush_clump_0"


def build_house(width=48, depth=24, wall_h=12, roof_h=14, chimney=False, sign=None):
    """A cottage for a block of roof and front-wall tiles: plastered walls, a door and two
    windows on the front (-Y), a steep gabled roof whose colour follows the roof tiles'
    palette (pal2 / pal3 materials)."""
    p = "house"
    plaster = mat(p + "_plaster", (238, 214, 170), "stone", 0.9)
    timber = mat(p + "_timber", (120, 70, 40), "wood", 0.8)
    roof = mat("pal2", (235, 235, 235), "shingle", 0.75)
    ridge = mat("pal3", (235, 235, 235), "shingle", 0.75)
    glass = mat(p + "_window", (60, 80, 110), None, 0.2)
    door = mat(p + "_door", (90, 54, 30), "wood", 0.8)
    W, D = width, depth
    walls = finish(box(p + "_walls", (W - 2, D - 2, wall_h), (0, 0, wall_h / 2)), plaster, bevel=0.4)
    for sx in (-1, 1):  # corner posts and a beam
        finish(box("%s_post_%d" % (p, sx), (1.6, D - 1, wall_h), (sx * (W / 2 - 1.6), 0, wall_h / 2)), timber,
               bevel=0.2)
    finish(box(p + "_beam", (W - 1, 1.2, 1.4), (0, -(D / 2 - 0.6), wall_h - 0.7)), timber, bevel=0.2)
    finish(box(p + "_door", (8, 1.0, 9.5), (0, -(D / 2 - 0.4), 4.75)), door, bevel=0.3)
    for sx in (-1, 1):
        finish(box("%s_win_%d" % (p, sx), (6, 0.8, 4.5), (sx * W * 0.28, -(D / 2 - 0.5), 7.0)), glass, bevel=0.2)
        finish(box("%s_winframe_%d" % (p, sx), (7.2, 0.6, 5.6), (sx * W * 0.28, -(D / 2 - 0.2), 7.0)), timber,
               bevel=0.2)
    # gabled roof: ridge along X, slopes front and back, eaves overhang
    bm = bmesh.new()
    hw, hd = W / 2 + 1.5, D / 2 + 1.2
    z0, z1 = wall_h - 0.5, wall_h + roof_h
    v = [bm.verts.new(c) for c in ((-hw, -hd, z0), (hw, -hd, z0), (hw, 0, z1), (-hw, 0, z1),
                                   (-hw, hd, z0), (hw, hd, z0))]
    bm.faces.new((v[0], v[1], v[2], v[3]))
    bm.faces.new((v[3], v[2], v[5], v[4]))
    bm.faces.new((v[0], v[3], v[4]))
    bm.faces.new((v[1], v[5], v[2]))
    bm.faces.new((v[0], v[4], v[5], v[1]))
    me = bpy.data.meshes.new(p + "_roof")
    bm.to_mesh(me)
    bm.free()
    ro = bpy.data.objects.new(p + "_roof", me)
    bpy.context.scene.collection.objects.link(ro)
    sol = ro.modifiers.new("t", "SOLIDIFY")
    sol.thickness = 1.2
    _apply(ro, sol)
    finish(ro, roof, bevel=0.3, smooth=False, density=0.12)
    finish(cyl(p + "_ridge", 1.1, 2 * hw + 0.6, (0, 0, z1 + 0.2), rot=(0, math.pi / 2, 0), verts=12), ridge)
    # gable ends in plaster
    bm = bmesh.new()
    for sx in (-1, 1):
        x = sx * (W / 2 - 1)
        a = [bm.verts.new(c) for c in ((x, -(D / 2 - 1), wall_h), (x, D / 2 - 1, wall_h), (x, 0, z1 - 1))]
        bm.faces.new(a)
    me = bpy.data.meshes.new(p + "_gables")
    bm.to_mesh(me)
    bm.free()
    go = bpy.data.objects.new(p + "_gables", me)
    bpy.context.scene.collection.objects.link(go)
    sol = go.modifiers.new("t", "SOLIDIFY")
    sol.thickness = 0.8
    _apply(go, sol)
    finish(go, plaster, smooth=False)
    # A porch slab in front: the game draws the front wall as 16 px of tiles below the roof;
    # in 3D the wall stands up, and the slab covers the ground those tiles took.
    flag = mat(p + "_porch", (196, 170, 130), "stone", 0.9)
    finish(box(p + "_porch", (W, 16, 1.0), (0, -(D / 2 + 8), 0.5)), flag, bevel=0.3, density=0.2)
    if chimney:
        stone = mat(p + "_chimney", (150, 140, 130), "stone", 0.9)
        finish(box(p + "_chimney", (4, 4, 9), (W * 0.25, 4, z1 - 1)), stone, bevel=0.3)
    if sign:
        board = mat(p + "_signboard", (240, 220, 160), "wood", 0.8)
        finish(box(p + "_sign", (16, 1.0, 5), (0, -(D / 2 + 1.2), wall_h + 2.0), rot=(0.3, 0, 0)), board, bevel=0.3)
        # three simple shapes: a jar, a coin and a bag, generic shop goods
        goods = mat(p + "_signpaint", (60, 90, 150), None, 0.6)
        for i, x in enumerate((-4.5, 0, 4.5)):
            finish(ball("%s_signmark_%d" % (p, i), 1.4, (x, -(D / 2 + 1.9), wall_h + 2.2), (1, 0.4, 1)), goods)
    return "house_walls"


# ----------------------------------------------------------------------------- pass 2: the sword
# Textures added for the beach: brushed steel, sand grain, bark rings, a shell/spine stripe.

def tex_steel():
    y, x = np.mgrid[0:N, 0:N]
    return 0.82 + 0.1 * np.sin(y * 0.9 + 3 * _noise(2)) * 0.5 + 0.12 * _noise(1)


def tex_sand():
    n = _rng.random((N, N))
    return 0.85 + 0.15 * _blur(n, 1) + 0.1 * (n > 0.97)


def tex_bark():
    y, x = np.mgrid[0:N, 0:N]
    return 0.75 + 0.18 * ((y % 12) < 3) + 0.1 * _noise(2)


def tex_frond():
    y, x = np.mgrid[0:N, 0:N]
    return 0.8 + 0.25 * (np.abs(((x + y // 3) % 10) - 5) < 1) + 0.08 * _noise(2)


TEXTURES.update({"steel": tex_steel, "sand": tex_sand, "bark": tex_bark, "frond": tex_frond})


def cut_world(o, z):
    """cut_below in world space: applies the object's transform first."""
    bpy.ops.object.select_all(action="DESELECT")
    _active(o)
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    cut_below(o, z)
    return o


def sword_parts(p, length=11.0, width=1.5):
    """A short arming sword lying along -Z from its grip at the origin (blade down)."""
    steel = mat(p + "_blade", (226, 232, 240), "steel", 0.25, 0.6)
    brass = mat(p + "_guard", (214, 170, 70), "steel", 0.35, 0.7)
    grip_m = mat(p + "_grip", (110, 60, 40), "clay", 0.6)
    blade = box(p + "_bladeo", (width, width * 0.45, length), (0, 0, -1.6 - length / 2))
    # taper the tip
    for v in blade.data.vertices:          # (mesh coordinates are local to the blade's centre)
        if v.co.z < -length / 2 + 0.5:
            v.co.x *= 0.15
    finish(blade, steel, bevel=0.15, smooth=False)
    fuller = finish(box(p + "_fuller", (0.4, 0.62, length * 0.7), (0, 0, -1.9 - length * 0.35)), brass)
    guard = finish(box(p + "_crossguard", (5.0, 1.0, 0.9), (0, 0, -1.2)), brass, bevel=0.3)
    grip = finish(cyl(p + "_hilt", 0.6, 2.6, (0, 0, 0.2), verts=10), grip_m)
    pommel = finish(ball(p + "_pommel", 0.9, (0, 0, 1.7), seg=12, rings=8), brass)
    return [blade, fuller, guard, grip, pommel]


def build_sword():
    """The sword stuck point-down in the sand at the water's edge (8x16 sprite)."""
    p = "sword"
    parts = sword_parts(p, 13.0, 2.6)   # broad, like the sprite's blade, so it reads at game size
    for o in parts:
        o.location.z += 13.0          # grip at 13: the blade's tip 1.6 + 13 below, in the sand
    bpy.context.view_layer.update()
    sand = mat(p + "_sand", (226, 200, 150), "sand", 0.95)
    mound = finish(ball(p + "_mound", 2.0, (0, 0, 0), (1.2, 1.0, 0.4), seg=16, rings=8), sand)
    cut_below(mound, 0)
    for o in parts:
        cut_world(o, 0.2)
    return "sword_mound"


def _key_pose(pivots, rest, frame, pose):
    for pv in pivots:
        pv.matrix_basis = rest[pv.name]
        if pv.name in pose:
            spec = pose[pv.name]
            if "rot" in spec:
                pv.rotation_quaternion = spec["rot"]
            if "scale" in spec:
                pv.scale = (spec["scale"],) * 3
            if "dz" in spec:
                pv.location.z += spec["dz"]
        pv.keyframe_insert("location", frame=frame)
        pv.keyframe_insert("rotation_quaternion", frame=frame)
        pv.keyframe_insert("scale", frame=frame)


def add_held_clips(pivots, rest, clips):
    """clips: {name: (frame, pose)}; a held pose = two identical keys at frame, frame + 1."""
    for name, (f, pose) in clips.items():
        for pv in pivots:
            pv.animation_data.action = None
        for fr in (f, f + 1):
            _key_pose(pivots, rest, fr, pose)
        for pv in pivots:
            act = pv.animation_data.action
            act.name = name + "_" + pv.name
            tr = pv.animation_data.nla_tracks.new()
            tr.name = name
            st = tr.strips.new(name, f, act)
            st.extrapolation = "NOTHING"
            pv.animation_data.action = None
            pv.matrix_basis = rest[pv.name]
    bpy.context.scene.frame_set(0)


def Q(axis, deg):
    return Quaternion(axis, math.radians(deg))


def build_hero_sword():
    """The hero once he has found his sword: a sheathed sword on his back while he walks, the
    sword in his right hand (+X side) in the held poses the swing groups name:
    hold_up (both hands up, sword pointing at the sky), swing_in_l / swing_mid_l (blade to his
    left / diagonal forward-left), swing_in_r / swing_mid_r (to his right), swing_out (forward)."""
    pivot = build_hero()
    p = "hero"
    sh_r = bpy.data.objects[p + "_shoulder_R"]
    sh_l = bpy.data.objects[p + "_shoulder_L"]
    body = bpy.data.objects[p + "_body"]
    # sword in hand: grip at the right hand, blade down along the arm's line
    hand = bpy.data.objects[p + "_hand_1"]
    hz = hand.matrix_world.translation.copy()
    # held: longer and broader than life, so the blade reads at game size like the sprite's
    parts = sword_parts(p + "_hs", 13.0, 2.8)
    for o in parts:
        o.location += hz
    bpy.context.view_layer.update()
    grip = _pivot(p + "_swordgrip", hz, parts)
    w = grip.matrix_world.copy()
    grip.parent = sh_r
    grip.matrix_parent_inverse = sh_r.matrix_world.inverted()
    grip.matrix_world = w
    # sheathed sword on the back: a leather scabbard across the back, hilt over the right shoulder
    leather = mat(p + "_scabbard", (96, 60, 36), "clay", 0.6)
    brass = bpy.data.materials[p + "_hs_guard"]
    sh_z = sh_r.matrix_world.translation.z
    sc = finish(box(p + "_scabbardbody", (1.9, 1.0, 10.5), (0, 0, -5.0)), leather, bevel=0.3)
    tip = finish(ball(p + "_scabbardtip", 1.0, (0, 0, -10.2), (1.0, 0.6, 1.0), seg=10, rings=6), brass)
    bs = sword_parts(p + "_bs", 0.1)
    keep = [o for o in bs if "blade" not in o.name and "fuller" not in o.name]   # only the hilt shows
    for o in bs:
        if o not in keep:
            bpy.data.objects.remove(o)
    bparts = [sc, tip] + keep
    for o in bparts:
        o.location += Vector((0, 3.6, sh_z + 3.0))
    bpy.context.view_layer.update()
    back = _pivot(p + "_backsword", Vector((0, 3.6, sh_z + 3.0)), bparts)
    back.rotation_quaternion = Q((0, 1, 0), -38)
    bpy.context.view_layer.update()
    rest_back = back.matrix_basis.copy()
    w = back.matrix_world.copy()
    back.parent = body
    back.matrix_parent_inverse = body.matrix_world.inverted()
    back.matrix_world = w
    for pv in (grip, back):
        pv.rotation_mode = "QUATERNION"
        pv.animation_data_create()
    pivots = [o for o in bpy.data.objects if o.type == "EMPTY"]
    rest = {pv.name: pv.matrix_basis.copy() for pv in pivots}
    # the walk clip gets keys for the two new pivots: sword in hand hidden, back sword shown
    for pv, sc_ in ((grip, 0.001), (back, 1.0)):
        pv.animation_data.action = None
        for fr in (0, 24):
            pv.matrix_basis = rest[pv.name]
            pv.scale = (sc_,) * 3
            pv.keyframe_insert("location", frame=fr)
            pv.keyframe_insert("rotation_quaternion", frame=fr)
            pv.keyframe_insert("scale", frame=fr)
        act = pv.animation_data.action
        act.name = "walk_" + pv.name
        tr = pv.animation_data.nla_tracks.new()
        tr.name = "walk"
        st = tr.strips.new("walk", 0, act)
        st.extrapolation = "NOTHING"
        st.frame_end = 24
        pv.animation_data.action = None
        pv.matrix_basis = rest[pv.name]
    fwd = Q((1, 0, 0), -90)                       # arm straight out in front (-Y)
    hide_back = {"scale": 0.001}
    show = {"scale": 1.0}
    lean = {"rot": Q((1, 0, 0), -8)}              # the body leans into the stroke
    clips = {
        # arms up and tipped back: from the top camera the sword then shows above his head
        "hold_up": (40, {sh_r.name: {"rot": Q((1, 0, 0), 145)}, sh_l.name: {"rot": Q((1, 0, 0), 150)},
                         grip.name: show, back.name: hide_back}),
        "swing_in_l": (50, {sh_r.name: {"rot": Q((0, 0, 1), 80) @ fwd}, grip.name: show, back.name: hide_back}),
        "swing_mid_l": (60, {sh_r.name: {"rot": Q((0, 0, 1), 40) @ fwd}, grip.name: show, back.name: hide_back,
                             body.name: lean}),
        "swing_in_r": (70, {sh_r.name: {"rot": Q((0, 0, 1), -85) @ fwd}, grip.name: show, back.name: hide_back}),
        "swing_mid_r": (80, {sh_r.name: {"rot": Q((0, 0, 1), -40) @ fwd}, grip.name: show, back.name: hide_back,
                             body.name: lean}),
        "swing_out": (90, {sh_r.name: {"rot": fwd}, grip.name: show, back.name: hide_back,
                           body.name: {"rot": Q((1, 0, 0), -12)}}),
    }
    add_held_clips(pivots, rest, clips)
    return pivot


# ----------------------------------------------------------------------------- pass 2: creatures

def build_octorok():
    """A round red sea-octopus that spits stones: a domed head, a tube mouth pointing forward
    (-Y), big eyes, and short curled legs (16x16 sprite)."""
    p = "octorok"
    red = mat(p + "_skin", (214, 52, 58), "skin", 0.5)
    pale = mat(p + "_spots", (250, 196, 170), "skin", 0.5)
    dark = mat(p + "_dark", (70, 20, 30), None, 0.4)
    white = mat(p + "_white", (250, 250, 245), None, 0.3)
    head = finish(ball(p + "_torso", 6.0, (0, 0.5, 8.0), (1.0, 1.0, 0.9), seg=28, rings=16), red)
    for i, (x, y, z, r) in enumerate([(-2.8, -1.0, 12.4, 1.2), (2.4, 1.8, 13.0, 1.0), (0.2, 3.6, 11.0, 1.1),
                                      (-4.6, 2.0, 9.6, 0.9), (4.4, -0.4, 10.6, 0.9)]):
        finish(ball("%s_spot_%d" % (p, i), r, (x, y, z), (1, 1, 0.35), seg=10, rings=6), pale)
    tube = finish(cyl(p + "_tube", 2.0, 3.6, (0, -6.0, 7.0), rot=(math.pi / 2 - 0.15, 0, 0), r2=2.4, verts=16), red,
                  bevel=0.3)
    lip = finish(torus(p + "_lip", 2.2, 0.6, (0, -7.8, 7.3), rot=(math.pi / 2 - 0.15, 0, 0)), pale)
    hole = finish(cyl(p + "_mouth", 1.5, 0.3, (0, -8.0, 7.3), rot=(math.pi / 2 - 0.15, 0, 0), verts=14), dark)
    for s in (-1, 1):
        finish(ball("%s_eye_%d" % (p, s), 1.7, (s * 2.6, -4.2, 10.4), (1, 0.6, 1.1), seg=14, rings=8), white)
        finish(ball("%s_pupil_%d" % (p, s), 0.9, (s * 2.6, -5.1, 10.3), (1, 0.5, 1.2), seg=10, rings=6), dark)
    for i in range(6):
        a = i * math.pi / 3 + math.pi / 6
        x, y = math.cos(a) * 4.4, math.sin(a) * 4.4 + 0.5
        leg = finish(cyl("%s_leg_%d" % (p, i), 1.3, 4.0, (x, y, 2.0), rot=(-math.sin(a) * 0.5, math.cos(a) * 0.5, 0),
                         r2=0.7, verts=10), red, bevel=0.2)
        finish(ball("%s_curl_%d" % (p, i), 1.0, (x * 1.25, y * 1.25 + 0.1, 0.8), seg=10, rings=6), red)
    return "octorok_torso"


def build_crab():
    """A red beach crab that digs in the sand: a wide shell, raised claws, eye stalks."""
    p = "crab"
    shell = mat(p + "_shell", (200, 60, 50), "clay", 0.45)
    belly = mat(p + "_belly", (246, 190, 160), "clay", 0.5)
    dark = mat(p + "_dark", (40, 20, 20), None, 0.4)
    body = finish(ball(p + "_torso", 5.6, (0, 0, 4.4), (1.25, 0.85, 0.55), seg=28, rings=14), shell)
    under = finish(ball(p + "_under", 5.0, (0, 0, 3.6), (1.2, 0.8, 0.35), seg=20, rings=10), belly)
    for s in (-1, 1):
        arm = finish(cyl("%s_arm_%d" % (p, s), 0.9, 4.0, (s * 6.2, -2.6, 5.6), rot=(0.6, s * 0.6, 0), verts=10), shell)
        claw = finish(ball("%s_claw_%d" % (p, s), 2.2, (s * 7.6, -4.6, 8.0), (0.8, 1.0, 1.2), seg=16, rings=10), shell)
        pincer = finish(cyl("%s_pincer_%d" % (p, s), 0.8, 2.6, (s * 7.4, -6.0, 9.6), rot=(0.9, 0, 0), r2=0.2, verts=8),
                        shell)
        stalk = finish(cyl("%s_stalk_%d" % (p, s), 0.35, 2.2, (s * 1.6, -3.0, 7.0), verts=8), shell)
        finish(ball("%s_eye_%d" % (p, s), 0.8, (s * 1.6, -3.0, 8.2), seg=10, rings=6), dark)
        for i in range(3):
            y = -1.0 + i * 1.8
            finish(cyl("%s_leg_%d_%d" % (p, s, i), 0.45, 4.4, (s * 6.2, y, 2.4), rot=(0, s * 1.0, 0), r2=0.25,
                       verts=8), shell)
    return "crab_torso"


def build_urchin():
    """A sea urchin too spiny to touch: a dark round test bristling with spines, pushed with a
    shield (16x16 sprite)."""
    p = "urchin"
    test = mat(p + "_test", (60, 50, 90), "clay", 0.5)
    spine = mat(p + "_spine", (230, 226, 240), None, 0.4)
    tip = mat(p + "_tip", (110, 140, 220), None, 0.4)
    body = finish(ball(p + "_torso", 4.8, (0, 0, 4.6), (1, 1, 0.9), seg=24, rings=14), test)
    k = 0
    for ring, (el, n) in enumerate([(70, 6), (35, 10), (5, 12)]):
        for i in range(n):
            az = 2 * math.pi * i / n + ring * 0.3
            e = math.radians(el)
            d = Vector((math.cos(az) * math.cos(e), math.sin(az) * math.cos(e), math.sin(e)))
            L = 4.2 if ring else 3.4
            c = Vector((0, 0, 4.6)) + d * (4.4 + L / 2)
            o = cyl("%s_spine_%d" % (p, k), 0.55, L, c, verts=6, r2=0.05)
            o.rotation_mode = "QUATERNION"
            o.rotation_quaternion = Vector((0, 0, 1)).rotation_difference(d)
            bpy.context.view_layer.update()
            finish(o, spine if k % 3 else tip, smooth=False)
            k += 1
    return "urchin_torso"


def build_owl():
    """A big wise owl perched on the sand: round body, ear tufts, large eyes, folded wings,
    brown-orange plumage (16x16 perched, 32x16 in flight)."""
    p = "owl"
    plum = mat(p + "_plumage", (200, 120, 60), "hair", 0.85)
    breast = mat(p + "_breast", (246, 214, 160), "hair", 0.85)
    dark = mat(p + "_dark", (60, 36, 24), None, 0.4)
    eye = mat(p + "_eye", (250, 220, 90), None, 0.3)
    beak = mat(p + "_beak", (230, 190, 90), None, 0.4)
    body = finish(ball(p + "_torso", 6.0, (0, 0.6, 7.0), (1.0, 0.9, 1.1), seg=28, rings=16), plum)
    chest = finish(ball(p + "_chest", 4.6, (0, -2.6, 6.6), (1.0, 0.6, 1.0), seg=20, rings=12), breast)
    head = finish(ball(p + "_head", 5.0, (0, -0.4, 14.0), (1.1, 0.95, 0.85), seg=28, rings=16), plum)
    rotate_about([head], Vector((0, 0, 11)), (1, 0, 0), -20)
    for s in (-1, 1):
        finish(ball("%s_disc_%d" % (p, s), 2.4, (s * 2.1, -4.0, 14.8), (1, 0.4, 1), seg=16, rings=8), breast)
        finish(ball("%s_eye_%d" % (p, s), 1.4, (s * 2.1, -4.6, 15.0), (1, 0.4, 1), seg=14, rings=8), eye)
        finish(ball("%s_pupil_%d" % (p, s), 0.7, (s * 2.1, -5.0, 15.0), (1, 0.4, 1), seg=10, rings=6), dark)
        finish(cyl("%s_tuft_%d" % (p, s), 1.2, 3.4, (s * 3.4, 0.0, 18.4), rot=(0, s * 0.45, 0), r2=0.1, verts=8),
               plum)
        finish(ball("%s_wing_%d" % (p, s), 3.4, (s * 5.2, 1.2, 7.4), (0.45, 1.0, 1.4), seg=16, rings=10), plum)
        finish(box("%s_foot_%d" % (p, s), (2.2, 2.6, 0.8), (s * 2.0, -1.6, 0.4)), beak, bevel=0.3)
    finish(cyl(p + "_beak", 0.8, 2.0, (0, -5.2, 13.6), rot=(math.pi / 2 + 0.6, 0, 0), r2=0.1, verts=8), beak)
    finish(cyl(p + "_tail", 2.6, 3.0, (0, 5.0, 3.0), rot=(-1.1, 0, 0), r2=1.0, verts=10), dark)
    return "owl_torso"


def build_chomper():
    """The chained guard beast of the village (16x16, black): a round, heavy, bristly boar-ball
    with tusks, a blunt snout and an iron collar, chained to its post."""
    p = "chomper"
    hide = mat(p + "_hide", (40, 40, 48), "hair", 0.7)
    iron = mat(p + "_iron", (150, 150, 160), "steel", 0.4, 0.8)
    tusk = mat(p + "_tusk", (250, 244, 220), None, 0.4)
    eye = mat(p + "_eye", (250, 250, 250), None, 0.3)
    pink = mat(p + "_snout", (200, 120, 130), "skin", 0.5)
    body = finish(ball(p + "_torso", 7.0, (0, 0, 7.2), (1, 1, 0.95), seg=32, rings=18), hide)
    collar = finish(torus(p + "_collar", 5.6, 0.9, (0, 1.2, 5.0), rot=(0.5, 0, 0)), iron)
    snout = finish(cyl(p + "_snoutc", 2.4, 2.2, (0, -6.6, 6.6), rot=(math.pi / 2, 0, 0), verts=16), pink, bevel=0.4)
    for s in (-1, 1):
        finish(ball("%s_nostril_%d" % (p, s), 0.5, (s * 0.9, -7.8, 6.8), seg=8, rings=6), hide)
        finish(cyl("%s_tusk_%d" % (p, s), 0.6, 3.2, (s * 3.0, -5.6, 4.8), rot=(-0.9, s * 0.4, 0), r2=0.1, verts=8),
               tusk)
        finish(ball("%s_eye_%d" % (p, s), 1.4, (s * 2.8, -5.4, 10.0), (1, 0.6, 1), seg=12, rings=8), eye)
        finish(ball("%s_pupil_%d" % (p, s), 0.6, (s * 2.8, -6.2, 10.0), seg=8, rings=6), hide)
        finish(ball("%s_ear_%d" % (p, s), 1.6, (s * 4.0, 0.0, 13.0), (0.6, 0.4, 1.0), seg=10, rings=6), hide)
        for f in (-1, 1):
            finish(cyl("%s_leg_%d_%d" % (p, s, f), 1.2, 2.0, (s * 3.6, f * 3.0, 1.0), verts=10), hide)
    return "chomper_torso"


def build_rupee():
    """A gem pickup: a long hexagonal crystal standing upright (8x16 sprite)."""
    p = "rupee"
    gem = mat(p + "_gem", (60, 110, 230), None, 0.15, 0.1)
    hi = mat(p + "_gemhi", (170, 210, 255), None, 0.1)
    bm = bmesh.new()
    top, bot = bm.verts.new((0, 0, 13.0)), bm.verts.new((0, 0, 1.0))
    ring_hi = [bm.verts.new((math.cos(a) * 3.0, math.sin(a) * 1.6, 10.0)) for a in [i * math.pi / 3 for i in range(6)]]
    ring_lo = [bm.verts.new((math.cos(a) * 3.0, math.sin(a) * 1.6, 4.0)) for a in [i * math.pi / 3 for i in range(6)]]
    for i in range(6):
        j = (i + 1) % 6
        bm.faces.new((top, ring_hi[i], ring_hi[j]))
        bm.faces.new((ring_hi[i], ring_lo[i], ring_lo[j], ring_hi[j]))
        bm.faces.new((ring_lo[j], ring_lo[i], bot))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    me = bpy.data.meshes.new(p + "_body")
    bm.to_mesh(me)
    bm.free()
    o = bpy.data.objects.new(p + "_body", me)
    bpy.context.scene.collection.objects.link(o)
    finish(o, gem, bevel=0.2, smooth=False)
    glint = finish(box(p + "_glint", (1.0, 0.4, 4.0), (-1.0, -1.5, 7.0)), hi)
    # tip it back so its long face shows to the top camera, as the sprite's upright gem does
    rotate_about([o, glint], Vector((0, 0, 1.0)), (1, 0, 0), 50)
    return "rupee_body"


# ----------------------------------------------------------------------------- pass 2: beach scenery

def build_palm():
    """A coconut palm for its 32x32 tile block: a curved ringed trunk, a crown of long fronds,
    coconuts under the crown, roots in a sandy mound."""
    p = "palm"
    bark = mat(p + "_bark", (150, 104, 62), "bark", 0.9)
    frond = mat(p + "_frond", (60, 150, 70), "frond", 0.8)
    frond_d = mat(p + "_frond_dark", (36, 110, 56), "frond", 0.8)
    nut = mat(p + "_coconut", (110, 72, 40), "clay", 0.6)
    sand = mat(p + "_sand", (236, 210, 156), "sand", 0.95)
    mound = finish(ball(p + "_mound", 8.0, (0, 0, 0), (1.2, 1.0, 0.25), seg=20, rings=8), sand)
    cut_below(mound, 0)
    segs = []
    z, x = 0.0, 0.0
    for i in range(8):
        r = 3.0 - i * 0.15
        seg = finish(cyl("%s_trunk_%d" % (p, i), r, 3.2, (x, 2.0, z + 1.6), rot=(0, 0.06 * i, 0), r2=r * 0.85,
                         verts=12), bark, bevel=0.3)
        segs.append(seg)
        z += 3.0
        x += 0.2 * i
    top = Vector((x, 2.0, z + 1.0))
    finish(ball(p + "_heart", 2.6, top, seg=14, rings=8), frond_d)
    for i in range(10):
        a = i * math.pi / 5 + 0.2
        m = frond if i % 2 else frond_d
        bpy.ops.mesh.primitive_grid_add(x_subdivisions=8, y_subdivisions=3, size=1)
        lf = _new("%s_frond_%d" % (p, i))
        for v in lf.data.vertices:          # leaf from the crown outwards: wide, narrow tip, drooping
            t = v.co.x + 0.5                # 0 at the crown .. 1 at the tip
            v.co.x = t * 15.0
            v.co.y *= 6.5 * (1.0 - 0.8 * t) * (0.5 + 2.0 * t * (1 - t))
            v.co.z = 2.0 * t - 9.0 * t * t + 1.5 * abs(v.co.y) * 0.3
        sol = lf.modifiers.new("t", "SOLIDIFY")
        sol.thickness = 0.5
        _apply(lf, sol)
        lf.location = top
        lf.rotation_euler = (0, 0, a)
        bpy.context.view_layer.update()
        finish(lf, m, smooth=True)
    for i in range(3):
        a = i * 2.1
        finish(ball("%s_nut_%d" % (p, i), 1.4, top + Vector((math.cos(a) * 1.8, math.sin(a) * 1.8 - 0.4, -2.2))), nut)
    return "palm_mound"


def build_beach_rock():
    """A round mossy beach rock with a sprouting weed (16x16 block)."""
    p = "rock"
    stone = mat(p + "_stone", (150, 100, 66), "stone", 0.9)
    moss = mat(p + "_moss", (70, 140, 70), "leaf", 0.9)
    r = finish(ball(p + "_body", 6.4, (0, 0, 3.4), (1.15, 1.0, 0.8), seg=24, rings=14), stone, subsurf=0)
    for v in r.data.vertices:
        v.co *= 1.0 + 0.06 * math.sin(v.co.x * 1.3) * math.cos(v.co.y * 1.1)
    cut_world(r, 0)
    for i, a in enumerate((0.0, 2.1, 4.2)):
        lf = finish(cyl("%s_sprout_%d" % (p, i), 1.0, 4.0, (math.cos(a) * 1.2, math.sin(a) * 1.2, 9.0),
                        rot=(math.sin(a) * 0.7, -math.cos(a) * 0.7, 0), r2=0.1, verts=6), moss)
    finish(ball(p + "_mosscap", 3.0, (0.8, 1.0, 7.4), (1.2, 1.0, 0.35), seg=14, rings=8), moss)
    return "rock_body"


def build_stake():
    """A weathered driftwood stake leaning in the sand, a band of rope and a tuft of weed."""
    p = "stake"
    wood = mat(p + "_wood", (130, 92, 56), "wood", 0.85)
    rope = mat(p + "_rope", (210, 190, 140), "cloth", 0.9)
    weed = mat(p + "_weed", (50, 130, 70), "leaf", 0.9)
    # a fairly upright post (the sprite's stake leans), so it stands out of the sand from above
    post = finish(cyl(p + "_post", 2.0, 16.0, (0, 0, 7.0), rot=(0.35, 0, 0.6), r2=1.5, verts=10), wood, bevel=0.3)
    cut_world(post, 0)
    head = finish(cyl(p + "_head", 2.7, 2.4, (1.6, -2.4, 13.4), rot=(0.35, 0, 0.6), verts=10), wood, bevel=0.4)
    band = finish(torus(p + "_rope", 2.15, 0.45, (0.8, -1.2, 8.8), rot=(0.35, 0, 0.6)), rope)
    for i, a in enumerate((0.0, 1.7, 3.4, 5.0)):
        finish(cyl("%s_weed_%d" % (p, i), 0.6, 3.0, (math.cos(a) * 1.6 - 1.0, math.sin(a) * 1.6 + 1.6, 1.2),
                   rot=(math.sin(a) * 0.6, -math.cos(a) * 0.6, 0), r2=0.1, verts=6), weed)
    return "stake_post"


def build_surf():
    """One 8x8 piece of the surf line: shallow water with a curling foam crest.  Pieces meet
    edge to edge: exactly 8 wide (x) and 8 deep (y), centred on the origin."""
    p = "surf"
    water = mat(p + "_water", (90, 140, 220), None, 0.2)
    foam = mat(p + "_foam", (246, 250, 255), "cloth", 0.6)
    slab = finish(box(p + "_slab", (8.0, 8.0, 0.6), (0, 0, 0.3)), water, smooth=False)
    crest = cyl(p + "_crest", 1.0, 8.0, (0, 0.5, 0.9), rot=(0, math.pi / 2, 0), verts=12)
    for v in crest.data.vertices:
        v.co.z *= 0.7
        v.co.y += 0.35 * math.sin(v.co.x * 0.8)   # local x runs along the crest after rotation
    finish(crest, foam)
    for i, x in enumerate((-2.5, 1.0, 3.2)):
        finish(ball("%s_bubble_%d" % (p, i), 0.6, (x, -1.6 + (i % 2) * 0.8, 0.7), (1.2, 1, 0.5), seg=8, rings=4), foam)
    return "surf_slab"


BUILDERS = {
    "hero_sword": build_hero_sword, "sword": build_sword, "octorok": build_octorok, "crab": build_crab,
    "urchin": build_urchin, "owl": build_owl, "chomper": build_chomper, "rupee": build_rupee,
    "palm": build_palm, "beach_rock": build_beach_rock, "stake": build_stake, "surf": build_surf,
    "hero": build_hero, "marin": build_marin, "tarin": build_tarin, "kid": build_kid,
    "hen": build_hen, "fox": build_fox, "pup": build_pup,
    "pot": build_pot, "bed": build_bed, "table": build_table, "dresser": build_dresser, "stool": build_stool,
    "tree": build_tree, "bush": build_bush,
    "house_tarin": lambda: build_house(48, 24, 15, 11),
    "house_shop": lambda: build_house(48, 40, 16, 13, sign=True),
    "house_madam": lambda: build_house(48, 40, 16, 13, chimney=True),
}


def build(name):
    clear()
    pivot = BUILDERS[name]()
    bpy.context.view_layer.update()
    print("%s: %d triangles, pivot %s" % (name, tris(), pivot))
    return pivot


if __name__ == "__main__" and "--model" in sys.argv:
    argv = sys.argv[sys.argv.index("--") + 1:]
    name = argv[argv.index("--model") + 1]
    build(name)
    if "--blend" in argv:
        bpy.ops.wm.save_as_mainfile(filepath=argv[argv.index("--blend") + 1])
