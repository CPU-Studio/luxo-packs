"""Tile rules for the ladx-diorama pack (Link's Awakening DX, Game Boy Color).

Writes the "tiles" list of pack.json from the key lists below; groups, models and the rest
of pack.json are kept.  Run: python3 ladx_rules.py PACK_DIR
"""
import json, sys

OW, IN = "overworld", "indoors"

# --- Overworld (Mabe Village and around) ---------------------------------------------
FENCE = ["2bf6f2a61a2038d3", "e3765950f19bc663"]
TALL_GRASS = ["c29b065f3c375dbd", "c207a3c8de19a7df", "6325bb6695beab4f", "350d59b2e05afff2"]
BUSH = ["406ad945abcf4a40", "01bef785838be407", "6d9fc03890405ea5", "fcc511294c0f7edf"]
CANOPY = ["492b9d328c2ce9f8", "36c0f4d6e79251d7", "c31d2a5b12dc7b10", "d8709366b3e60f69",
          "d31d168b4bac943d", "ff41d5adca894256", "6b48f7bd3fb33431", "132a34fb01c2a31b",
          "398dde249c451c57", "eb8a026aa028a5f1",
          # the plaza's big tree (middle columns)
          "35b0d4e14035282d", "3b037789cc480ff6", "12f65a62186e1210", "73d2b5bce69419e0"]
TRUNK = ["238d30d8c35d9261", "fd7df30a4c200d23", "4852c0a7caf1f661", "4999798ca445a605",
         "24af154e280f1ac5", "5ea946eb07a87dac", "58fe5551f852c329", "98b1cf62498b5942"]
HOUSE_WALL = ["8f59becb7661356c", "a3bc05737c3c783f", "8461c9b630e0ec76", "7acffbaf2e9a071b"]
HOUSE_DOOR = ["6aaeb93ddde05968", "9506524d5290920a", "b19d522bdbe0670d", "0cf91eea488d4629"]
ROOF = ["1ae6b0a0ad949de3", "1ce6ef9ce787e512",                       # Tarin's house
        "058f0c501af80636", "4c34d0eaa9d8ed48", "3eb45dbf758711ad",   # slate roofs
        "71992420388457da", "9ac87053c6c85433", "13723a873eb43c72",
        "0f6104f17c47248c", "85a75c81706d1548", "bd744d7db7f6a900",
        "1628e6468b7709d4", "55c1f83faa9ce38e", "76751903e0707d18",
        "cc03658f6fa7a2e0", "dd50ea8fa3225e49", "4a7ca7a7852da98c", "7ce89414ff9cf9b3"]
ROOF_FILL = "7058ca7f9c68cbea"   # plain fill: grass in palette 6, roof in palettes 1 and 4
STONE_WALL = ["22782b22aac2c058", "b6da38c924cafc98", "1c574d5119f6176a", "0468e4b7a7ab4e29"]
WATER = ["ce6908a9c1a30bb6"]
BANK = ["ba7c8100c1a0e419", "8056c80e2ce7f38b", "22f80a467de6c906", "4a95cef881bb89c5",
        "5f26ada14fe388c6", "733a3b4c26b899ea", "4b942270805d9740", "4531464691da2879",
        "681a4109f454ea7b", "9bb4f572fa56ade1"]

# --- Indoors (Tarin's house) ---------------------------------------------------------
IN_WALL = [
    # outer frame
    "ab5ac0212eaa0841", "ab2ffcf9de2cfbb2", "7d9d455039b202b5", "cc58776d14d651c3",
    "546480431bd0f409", "73860cff10bc4b51", "a8098281c3c46f71", "a901f6045fb176c4",
    # inner wall band and door frame
    "5fd168231e6da4e8", "baef0f45f5dffefa", "c7a63b1f93a935fc", "82a832b4ef6e191c",
    "d4bfcaf83645730b", "d8f23e840e997513", "9a769eb7039738b5", "230329ce943e83c3",
    "a945169ca4eb13aa", "c3b65c93f3015f9c", "bc089e2c847c3779", "ea5c93e7780b3cf5",
    # window / shelf on the back wall
    "dba10a6b62205989", "16f82dc27e559252"]
SHELF = ["cd64d8139f643f4c", "31de17ea32d3ad5b"]
BED = ["7d1fe8f0bf760d9b", "c0d1c23c883cd9d3", "cea944cb39362a2e", "168da448d7a1ba69",
       "9eb198e7ddf62e16", "8a852bcf82ecd9b2"]
DRESSER = ["5aae981751d16d2f", "37ff98bbd47ee9cd", "7e982dbc8556e713", "dc0785ffbd9eeed6"]
TABLE = ["eec8ad13b5e2dd8d", "fbab909fef6c43b0", "f4d2d3d46079c589", "8f788636dde05590",
         "e27630343a934986", "5cbf4f77a86e5d89"]
POT = ["b57f4935dd0d3eeb", "30a0536f49dd2f01", "bd2fe05ce2cc4989", "bb84b3b92531275e"]
STOOL = ["6e42d2e9a10a05c5", "e0b7fcc7a01ab134", "021135d42feb3922", "0542f71ac0e927c6"]

# Ground: grass, paths, paving, flowers, doorways, carpets and boards.  Floor is the layer
# default too; the explicit rules document the tiles and keep coverage honest.
WATER += ["cb05d6b5e6bc9845", "e6837ae5f0ee4886", "540f2c5640d22d0f"]   # animation frames
OW_FLOOR = ["0c9c323d74468d77", "11ab8eb60a0d88c8", "27b2d1b5901504aa", "29e294e2483d1260",
            "3388464ce43c63e1", "3eca17414ecaad30", "3f36909c575572ba", "409c9572a925f92f",
            "57fc89e14b38e341", "65f6c11a76c523ff", "75e40851a1f3a8f7", "7675575fc0886bb0",
            "77ef4cf357397e0d", "8b3e8fea9274a5c1", "8cf58a6500389d1c", "e6598283dfe3de0d",
            "f616a0e16fa9ecbb"] + HOUSE_DOOR
IN_FLOOR = ["03e4c717905362f1", "0aaede06cf0458de", "0d48a9509975917e", "44a9447a9c84f49b",
            "7675575fc0886bb0", "8462741fc549012b", "94e766a0bee7d37b", "bdd2ad583845fd4f",
            "ffcf4a265f76a9eb"]


# --- Pass 2: the way south (A0, B0, C0, D0) and Toronbo Shores (E0, F0, F1, F2) -------------
# The village's outskirts (A0, B0) stay in "overworld"; rooms from 0xC0 down are the "shore"
# scene, because the cliff tiles there are the same shapes the village uses for its river banks
# (low platforms), and on the way to the beach they are tall cliffs.
SH = "shore"
# Cliff faces (the brown striped drop below a plateau): never walked in front of
CLIFF_FACE = ["6bc618fb10c37747", "4e9a82086bb23a72", "356dc458c86bb74a", "315da7a440015f22",
              "53ca56e0a5e192a4", "9e9aaf10d5ce002f", "00d9ea2946bb176c", "d5fb81affd1bf89d",
              "94f2f7e1339786ca", "8263e409e9a8e1ec",
              # the river bank shapes, as cliffs here
              "4b942270805d9740", "733a3b4c26b899ea", "681a4109f454ea7b", "8056c80e2ce7f38b",
              "5f26ada14fe388c6", "4531464691da2879",
              "1e2ec7ce3fbc308c"]  # 0.2.1: the rounded corner by the sword (F2)
# Cliff rims (the light edge of a plateau, palette 1)
CLIFF_RIM = ["6e51b9b5ab509796", "234da81aa62af913", "8b2f3a18746e8708", "5e167a436d489aa1",
             "fb44c55816dc7041", "ba7c8100c1a0e419", "22f80a467de6c906", "4a95cef881bb89c5",
             "9bb4f572fa56ade1",
             "f9e91d0504ae58a6"]  # 0.2.1: the rim's corner by the sword (F2)
STAIRS = ["9f2cd1d4d4e0ff65"]
SIGN = ["8176e2136b925e4a", "056435a2368f94b5", "5dcb508130dfcdd7", "2a2d604aecb9939a"]
SAND = ["8f189558611e9fad", "6a2c521067ffa2bc", "ed979ab71d814b84", "5ad4ced29d9c4f87", "ba40467f415388ff"]
# The sea: four animation frames of the open water and of the surf line along the beach
SEA = ["117f3cae8846482a", "3484ba637110ad61", "7fa00bfb5d5e088b", "cf7848e2f76bf383",
       "5ddf2c7cdb41dc8a", "2d57e4721c0678a3", "bfdb5479880a4ee3", "a442b5127eeb4407"]
SURF = ["7b2eb884330b29ee", "2d64c9ccd84eb22b", "4ee7361f76e63a8d", "e012b5841b6d3e77",
        "72257c86f2841643", "78604704f136199b", "fb14b47ee619705d", "27f156b8e200dab0"]
# Palms: a 4x4 block (crown, trunk, base); tile fallback when only part is on screen
PALM_CROWN = [("a89b1d22ea1e72af", 5), ("7a204ec990e46782", 5), ("7259cdb8d0694cdf", 5),
              ("b88b21b409305403", 5), ("bd5ea9f1cb1b85a3", 5), ("1a272ec25d4160a8", 5),
              ("4ad20d8c3575f317", 0), ("afa8e8a4b093dbc8", 0)]
PALM_TRUNK = ["8d520e4b698ae056", "74825212a5766ef2", "4d80cb5d60bd87a3", "302f1a15d6f45c06"]
PALM_BASE = ["65942fcbff0f6ce8", "078ddc8b83a7deae", "fff1a6695d456875", "b77bf6e2f06a7d92"]
# Things lying on the sand (2x2 each): driftwood stakes, seaweed, a round mossy rock
STAKE = ["2bb0b0411d930670", "981b0300be4b0265", "42f8dd8f2f45efef", "9c95d67a14bc99ec"]
SEAWEED = ["9cc8888346b4fbb3", "6560156a9ebc09e2", "17919a14ff03e760", "40b9582d22c908df"]
ROCK = ["84daa164626ce1f8", "628eebd78f087fdb", "364f4bfce9e5d5f1", "04e02a1747db3526"]
# Village outskirts (A0, A1, B0): the same cliffs, and a roof in palette 7
OW_CLIFF_FACE = ["6bc618fb10c37747", "4e9a82086bb23a72", "356dc458c86bb74a", "315da7a440015f22",
                 "53ca56e0a5e192a4", "9e9aaf10d5ce002f", "00d9ea2946bb176c", "d5fb81affd1bf89d"]
OW_CLIFF_RIM = ["6e51b9b5ab509796", "234da81aa62af913", "8b2f3a18746e8708", "5e167a436d489aa1"]


def rule(key, scene, role, **kw):
    r = {"key": key, "scene": scene, "role": role}
    r.update(kw)
    return r


def tiles():
    t = []
    t += [rule(k, OW, "wall", height=8, _note="fence post") for k in FENCE]
    t += [rule(k, OW, "decoration", style="relief", height=4, _note="tall grass") for k in TALL_GRASS]
    t += [rule(k, OW, "solid", style="relief", height=9, _note="bush") for k in BUSH]
    t += [rule(k, OW, "wall", style="relief", height=18, _note="tree canopy") for k in CANOPY]
    t += [rule(k, OW, "wall", style="relief", height=12, _note="tree trunk") for k in TRUNK]
    t += [rule(k, OW, "wall", height=14, _note="house wall") for k in HOUSE_WALL]
    t += [rule(k, OW, "wall", height=18, _note="roof") for k in ROOF]
    t += [rule(ROOF_FILL, OW, "wall", pal=p, height=18, _note="roof") for p in (1, 4)]
    t += [rule(k, OW, "wall", height=12, _note="stone wall") for k in STONE_WALL]
    t += [rule(k, OW, "water") for k in WATER]
    t += [rule(k, OW, "platform", height=3, _note="river bank") for k in BANK]
    t += [rule(k, IN, "wall", _note="house wall") for k in IN_WALL]
    t += [rule(k, IN, "wall", height=12, _note="shelf") for k in SHELF]
    t += [rule(k, IN, "solid", height=6, _note="bed") for k in BED]
    t += [rule(k, IN, "solid", height=10, _note="dresser") for k in DRESSER]
    t += [rule(k, IN, "solid", height=7, _note="table") for k in TABLE]
    t += [rule(k, IN, "solid", style="relief", height=7, _note="pot") for k in POT]
    t += [rule(k, IN, "solid", height=6, _note="stool") for k in STOOL]
    t += [rule(k, OW, "floor") for k in OW_FLOOR]
    t += [rule(ROOF_FILL, OW, "floor", pal=6, _note="grass")]
    t += [rule(k, IN, "floor") for k in IN_FLOOR]
    # pass 2: the village outskirts
    t += [rule(k, OW, "wall", height=10, _note="cliff") for k in OW_CLIFF_FACE]
    t += [rule(k, OW, "platform", height=4, _note="cliff rim") for k in OW_CLIFF_RIM]
    t += [rule(ROOF_FILL, OW, "wall", pal=7, height=18, _note="roof")]
    return t


def shore_tiles(models):
    """The shore scene: its own rules first, then a copy of every overworld rule it does not
    replace (paths, grass, trees and bushes appear on the way down too)."""
    t = []
    t += [rule(k, SH, "wall", height=10, _note="cliff") for k in CLIFF_FACE]
    t += [rule(k, SH, "platform", height=4, _note="cliff rim") for k in CLIFF_RIM]
    t += [rule(k, SH, "floor", _note="stairs") for k in STAIRS]
    t += [rule(k, SH, "solid", height=6, _note="sign") for k in SIGN]
    t += [rule(k, SH, "floor", _note="sand") for k in SAND]
    t += [rule(k, SH, "water", _note="sea") for k in SEA]
    if "surf" in models:
        t += [rule(k, SH, "water", model="surf", _note="surf line") for k in SURF]
    else:
        t += [rule(k, SH, "water", _note="surf line") for k in SURF]
    t += [rule(k, SH, "wall", pal=p, style="relief", height=16, _note="palm crown") for k, p in PALM_CROWN]
    t += [rule(k, SH, "wall", style="relief", height=12, _note="palm trunk") for k in PALM_TRUNK]
    t += [rule(k, SH, "decoration", style="relief", height=2, _note="palm roots") for k in PALM_BASE]
    t += [rule(k, SH, "decoration", style="relief", height=5, _note="driftwood stake") for k in STAKE]
    t += [rule(k, SH, "decoration", style="relief", height=2, _note="seaweed") for k in SEAWEED]
    t += [rule(k, SH, "solid", style="relief", height=8, _note="beach rock") for k in ROCK]
    have = set((r["key"], r.get("pal")) for r in t)
    for r in tiles():
        if r["scene"] != OW or (r["key"], r.get("pal")) in have or (r["key"], None) in have:
            continue
        c = dict(r)
        c["scene"] = SH
        t.append(c)
    return t


SCENES = [
    # 0.2.1: Link dying and the game-over menu (0xC4D1 is 1 from the death to the menu): flat.
    {"id": "gameover", "view": "flat", "when": "ram[0x04D1] == 1"},
    {"id": "indoors", "view": "top", "when": "ram[0x1BA5] == 1", "camera": {"pitch": 60}},
    # rooms 0xC0 and below: the cliffs south of the village and Toronbo Shores
    {"id": "shore", "view": "top", "when": "ram[0x1BA5] == 0 && ram[0x3FF6] >= 0xC0", "camera": {"pitch": 60}},
    {"id": "overworld", "view": "top", "when": "ram[0x1BA5] == 0", "camera": {"pitch": 60}},
]
HUD = [
    {"window": True},   # the status bar is the window layer
    # the dialogue box is drawn into the background map, at the bottom or the top
    {"x": [8, 152], "y": [80, 120], "when": "(ram[0x19F] & 0x80) != 0"},
    {"x": [8, 152], "y": [8, 48], "when": "ram[0x19F] != 0 && (ram[0x19F] & 0x80) == 0"},
]


MODELS2 = {
    "hero_sword": {"file": "models/hero_sword.glb", "clip": "walk", "clip_px": 16},
    "sword": {"file": "models/sword.glb"}, "octorok": {"file": "models/octorok.glb"},
    "crab": {"file": "models/crab.glb"}, "urchin": {"file": "models/urchin.glb"}, "owl": {"file": "models/owl.glb"},
    "chomper": {"file": "models/chomper.glb"}, "rupee": {"file": "models/rupee.glb"},
    "palm": {"file": "models/palm.glb"}, "beach_rock": {"file": "models/beach_rock.glb"},
    "stake": {"file": "models/stake.glb"}, "surf": {"file": "models/surf.glb"},
}


if __name__ == "__main__":
    import os
    path = sys.argv[1].rstrip("/") + "/pack.json"
    p = json.load(open(path))
    p["version"] = "0.2.0"
    for k, v in MODELS2.items():
        if os.path.exists(os.path.join(sys.argv[1], v["file"])):
            p.setdefault("models", {})[k] = v
    p["scenes"] = SCENES
    p["hud"] = HUD
    p["tiles"] = tiles() + shore_tiles(set(p.get("models", {})))
    json.dump(p, open(path, "w"), indent=1)
    print(len(p["tiles"]), "tile rules written to", path)
