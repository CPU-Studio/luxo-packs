"""Sprite groups for the ladx-diorama pack.

Reads the tile layouts from propose_groups' proposals (proposals.json beside this file:
group_N -> tiles; tile keys only, no art) and writes pack.json "groups", in order.
Run: python3 ladx_groups.py PACK_DIR
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
P = {p["id"]: p["tiles"] for p in json.load(open(os.path.join(HERE, "proposals.json")))}


def quad(a, b, c, d, flip=False):
    """A 16x16 sprite from its four 8x8 tiles (top-left, bottom-left, top-right, bottom-right)."""
    t = lambda dx, dy, k: {"dx": dx, "dy": dy, "key": k, "hflip": flip, "vflip": False}
    return [t(0, 0, a), t(0, 8, b), t(8, 0, c), t(8, 8, d)]


def mirror(tiles):
    """The same sprite drawn mirrored (hflip), as the game does for the other side."""
    return [{"dx": 8 - t["dx"], "dy": t["dy"], "key": t["key"], "hflip": not t.get("hflip", False),
             "vflip": t.get("vflip", False)} for t in tiles]


# Poses the proposals missed (from the walk check: frames without the player model)
P["group_201"] = quad("acf2e1e0e15810f9", "2647baeb3069ebcf", "2210dcdd1e89c0d3", "cd310aaf39d5bf90")
P["group_202"] = mirror(P["group_201"])
P["group_203"] = quad("7cbacaa40aae7269", "dd3f2888fdb010ab", "7cbacaa40aae7269", "dd3f2888fdb010ab")
P["group_203"][2]["hflip"] = P["group_203"][3]["hflip"] = True
P["group_204"] = quad("867c5cacf96ed21d", "bd34d38ccc19839a", "ab073f5d3f29c72f", "5622d91f8528b051")
P["group_205"] = mirror(P["group_27"])
P["group_206"] = mirror(P["group_42"])

# (proposal number, id, object, facing, extra fields)
HERO = {"model": "hero", "model_at": [8, 8]}
SPEC = [
    # Link in tall grass first (his 4 tiles plus the grass blades at his feet)
    (102, "link_grass_south_1", "player", "south", HERO),
    (30, "link_grass_north_1", "player", "north", HERO),
    (33, "link_grass_north_2", "player", "north", HERO),
    (37, "link_grass_north_3", "player", "north", HERO),
    (45, "link_grass_north_4", "player", "north", HERO),
    (48, "link_grass_north_5", "player", "north", HERO),
    (46, "link_grass_east_1", "player", "east", HERO),
    (47, "link_grass_east_2", "player", "east", HERO),
    (34, "link_grass_west_1", "player", "west", HERO),
    (49, "link_grass_west_2", "player", "west", HERO),
    # Link walking
    (7, "link_south_1", "player", "south", HERO),
    (10, "link_south_2", "player", "south", HERO),
    (39, "link_south_3", "player", "south", HERO),
    (44, "link_south_4", "player", "south", HERO),
    (15, "link_shield_south_1", "player", "south", HERO),
    (22, "link_shield_south_2", "player", "south", HERO),
    (38, "link_east_1", "player", "east", HERO),
    (43, "link_east_2", "player", "east", HERO),
    (26, "link_shield_east_1", "player", "east", HERO),
    (31, "link_shield_east_2", "player", "east", HERO),
    (32, "link_shield_east_3", "player", "east", HERO),
    (41, "link_shield_east_4", "player", "east", HERO),
    (14, "link_west_1", "player", "west", HERO),
    (16, "link_west_2", "player", "west", HERO),
    (23, "link_west_3", "player", "west", HERO),
    (28, "link_west_4", "player", "west", HERO),
    (201, "link_north_noshield_1", "player", "north", HERO),
    (202, "link_north_noshield_2", "player", "north", HERO),
    (204, "link_north_3", "player", "north", HERO),
    (203, "link_hold_up", "player", "south", HERO),
    (40, "link_north_1", "player", "north", HERO),
    (50, "link_north_2", "player", "north", HERO),
    # Link in bed: the model sinks into the bed so his top half shows above the blanket
    (35, "link_in_bed", "player", "south", dict(HERO, offset=-7)),
    (36, "bed_blanket", "blanket", None, {"offset": 6, "height": 1}),
    # People
    (18, "marin_south_1", "marin", "south", {"model": "marin"}),
    (19, "marin_south_2", "marin", "south", {"model": "marin"}),
    (27, "marin_west_1", "marin", "west", {"model": "marin"}),
    (42, "marin_west_2", "marin", "west", {"model": "marin"}),
    (205, "marin_east_1", "marin", "east", {"model": "marin"}),
    (206, "marin_east_2", "marin", "east", {"model": "marin"}),
    (8, "tarin_south_1", "tarin", "south", {"model": "tarin"}),
    (20, "tarin_south_2", "tarin", "south", {"model": "tarin"}),
    (9, "kid_1", "villager", None, {"model": "kid"}),
    (12, "kid_2", "villager", None, {"model": "kid"}),
    # Animals
    (17, "fox_east_1", "fox", "east", {"model": "fox"}),
    (21, "fox_east_2", "fox", "east", {"model": "fox"}),
    (24, "fox_west_1", "fox", "west", {"model": "fox"}),
    (29, "fox_west_2", "fox", "west", {"model": "fox"}),
    (3, "hen_1", "hen", None, {"model": "hen"}),
    (4, "hen_2", "hen", None, {"model": "hen"}),
    (11, "hen_3", "hen", None, {"model": "hen"}),
    (13, "hen_4", "hen", None, {"model": "hen"}),
    (5, "pup_1", "pup", None, {"model": "pup"}),
    (6, "pup_2", "pup", None, {"model": "pup"}),
    (1, "butterfly_1", "butterfly", None, {"offset": 10, "height": 1}),
    (2, "butterfly_2", "butterfly", None, {"offset": 10, "height": 1}),
    # Grass blades drawn over feet in tall grass: the relief grass does that job in 3D
    (25, "grass_blades", "grass_blades", None, {"hide": True}),
    # Painted drop shadow (a dark oval): models cast their own
    (101, "drop_shadow", "shadow", None, {"hide": True}),
]


def bg_block(rows, pal=None):
    """Tile layout from rows of keys (8x8 cells, None = skip).  pal: {key: palette}."""
    tiles = []
    for j, row in enumerate(rows):
        for i, k in enumerate(row):
            if k:
                t = {"dx": 8 * i, "dy": 8 * j, "key": k}
                if pal and k in pal:
                    t["pal"] = pal[k]
                tiles.append(t)
    return tiles


W1, W2, D1, D2 = "8f59becb7661356c", "a3bc05737c3c783f", "6aaeb93ddde05968", "9506524d5290920a"
W3, W4, D3, D4 = "8461c9b630e0ec76", "7acffbaf2e9a071b", "b19d522bdbe0670d", "0cf91eea488d4629"
FRONT = [[W1, W2, D1, D2, W1, W2], [W3, W4, D3, D4, W3, W4]]
SCENERY = [
    # (id, object, model, scene, rows, palettes)
    ("house_shop", "house", "house_shop", "overworld",
     [["058f0c501af80636", "4c34d0eaa9d8ed48", "4c34d0eaa9d8ed48", "4c34d0eaa9d8ed48", "4c34d0eaa9d8ed48", "3eb45dbf758711ad"],
      ["71992420388457da", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "9ac87053c6c85433"],
      ["71992420388457da", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "9ac87053c6c85433"],
      ["13723a873eb43c72", "0f6104f17c47248c", "85a75c81706d1548", "bd744d7db7f6a900", "1628e6468b7709d4", "55c1f83faa9ce38e"]]
     + FRONT, {"7058ca7f9c68cbea": 1}),
    ("house_madam", "house", "house_madam", "overworld",
     [["058f0c501af80636", "4c34d0eaa9d8ed48", "cc03658f6fa7a2e0", "dd50ea8fa3225e49", "4c34d0eaa9d8ed48", "3eb45dbf758711ad"],
      ["71992420388457da", "7058ca7f9c68cbea", "4a7ca7a7852da98c", "7ce89414ff9cf9b3", "7058ca7f9c68cbea", "9ac87053c6c85433"],
      ["71992420388457da", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "7058ca7f9c68cbea", "9ac87053c6c85433"],
      ["13723a873eb43c72", "76751903e0707d18", "76751903e0707d18", "76751903e0707d18", "76751903e0707d18", "55c1f83faa9ce38e"]]
     + FRONT, {"7058ca7f9c68cbea": 4}),
    ("house_tarin", "house", "house_tarin", "overworld",
     [["1ae6b0a0ad949de3"] * 6, ["1ce6ef9ce787e512"] * 6] + FRONT, None),
    ("tree", "tree", "tree", "overworld",
     [["492b9d328c2ce9f8", "36c0f4d6e79251d7", "c31d2a5b12dc7b10", "d8709366b3e60f69"],
      ["d31d168b4bac943d", "ff41d5adca894256", "6b48f7bd3fb33431", "132a34fb01c2a31b"],
      ["238d30d8c35d9261", "fd7df30a4c200d23", "4852c0a7caf1f661", "4999798ca445a605"],
      ["24af154e280f1ac5", "5ea946eb07a87dac", "58fe5551f852c329", "98b1cf62498b5942"]], None),
    # the crowns of trees standing in rows (only their tops are drawn)
    ("crown_a", "tree", "crown", "overworld",
     [["492b9d328c2ce9f8", "36c0f4d6e79251d7"], ["d31d168b4bac943d", "ff41d5adca894256"]], None),
    ("crown_b", "tree", "crown", "overworld",
     [["c31d2a5b12dc7b10", "d8709366b3e60f69"], ["6b48f7bd3fb33431", "132a34fb01c2a31b"]], None),
    ("crown_c", "tree", "crown", "overworld",
     [["398dde249c451c57", "36c0f4d6e79251d7"], ["d31d168b4bac943d", "ff41d5adca894256"]], None),
    ("bush", "bush", "bush", "overworld",
     [["406ad945abcf4a40", "01bef785838be407"], ["6d9fc03890405ea5", "fcc511294c0f7edf"]], None),
    ("bed", "bed", "bed", "indoors",
     [["7d1fe8f0bf760d9b", "c0d1c23c883cd9d3"], ["cea944cb39362a2e", "168da448d7a1ba69"],
      ["cea944cb39362a2e", "168da448d7a1ba69"], ["9eb198e7ddf62e16", "8a852bcf82ecd9b2"]], None),
    ("table", "table", "table", "indoors",
     [["eec8ad13b5e2dd8d", "fbab909fef6c43b0", "fbab909fef6c43b0", "f4d2d3d46079c589"],
      ["8f788636dde05590", "e27630343a934986", "e27630343a934986", "5cbf4f77a86e5d89"]], None),
    ("cabinet", "cabinet", "dresser", "indoors",
     [["5aae981751d16d2f", "37ff98bbd47ee9cd"], ["7e982dbc8556e713", "dc0785ffbd9eeed6"]], None),
    ("pot", "pot", "pot", "indoors",
     [["b57f4935dd0d3eeb", "30a0536f49dd2f01"], ["bd2fe05ce2cc4989", "bb84b3b92531275e"]], None),
    ("stool", "stool", "stool", "indoors",
     [["6e42d2e9a10a05c5", "e0b7fcc7a01ab134"], ["021135d42feb3922", "0542f71ac0e927c6"]], None),
]


# Where the model's pivot (the house walls' footprint centre, the tree trunk) stands, from the
# block's top-left: a house's front wall stands where its roof tiles end (the wall tiles
# below are the wall seen from the front; the model's porch covers them).
MODEL_AT = {"house_tarin": [24, 4], "house_shop": [24, 12], "house_madam": [24, 12], "tree": [16, 20]}


# ----------------------------------------------------------------------------- pass 2
# The way south and Toronbo Shores.  Layouts from propose_groups over dumps/route and
# dumps/swing (proposals2.json, keys only) and Link's sword poses (sword_poses.json, built by
# analysis/sword_poses.py from the every-frame dumps/swing1).
P2 = {p["id"]: p["tiles"] for p in json.load(open(os.path.join(HERE, "proposals2.json")))}
POSES = json.load(open(os.path.join(HERE, "sword_poses.json")))
HAS_SWORD = "ram[0x1B4E] != 0"          # the sword level (0xDB4E): 0 until the beach
SH = "shore"
SWORD_HERO = {"model": "hero_sword", "model_at": [8, 8]}
SPEC2 = [
    # Link's body while swinging, on frames whose blade is not next to him (wind-up, spin)
    (4, "link_swing_body_w", "player", "west", dict(SWORD_HERO, clip="swing_in_r")),
    (25, "link_swing_body_w2", "player", "west", dict(SWORD_HERO, clip="swing_in_r")),
    (41, "link_swing_body_n", "player", "north", dict(SWORD_HERO, clip="swing_in_r")),
    (14, "link_swing_body_n2", "player", "north", dict(SWORD_HERO, clip="swing_in_r")),
    (42, "link_swing_body_e", "player", "east", dict(SWORD_HERO, clip="swing_in_l")),
    (17, "link_swing_body_e2", "player", "east", dict(SWORD_HERO, clip="swing_out")),
    (21, "link_swing_body_s", "player", "south", dict(SWORD_HERO, clip="swing_in_r")),
    (55, "link_swing_body_s2", "player", "south", dict(SWORD_HERO, clip="swing_in_r")),
    # Link: pushing the sea urchin with the shield, hopping off a ledge, in tall grass facing west
    (58, "link_push_e1", "player", "east", {"model": "hero", "model_at": [8, 8]}),
    (59, "link_push_e2", "player", "east", {"model": "hero", "model_at": [8, 8]}),
    (57, "link_hop_s", "player", "south", {"model": "hero", "model_at": [8, 8]}),
    (60, "link_hold_s", "player", "south", dict(SWORD_HERO, clip="hold_up")),
    (36, "link_grass_west_3", "player", "west", {"model": "hero", "model_at": [8, 8]}),
    (40, "link_grass_west_4", "player", "west", {"model": "hero", "model_at": [8, 8]}),
    # The blade alone (a swing or spin frame whose body did not match): flat, at hand height
    (26, "blade_1", "blade", None, {"offset": 6, "height": 1}),
    (35, "blade_2", "blade", None, {"offset": 6, "height": 1}),
    (46, "blade_3", "blade", None, {"offset": 6, "height": 1}),
    (7, "blade_4", "blade", None, {"offset": 6, "height": 1}),
    (9, "blade_5", "blade", None, {"offset": 6, "height": 1}),
    (13, "blade_6", "blade", None, {"offset": 6, "height": 1}),
    (31, "blade_7", "blade", None, {"offset": 6, "height": 1}),
    (47, "blade_8", "blade", None, {"offset": 6, "height": 1}),
    # The sword in the sand at the water's edge
    (2, "sword_in_sand", "sword", None, {"model": "sword"}),
    # Enemies
    (12, "octorok_s1", "octorok", "south", {"model": "octorok"}),
    (15, "octorok_s2", "octorok", "south", {"model": "octorok"}),
    (24, "octorok_n1", "octorok", "north", {"model": "octorok"}),
    (30, "octorok_n2", "octorok", "north", {"model": "octorok"}),
    (33, "octorok_w1", "octorok", "west", {"model": "octorok"}),
    (52, "octorok_w2", "octorok", "west", {"model": "octorok"}),
    (11, "octorok_e1", "octorok", "east", {"model": "octorok"}),
    (34, "octorok_e2", "octorok", "east", {"model": "octorok"}),
    (53, "octorok_rock", "rock_shot", None, {"offset": 3, "height": 3}),
    (8, "crab_1", "crab", None, {"model": "crab"}),
    (10, "crab_2", "crab", None, {"model": "crab"}),
    (28, "crab_dig", "crab", None, {"model": "crab", "offset": -4}),
    (18, "sand_puff", "sand_puff", None, {"height": 1}),
    (3, "urchin_1", "urchin", None, {"model": "urchin"}),
    (20, "urchin_2", "urchin", None, {"model": "urchin"}),
    (22, "urchin_3", "urchin", None, {"model": "urchin"}),
    (29, "urchin_4", "urchin", None, {"model": "urchin"}),
    # Creatures and people on the way
    (38, "owl_perched", "owl", None, {"model": "owl"}),
    (48, "owl_flying", "owl", None, {"model": "owl", "offset": 10}),
    (27, "chomper_1", "chomper", None, {"model": "chomper"}),
    (44, "chomper_2", "chomper", None, {"model": "chomper"}),
    (45, "chomper_3", "chomper", None, {"model": "chomper"}),
    (49, "chomper_4", "chomper", None, {"model": "chomper"}),
    (50, "chomper_5", "chomper", None, {"model": "chomper"}),
    (56, "chain_2", "chain", None, {"height": 2, "offset": 2}),
    (5, "chain_1", "chain", None, {"height": 2, "offset": 2}),
    (16, "kid_3", "villager", None, {"model": "kid"}),
    (19, "kid_4", "villager", None, {"model": "kid"}),
    (37, "kid_5", "villager", None, {"model": "kid"}),
    (51, "kid_6", "villager", None, {"model": "kid"}),
    (32, "ball", "ball", None, {"offset": 4, "height": 4}),
    # Pickups and small effects
    (6, "rupee", "rupee", None, {"model": "rupee"}),
    (23, "heart", "heart", None, {"offset": 4, "height": 2}),
    (39, "shield_held", "shield_item", None, {"offset": 14, "height": 1}),
    (54, "sparkle", "sparkle", None, {"offset": 8, "height": 1}),
    (1, "ripple", "ripple", None, {"height": 1}),
]
PALM = [["a89b1d22ea1e72af", "7a204ec990e46782", "7259cdb8d0694cdf", "b88b21b409305403"],
        ["bd5ea9f1cb1b85a3", "4ad20d8c3575f317", "afa8e8a4b093dbc8", "1a272ec25d4160a8"],
        ["8d520e4b698ae056", "74825212a5766ef2", "4d80cb5d60bd87a3", "302f1a15d6f45c06"],
        ["65942fcbff0f6ce8", "078ddc8b83a7deae", "fff1a6695d456875", "b77bf6e2f06a7d92"]]
# Poses the walk check found without a group (ledge hops facing the viewer, two shoves), and the
# small shadow drawn under Link while he is in the air (the model casts its own)
EXTRA2 = [
    ("link_hop_s2", "player", "south", quad("e72f47e5972bae9e", "ff7d9216a147c613", "e72f47e5972bae9e", "ff7d9216a147c613", False)),
    ("link_hop_s3", "player", "south", quad("8e45d72acfe65b24", "ed5e7c244e655076", "8e45d72acfe65b24", "ed5e7c244e655076", False)),
    ("link_shove_w", "player", "west", quad("7f18101c694fd8c3", "adeb4b91e42f4a46", "297d6dfe8818f511", "c5b61d5dccba602d")),
    ("link_shove_e", "player", "east", quad("991188143fdde692", "19609d1815a21585", "8a90d74f2db1d25d", "fc701a3c5049e381")),
]
for _g in EXTRA2[:2]:   # the right half is the left half mirrored
    _g[3][2]["hflip"] = _g[3][3]["hflip"] = True
HOP_SHADOW = [{"dx": 0, "dy": 0, "key": "a3ddafbab8edc7b4", "hflip": False, "vflip": False}]
SHORE_SCENERY = [
    # (id, object, model, rows, model_at)
    ("palm", "palm", "palm", PALM, [16, 26]),
    ("stake", "stake", "stake", [["2bb0b0411d930670", "981b0300be4b0265"], ["42f8dd8f2f45efef", "9c95d67a14bc99ec"]], None),
    ("beach_rock", "rock", "beach_rock", [["84daa164626ce1f8", "628eebd78f087fdb"], ["364f4bfce9e5d5f1", "04e02a1747db3526"]], None),
    ("bush_shore", "bush", "bush", [["406ad945abcf4a40", "01bef785838be407"], ["6d9fc03890405ea5", "fcc511294c0f7edf"]], None),
]


def groups2(available_models, pass1_player):
    out = []
    # Link's sword poses: body + blade (or the sword over his head), first: they are the largest
    for v in POSES:
        g = {"id": "link_" + v["pose"] + "_" + v["id"].split("_")[1], "object": "player", "facing": v["facing"],
             "tiles": v["tiles"], "model": "hero_sword", "model_at": [8, 8], "clip": v["pose"]}
        out.append(g)
    for n, gid, obj, facing, extra in SPEC2:
        g = {"id": gid, "object": obj}
        if facing:
            g["facing"] = facing
        g["tiles"] = P2["group_%d" % n]
        for k, v in extra.items():
            if k in ("model", "model_at", "clip") and extra.get("model") not in available_models:
                continue
            g[k] = v
        out.append(g)
    # (Link's ordinary poses keep the plain hero model: the sprite shows no sword while he
    # walks.  Copies with "when": HAS_SWORD and the sword-carrying model were tried, but validate
    # reads a group with a condition as hiding the same tiles' group after it.)
    for gid, obj, model, rows, at in SHORE_SCENERY:
        if model not in available_models:
            continue
        g = {"id": gid, "object": obj, "layer": "bg", "scene": SH, "tiles": bg_block(rows), "model": model}
        if at:
            g["model_at"] = at
        out.append(g)
    return out


def groups(available_models):
    out = []
    # The plaza's big tree has a doorway in its trunk: keep its own tiles (no model, so the
    # entrance stays visible) as one raised block, and stop the crown groups splitting it.
    out.append({"id": "plaza_tree", "object": "plaza_tree", "layer": "bg", "scene": "overworld",
                "role": "wall", "height": 14, "tiles": bg_block([
                    ["492b9d328c2ce9f8", "36c0f4d6e79251d7", "35b0d4e14035282d", "35b0d4e14035282d", "c31d2a5b12dc7b10", "d8709366b3e60f69"],
                    ["d31d168b4bac943d", "ff41d5adca894256", "3b037789cc480ff6", "3b037789cc480ff6", "6b48f7bd3fb33431", "132a34fb01c2a31b"],
                    ["238d30d8c35d9261", "fd7df30a4c200d23", "12f65a62186e1210", "12f65a62186e1210", "4852c0a7caf1f661", "4999798ca445a605"]])})
    for gid, obj, model, scene, rows, pal in SCENERY:
        if model not in available_models:
            continue
        g = {"id": gid, "object": obj, "layer": "bg", "scene": scene, "tiles": bg_block(rows, pal), "model": model}
        if gid in MODEL_AT:
            g["model_at"] = MODEL_AT[gid]
        out.append(g)
    for n, gid, obj, facing, extra in SPEC:
        g = {"id": gid, "object": obj}
        if facing:
            g["facing"] = facing
        g["tiles"] = P["group_%d" % n]
        for k, v in extra.items():
            if k == "model" and v not in available_models:
                continue
            if k == "model_at" and extra.get("model") not in available_models:
                continue
            g[k] = v
        out.append(g)
    # pass 2 groups go first: the sword poses contain Link's body tiles plus the blade, and the
    # sword-carrying copies of his poses only differ by their condition
    player = [g for g in out if g.get("object") == "player" and g.get("model") == "hero"]
    # the walk check's extra poses are parts of pass 1's larger groups (Link in tall grass, the
    # drop shadow): they go last
    late = [{"id": gid, "object": obj, "facing": facing, "tiles": tiles, "model": "hero", "model_at": [8, 8]}
            for gid, obj, facing, tiles in EXTRA2]
    # (the hop shadow, one tile of pass 1's drop_shadow, is left as a flat sprite: a group of it
    # alone would be "hidden" by drop_shadow in validate's eyes)
    return groups2(available_models, player) + out + late


if __name__ == "__main__":
    path = sys.argv[1].rstrip("/") + "/pack.json"
    p = json.load(open(path))
    p["groups"] = groups(set(p.get("models", {})))
    json.dump(p, open(path, "w"), indent=1)
    print(len(p["groups"]), "groups written;", sum(1 for g in p["groups"] if "model" in g), "with models")
