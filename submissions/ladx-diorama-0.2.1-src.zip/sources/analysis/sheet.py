"""Join PNGs into a grid, each padded to the same cell: sheet.py OUT.png COLS FILE..."""
import subprocess, sys

out, cols, files = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
ins = sum([["-i", f] for f in files], [])
n = len(files)
pads = "".join("[%d]scale=w='min(iw,360)':h=-1:flags=neighbor,pad=w=368:h=240:x=0:y=0:color=0x303030[p%d];" % (i, i)
               for i in range(n))
rows = (n + cols - 1) // cols
if rows * cols > n:  # fill the last row
    pads += "".join("color=c=0x303030:s=368x240:d=1[e%d];" % i for i in range(rows * cols - n))
labels = ["[p%d]" % i for i in range(n)] + ["[e%d]" % i for i in range(rows * cols - n)]
layout = "|".join("%d_%d" % ((i % cols) * 368, (i // cols) * 240) for i in range(rows * cols))
flt = pads + "".join(labels) + "xstack=inputs=%d:layout=%s" % (rows * cols, layout)
subprocess.run(["ffmpeg", "-loglevel", "error", "-y"] + ins + ["-filter_complex", flt, "-frames:v", "1", out], check=True)
print(out)
