"""Link's sword poses from per-frame dumps: Link's 16x16 body (palette 8, at the position in high
RAM) joined with the blade drawn next to it (palette 11 sprites within 20 px; the sea urchin's
tiles are left out) or the sword held over his head (palette 15).  Each distinct layout becomes a
group: body top-left tile first (the anchor, so model_at [8, 8] is the body's centre), the blade
tiles after it.  The facing comes from Link's direction byte (0xFF9E: 0 east, 1 west, 2 north,
3 south); the pose from where the blade is relative to the facing:
  hold_up   the sword straight up above the head (getting the sword)
  swing_out the blade in front (along the facing)
  swing_mid the blade diagonal
  swing_in  the blade to one side (start of a swing, or the spin's side frames)
Writes sword_poses.json beside this file (tile keys and layouts only, no art).
sword_poses.py GLOB [GLOB ...]"""
import collections, glob, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
URCHIN = {"b2e3cef40e9eaf47", "94318bd1098df1a9", "4de31b34e972019a", "d286345af2f16e88",
          "f90f504f7c2962f7"}   # (and the ripple round a wading Link)
FACING = {0: "east", 1: "west", 2: "north", 3: "south"}
FWD = {0: (1, 0), 1: (-1, 0), 2: (0, -1), 3: (0, 1)}

layouts = collections.OrderedDict()
counts = collections.Counter()
facings = collections.defaultdict(collections.Counter)
files = sorted(f for g in sys.argv[1:] for f in glob.glob(g))
for f in files:
    d = json.load(open(f))
    r = bytes.fromhex(d["ram"])
    lx, ly, fac = r[0x3F98] - 8, r[0x3F99] - 16, r[0x3F9E]
    spr = [t for t in d["tiles"] if t["layer"] == "sprite"]
    body = [t for t in spr if t["pal"] == 8 and lx - 4 <= t["x"] <= lx + 12 and ly - 4 <= t["y"] <= ly + 12]
    if len(body) != 4:
        continue
    bx = min(t["x"] for t in body)
    by = min(t["y"] for t in body)
    extra = [t for t in spr if t not in body and t["key"] not in URCHIN and
             ((t["pal"] == 11 and bx - 20 <= t["x"] <= bx + 28 and by - 20 <= t["y"] <= by + 28) or
              (t["pal"] == 15 and bx - 4 <= t["x"] <= bx + 12 and by - 18 <= t["y"] <= by - 8))]
    if not extra:
        continue
    anchor = min(body, key=lambda t: (t["y"], t["x"]))
    rest = sorted([t for t in body if t is not anchor], key=lambda t: (t["y"], t["x"])) + \
        sorted(extra, key=lambda t: (t["y"], t["x"]))
    tiles = [{"dx": t["x"] - anchor["x"], "dy": t["y"] - anchor["y"], "key": t["key"],
              "hflip": t["hflip"], "vflip": t["vflip"]} for t in [anchor] + rest]
    key = json.dumps(tiles, sort_keys=True)
    # pose
    ex = sum(t["x"] + 4 for t in extra) / len(extra) - (bx + 8)
    ey = sum(t["y"] + 4 for t in extra) / len(extra) - (by + 8)
    if any(t["pal"] == 15 for t in extra):
        pose = "hold_up"
    else:
        fx, fy = FWD.get(fac, (0, 1))
        along = ex * fx + ey * fy
        cross = ex * fy - ey * fx          # > 0: on Link's left (screen y points down)
        side = abs(cross)
        lr = "_l" if cross > 0 else "_r"
        if along > 2 * side:
            pose = "swing_out"
        elif side > 2 * max(along, 0):
            pose = "swing_in" + lr
        else:
            pose = "swing_mid" + lr
    if key not in layouts:
        layouts[key] = {"tiles": tiles, "pose": pose, "first": os.path.basename(f)}
    counts[key] += 1
    facings[key][fac] += 1

out = []
for i, (k, v) in enumerate(layouts.items()):
    fac = facings[k].most_common(1)[0][0]
    v.update({"id": "sword_%02d" % i, "facing": FACING.get(fac, "south"), "seen": counts[k],
              "facings": dict(facings[k])})
    out.append(v)
json.dump(out, open(os.path.join(HERE, "..", "sword_poses.json"), "w"), indent=1)
for v in out:
    print(v["id"], v["pose"], v["facing"], v["facings"], "seen", v["seen"], "tiles", len(v["tiles"]), v["first"])
