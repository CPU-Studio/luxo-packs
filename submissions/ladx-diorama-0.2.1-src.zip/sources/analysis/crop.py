"""Crop a dump's screenshot region, scaled: crop.py DUMP.png OUT.png X Y W H [SCALE]
(local art: stays on this machine)"""
import subprocess, sys

src, out, x, y, w, h = sys.argv[1:7]
s = int(sys.argv[7]) if len(sys.argv) > 7 else 8
subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", src, "-vf",
                f"crop={w}:{h}:{x}:{y},scale=iw*{s}:ih*{s}:flags=neighbor", out], check=True)
