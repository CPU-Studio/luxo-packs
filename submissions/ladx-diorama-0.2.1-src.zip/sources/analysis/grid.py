"""Numbered contact grid of PNGs with ffmpeg: grid.py OUT.png COLS FILE...  (label = index from 1)"""
import os, subprocess, sys, tempfile

import glob, re
out, cols = sys.argv[1], int(sys.argv[2])
files = [f for g in sys.argv[3:] for f in sorted(glob.glob(g), key=lambda s: [int(x) if x.isdigit() else x for x in re.split(r"(\d+)", s)])]
tmp = tempfile.mkdtemp()
for i, f in enumerate(files, 1):
    label = os.path.basename(f).rsplit(".", 1)[0].split("_")[-1]
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", f, "-vf",
                    "scale=w=108:h=64:force_original_aspect_ratio=decrease:flags=neighbor,pad=112:84:(ow-iw)/2:16:color=0x303030,"
                    f"drawtext=text='{label}':x=2:y=1:fontsize=13:fontcolor=yellow",
                    os.path.join(tmp, "t_%03d.png" % i)], check=True)
rows = (len(files) + cols - 1) // cols
subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-framerate", "1", "-i",
                os.path.join(tmp, "t_%03d.png"), "-vf", f"tile={cols}x{rows}", "-frames:v", "1", out], check=True)
print(out)
