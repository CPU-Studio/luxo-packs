"""Make a scratch pack with every proposal as a group (object cand_N) for sprite_refs.
cand_pack.py PROPOSALS.txt BASE_PACK_DIR OUT_PACK_DIR   (proposals: propose_groups' output)"""
import json, os, sys

txt = open(sys.argv[1]).read()
props, _ = json.JSONDecoder().raw_decode(txt[txt.index("["):])
base = json.load(open(os.path.join(sys.argv[2], "pack.json")))
os.makedirs(sys.argv[3], exist_ok=True)
base["id"] = "ladx-cand"
base["groups"] = [{"id": "cand_" + p["id"].split("_")[1], "object": "cand_" + p["id"].split("_")[1],
                   "tiles": p["tiles"]} for p in props]
base.pop("models", None)
json.dump(base, open(os.path.join(sys.argv[3], "pack.json"), "w"), indent=1)
json.dump(props, open(os.path.join(sys.argv[3], "proposals.json"), "w"), indent=1)
print(len(props), "candidate groups")
