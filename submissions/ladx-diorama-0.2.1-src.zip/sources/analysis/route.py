"""Build inputs/to_sword.txt: after_talk.state -> shield from Tarin -> out of the house ->
west round the village (A1, A0) -> south through B0, C0, D0 (ledges) -> beach E0 -> F0 -> F1 ->
F2: push the sea urchin with the shield, owl, sword, spin, swings.
Legs are the navigation runs that worked, each from the previous one's last state; the frame
counts add up so one capture from after_talk.state replays them all.
Prints each leg's start frame."""
import os

TRIAL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A30 = " ".join(["A:30"] * 30)
LEGS = [
    ("shield", None),  # nav/shield.txt, 1500 frames
    ("A2->B2", "DOWN:200"),
    ("B2", "LEFT:60 DOWN:250"),
    ("B2->B1", "UP:20 LEFT:120 DOWN:150"),
    ("B1", "UP:60 LEFT:300"),
    ("B1->A1", "RIGHT:12 UP:120 LEFT:300"),
    ("A1->A0->B0", "DOWN:20 LEFT:300 DOWN:150"),
    ("B0", "DOWN:300"),
    ("B0->C0", "LEFT:22 DOWN:300"),
    ("C0", "LEFT:12 DOWN:300"),
    ("C0 ledge", "RIGHT:22 DOWN:200"),
    ("C0->D0", "LEFT:32 DOWN:200"),
    ("D0", "RIGHT:60 DOWN:200"),
    ("D0b", "RIGHT:30 DOWN:200"),
    ("D0->E0->F0", "LEFT:20 UP:16 LEFT:80 DOWN:150 RIGHT:84 DOWN:100"),
    ("F0->F1->F2 urchin, owl", "DOWN:10 RIGHT:228 DOWN:44 RIGHT:80 RIGHT+B:100 DOWN:16 RIGHT:26 DOWN:16 RIGHT:24 WAIT:340 " + A30 + " WAIT:100"),
    ("owl ends, sword", "A:30 A:30 A:30 A:30 WAIT:150 RIGHT:24 DOWN:6 WAIT:200 A:30 A:30 A:30 A:30 WAIT:60"),
    ("sword text", "A:30 A:30 A:30 A:30 A:30 A:30 WAIT:60 UP:10 A:30 RIGHT:10 A:30 LEFT:10 A:30 DOWN:4 A:30"),
    ("fanfare, spin, swings", "WAIT:400 UP:20 A:30 RIGHT:10 A:30"),
]


def leg_lines(steps, base):
    lines, f = [], 0
    for s in steps.split():
        b, n = s.split(":")
        n = int(n)
        if b != "WAIT":
            lines.append(f"{base+f}-{base+f+(4 if b in ('A', 'B') else n-1)} {b}")
        f += n
    return lines, f


out, base = [], 0
for name, steps in LEGS:
    print(f"{base:6d} {name}")
    if steps is None:
        for ln in open(os.path.join(TRIAL, "nav/shield.txt")):
            if ln.strip():
                out.append(ln.strip())
        base += 1500
        continue
    lines, n = leg_lines(steps, base)
    out += lines
    base += n
open(os.path.join(TRIAL, "inputs/to_sword.txt"), "w").write(
    "# after_talk.state -> shield -> Toronbo Shores -> sword (see scripts/route.py)\n" + "\n".join(out) + "\n")
print("total", base)
