import os
"""Coverage per room: runs luxo3d coverage on DUMP_DIR, groups the per-dump lines by the room
byte (0xFFF6) and prints scene, bg tiles with a rule and sprite tiles in groups per room.
cov_rooms.py PACK_DIR DUMP_DIR [DUMP_DIR ...]"""
import collections, glob, json, os, re, subprocess, sys

MCP = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "..", "..", "tools", "luxo3d", "luxo3d_mcp.py"))
pack = sys.argv[1]
rows = collections.defaultdict(lambda: [collections.Counter(), 0, 0, 0, 0, 0])
for d in sys.argv[2:]:
    room = {}
    for f in glob.glob(os.path.join(d, "*.json")):
        r = bytes.fromhex(json.load(open(f))["ram"])
        room[os.path.basename(f)] = "%02X%s" % (r[0x3FF6], "i" if r[0x1BA5] else "")
    out = subprocess.run(["python3", MCP, "call", "coverage", json.dumps({"pack": pack, "dumps": d})],
                         capture_output=True, text=True).stdout
    for ln in out.splitlines():
        m = re.match(r"(\S+\.json)\s+scene\s+(\S+)\s+(\S+)\s+groups\s+\d+ models\s+(\d+)\s+sprites\s+(\d+)/(\d+)\s+bg\s+(\d+)/(\d+)", ln)
        if not m:
            continue
        rm = rows[room.get(m.group(1), "?")]
        rm[0][m.group(2) + "/" + m.group(3)] += 1
        rm[1] += int(m.group(5)); rm[2] += int(m.group(6)); rm[3] += int(m.group(7)); rm[4] += int(m.group(8))
        rm[5] += 1
    tail = [l for l in out.splitlines() if l.startswith(("sprite tiles", "background tiles", "groups never"))]
    print(d, "|", " | ".join(tail))
print("room  dumps  scenes                         sprites-in-groups   bg-with-rule")
for k in sorted(rows):
    s = rows[k]
    print("%-5s %5d  %-30s %6d/%-6d %3.0f%%  %7d/%-7d %3.0f%%" % (k, s[5], dict(s[0]), s[1], s[2], 100 * s[1] / max(s[2], 1),
                                                              s[3], s[4], 100 * s[3] / max(s[4], 1)))
