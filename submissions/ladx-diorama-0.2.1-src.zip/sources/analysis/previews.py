"""Full-frame previews (2D beside 3D) of the pass-2 screens into out/p2_<name>.png."""
import json, os, subprocess

TRIAL = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
os.chdir(TRIAL)
JOBS = [("a1_chomper", "states/after_talk.state", "inputs/to_sword.txt", 2790),
        ("b0_kids", "states/after_talk.state", "inputs/to_sword.txt", 3520),
        ("c0_cliffs", "states/after_talk.state", "inputs/to_sword.txt", 4300),
        ("d0_stairs", "states/after_talk.state", "inputs/to_sword.txt", 5000),
        ("e0_palms", "states/after_talk.state", "inputs/to_sword.txt", 5840),
        ("f0_shore", "states/after_talk.state", "inputs/to_sword.txt", 5960),
        ("f1_beach", "states/after_talk.state", "inputs/to_sword.txt", 6200),
        ("f2_sword", "states/after_talk.state", "inputs/to_sword.txt", 6420),
        ("f2_owl", "states/after_talk.state", "inputs/to_sword.txt", 6490),
        ("f2_holdup", "states/after_talk.state", "inputs/to_sword.txt", 8500),
        ("f2_swing_east", "dumps/route/route_last.state", "inputs/swing.txt", 56),
        ("f2_swing_south", "dumps/route/route_last.state", "inputs/swing.txt", 96)]
for name, state, inputs, f in JOBS:
    args = {"state": state, "inputs": inputs, "frames": f, "pack": "packs/ladx-diorama", "out": "out/p2_%s.png" % name}
    r = subprocess.run(["python3", "scripts/lx.py", "render_preview", json.dumps(args), "3"], capture_output=True, text=True)
    print(name, r.stdout.strip().splitlines()[0] if r.stdout.strip() else r.stderr[-200:])
