"""Game-size crops of the pass-2 models (sprite beside model): writes out/crop_<object>.png."""
import os, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
TRIAL = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
os.chdir(TRIAL)
JOBS = [("octorok:5", 5840), ("palm:4", 5840), ("crab:5", 6200), ("urchin:5", 6420), ("rock:5", 6420),
        ("stake:5", 6420), ("sword:5", 6420), ("chomper:5", 2790), ("villager:5", 3520), ("owl:5", 6600)]
for crop, f in JOBS:
    r = subprocess.run(["python3", os.path.join(HERE, "crops.py"), "states/after_talk.state", "inputs/to_sword.txt",
                        crop, "out/crop_%s.png" % crop.split(":")[0], str(f)], capture_output=True, text=True)
    print(r.stdout.splitlines()[0] if r.stdout else r.stderr[-300:])
r = subprocess.run(["python3", os.path.join(HERE, "crops.py"), "dumps/route/route_last.state", "inputs/swing.txt",
                    "rupee:6", "out/crop_rupee.png", "40"], capture_output=True, text=True)
print(r.stdout.splitlines()[0] if r.stdout else r.stderr[-300:])
