"""Count dumps whose models include the player; list the misses (frame, Link sprite tiles)."""
import glob, json, sys

files = sorted(glob.glob(sys.argv[1] + "/*.json"))
miss = []
for f in files:
    d = json.load(open(f))
    if any(m.get("object") == "player" for m in d.get("models", [])):
        continue
    r = bytes.fromhex(d["ram"])
    spr = [(t["x"], t["y"], t["key"], t["pal"], int(t["hflip"])) for t in d["tiles"] if t["layer"] == "sprite" and t["pal"] == 8]
    miss.append((f.rsplit("_", 1)[1][:6] + (" no-sprites" if not spr else ""), d.get("scene"), r[0x19F], spr))
print("player model in %d of %d dumps" % (len(files) - len(miss), len(files)))
for m in miss[:40]:
    print(m[0], m[1], "dialog" if m[2] else "", m[3][:6])
if len(miss) > 40:
    print("... frames", [m[0] for m in miss[40:]])
