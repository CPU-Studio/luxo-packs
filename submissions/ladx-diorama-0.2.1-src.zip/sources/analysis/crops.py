"""Render player (or another object's) crops at several frames and join them in a row.
crops.py STATE INPUTS OBJECT:SCALE OUT.png FRAME [FRAME ...]   (paths relative to TRIAL)"""
import json, os, subprocess, sys

TRIAL = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
os.chdir(TRIAL)
state, inputs, crop, out = sys.argv[1:5]
pngs = []
for f in sys.argv[5:]:
    base = "out/tmp_crop_%s" % f
    args = {"state": state, "frames": int(f), "pack": "packs/ladx-diorama", "crop": crop, "out": base + ".png"}
    if inputs != "-":
        args["inputs"] = inputs
    r = subprocess.run(["python3", "scripts/lx.py", "render_preview", json.dumps(args), "6"], capture_output=True, text=True)
    line = [l for l in r.stdout.splitlines() if l.startswith("crop:")]
    print(f, line[0] if line else r.stdout[-300:])
    obj = crop.split(":")[0]
    p = base + "_" + obj + ".png"
    if os.path.exists(p):
        pngs.append(p)
if pngs:
    ins = sum([["-i", p] for p in pngs], [])
    flt = "".join("[%d]pad=w=max(iw\\,300)+8:h=max(ih\\,400):x=0:y=0:color=0x303030[p%d];" % (i, i) for i in range(len(pngs))) + \
        "".join("[p%d]" % i for i in range(len(pngs))) + "hstack=inputs=%d" % len(pngs) if len(pngs) > 1 else "null"
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y"] + ins + ["-filter_complex", flt, out], check=True)
    print(out)
