"""Print bg tile keys (outside the status bar and dialogue boxes) that ladx_rules has no rule for."""
import glob, json, sys
sys.path.insert(0, "sources/ladx")
import ladx_rules as R

ruled = {t["key"] for t in R.tiles()}
out = {"overworld": set(), "indoors": set()}
for f in glob.glob(sys.argv[1] if len(sys.argv) > 1 else "dumps/*.json"):
    d = json.load(open(f))
    r = bytes.fromhex(d["ram"])
    sc = "indoors" if r[0x1BA5] == 1 else "overworld"
    if r[0x19F] != 0:
        continue
    for t in d["tiles"]:
        if t["layer"] != "bg" or t["y"] >= 128 or t["key"] in ruled:
            continue
        out[sc].add(t["key"])
for k, v in out.items():
    print(k, len(v))
    print(json.dumps(sorted(v)))
