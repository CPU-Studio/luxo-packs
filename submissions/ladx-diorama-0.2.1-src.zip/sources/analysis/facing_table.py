"""Which input was held when each candidate group matched (from verbose coverage)."""
import collections, re, sys

INPUTS = {
    "house": [(0, 30, "RIGHT"), (31, 110, "DOWN"), (111, 140, "RIGHT"), (141, 240, "DOWN")],
    "village": [(0, 40, "DOWN"), (41, 80, "LEFT"), (81, 130, "DOWN"), (131, 330, "RIGHT"),
                (331, 480, "DOWN"), (481, 700, "RIGHT"), (701, 850, "UP"), (851, 1100, "LEFT")],
    "village2": [(0, 250, "DOWN"), (251, 500, "LEFT"), (501, 700, "DOWN"), (701, 900, "LEFT"),
                 (901, 1100, "UP")],
}
tab = collections.defaultdict(collections.Counter)
cur = None
for line in open(sys.argv[1]):
    m = re.match(r"(\w+?)_(\d+)\.json", line)
    if m:
        cur = (m.group(1), int(m.group(2)))
        continue
    if "matched:" in line and cur and cur[0] in INPUTS:
        held = next((b for a, z, b in INPUTS[cur[0]] if a <= cur[1] - 1 <= z), "none")
        for g in re.findall(r"cand_\d+(?:x\d+)?", line):
            tab[g.split("x")[0]][held] += 1
for g in sorted(tab, key=lambda s: int(s.split("_")[1])):
    print(g, dict(tab[g]))
