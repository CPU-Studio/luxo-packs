"""Atlas of background tiles (key, pal) without a tile rule in the pack, for the given rooms.
new_atlas.py PACK_DIR OUT.png OUT.json ROOM_DIR [ROOM_DIR ...]
Tiles are numbered row-major, 16 per row, in order of first appearance; window tiles and the
status bar rows (y >= 128) are skipped. The picture is the game's art: it stays on this machine."""
import collections, glob, json, os, struct, sys, zlib

pack, out_png, out_json = sys.argv[1:4]
rules = json.load(open(os.path.join(pack, "pack.json")))["tiles"]
has = set()
for r in rules:
    if r.get("scene", "overworld") != "overworld":
        continue
    has.add((r["key"], r.get("pal")))


def ruled(k, p):
    return (k, None) in has or (k, p) in has


seen, count, where = collections.OrderedDict(), collections.Counter(), collections.defaultdict(set)
for d in sys.argv[4:]:
    room = os.path.basename(d.rstrip("/"))
    for f in sorted(glob.glob(os.path.join(d, "*.json"))):
        j = json.load(open(f))
        sh = {s["key"]: s["pixels"] for s in j["shapes"]}
        for t in j["tiles"]:
            if t["layer"] != "bg" or t["y"] >= 128 or t.get("window"):
                continue
            k = (t["key"], t["pal"])
            if ruled(*k):
                continue
            count[k] += 1
            where[k].add(room)
            if k not in seen:
                seen[k] = (sh[t["key"]], j["palettes"][t["pal"]])
keys = list(seen)
S, G, C = 4, 6, 16
rows = (len(keys) + C - 1) // C
W, H = C * (8 * S + G), max(1, rows) * (8 * S + G)
img = [[(40, 40, 40)] * W for _ in range(H)]
for i, k in enumerate(keys):
    px, pal = seen[k]
    ox, oy = (i % C) * (8 * S + G), (i // C) * (8 * S + G)
    for p in range(64):
        c = pal[int(px[p])] if px[p] != "." else "#ff00ff"
        rgb = tuple(int(c[q:q + 2], 16) for q in (1, 3, 5))
        for dy in range(S):
            for dx in range(S):
                img[oy + (p // 8) * S + dy][ox + (p % 8) * S + dx] = rgb
    if i % 4 == 0:
        for dy in range(G - 2):
            for dx in range(3):
                img[oy + 8 * S + 1 + min(dy, G - 3)][ox + dx] = (255, 255, 0)
raw = b"".join(b"\x00" + bytes(v for p in row for v in p) for row in img)


def chunk(t, data):
    return struct.pack(">I", len(data)) + t + data + struct.pack(">I", zlib.crc32(t + data) & 0xffffffff)


png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0)) + \
    chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
open(out_png, "wb").write(png)
json.dump([{"i": i, "key": k[0], "pal": k[1], "n": count[k], "in": sorted(where[k])} for i, k in enumerate(keys)],
          open(out_json, "w"), indent=0)
print(len(keys), "tiles without a rule,", rows, "rows")
for i, k in enumerate(keys):
    print(i, k[0], k[1], count[k], ",".join(sorted(where[k])))
