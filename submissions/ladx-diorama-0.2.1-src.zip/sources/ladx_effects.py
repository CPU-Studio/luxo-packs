"""The pack's effects and version (0.2.1): python3 ladx_effects.py PACK_DIR.

Run after ladx_rules.py and ladx_groups.py.  Signals come from the groups'
objects (appear / disappear) and from bush tiles going away (tile_changed);
colours are the game's own where "palette", else fixed.
"""
import json
import sys

OUTDOORS = ("overworld", "shore")


def fx(on, scenes=OUTDOORS, **sel_and_do):
    do = sel_and_do.pop("do")
    return [dict({"on": on, "scene": s, "do": do}, **sel_and_do) for s in scenes]


def burst(count, speed, life_ms, size, color="palette", kind="burst"):
    return {"preset": "particles", "kind": kind, "count": count, "color": color, "speed": speed,
            "life_ms": life_ms, "size": size}


def light(color, radius, intensity, ms):
    return {"preset": "light", "color": color, "radius": radius, "intensity": intensity, "ms": ms}


EFFECTS = (
    # An enemy struck down: a burst in its own colours, a warm light, a small knock.
    fx("disappear", object="octorok", do=[burst(26, 60, 500, 2.2), light("#ffd080", 56, 1.3, 220),
                                          {"preset": "shake", "amount": 1, "ms": 110}])
    + fx("disappear", object="crab", do=[burst(22, 55, 480, 2.0), light("#ffd080", 50, 1.2, 200)])
    # Pickups: a short golden glint where they were taken, and the game's sparkle.
    + fx("disappear", object="rupee", do=[burst(10, 45, 300, 1.5, color="#9fd8ff", kind="sparks"),
                                          light("#a0d8ff", 40, 1.0, 180)])
    + fx("disappear", object="heart", do=[burst(10, 45, 300, 1.5, color="#ff9090", kind="sparks"),
                                          light("#ff8080", 40, 1.0, 180)])
    + fx("appear", object="sparkle", do=[burst(8, 35, 280, 1.3, color="#fff6c0", kind="sparks"),
                                         light("#fff0b0", 36, 0.9, 200)])
    # Sand and water: a puff of sand, splashes round a wading hero, dust where a stone lands.
    + fx("appear", object="sand_puff", scenes=("shore",),
         do=[burst(14, 30, 520, 1.8, color="#e8c890", kind="debris")])
    + fx("appear", object="ripple", do=[burst(8, 28, 360, 1.4, color="#c8e8ff", kind="debris")])
    + fx("disappear", object="rock_shot", do=[burst(6, 30, 300, 1.3, color="#b0a090", kind="debris")])
    # A bush cut (its tile goes): leaves.
    + fx("tile_changed", role="solid", do=[burst(12, 40, 650, 1.8, color="#58a848", kind="debris")])
)


def main():
    path = sys.argv[1].rstrip("/") + "/pack.json"
    with open(path) as f:
        pack = json.load(f)
    pack["effects"] = EFFECTS
    pack["version"] = "0.2.1"
    with open(path, "w") as f:
        json.dump(pack, f, indent=1)
    print("%d effect rules written to %s (version %s)" % (len(EFFECTS), path, pack["version"]))


if __name__ == "__main__":
    main()
