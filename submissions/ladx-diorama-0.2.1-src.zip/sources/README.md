# Link's Awakening DX pack sources

Everything in `packs/ladx-diorama` is rebuilt from these. They were written by an agent working
in Blender through Blender MCP (see `docs/3d-view/PLAN.md`).

| Script | Rebuilds |
|---|---|
| `ladx_models.py` | Every model: hero, Marin, Tarin, kid (with `walk` clips), hen, fox, pup, pot, bed, table, dresser, stool, tree, bush, the three houses; pass 2: `hero_sword` (walk plus held clips `hold_up`, `swing_in_l`, `swing_mid_l`, `swing_in_r`, `swing_mid_r`, `swing_out`), sword, octorok, crab, urchin, owl, chomper, rupee, palm, beach_rock, stake, surf |
| `export_models.py` | Builds each model headless into `blend/<name>.blend` and exports it with `tools/luxo3d/blender_export.py`, merging duplicate glTF texture entries (`python3 export_models.py PACK_DIR [model ...]`) |
| `ladx_rules.py` | Scenes (`indoors`, `shore` for outdoor rooms from 0xC0, `overworld`), the HUD (window layer + dialogue box), version, pass-2 model entries, and the tile rules (`python3 ladx_rules.py PACK_DIR`) |
| `ladx_effects.py` | The effects (enemies struck, pickups, sand, water, bushes cut) and the version, 0.2.1 (`python3 ladx_effects.py PACK_DIR`) |
| `ladx_groups.py` | The groups, in order, from the layouts in `proposals.json` (pass 1), `proposals2.json` and `sword_poses.json` (pass 2), tile keys only (`python3 ladx_groups.py PACK_DIR`) |

Order for a full rebuild: `export_models.py`, then `ladx_rules.py`, then `ladx_groups.py`, then
`ladx_effects.py`.

Characters are original designs that fill each sprite's role (see `tools/luxo3d/MODELS.md`).

`analysis/` holds the helpers the runs used, on dumps captured with `luxo3d capture` (paths on
the command line):
- pass 1: facings from the held direction (`facing_table.py`), the per-frame walk check
  (`walk_check.py`), tiles without a rule (`unruled.py`), a numbered sprite grid (`grid.py`);
- pass 2: Link's sword poses from every-frame dumps (`sword_poses.py`, writes `sword_poses.json`),
  an atlas of tiles without a rule per room (`new_atlas.py`), coverage per room
  (`cov_rooms.py`), a scratch pack of proposals for `sprite_refs` (`cand_pack.py`), and the crop
  and preview renders (`crops.py`, `model_crops.py`, `previews.py`, `sheet.py`, `crop.py`).
