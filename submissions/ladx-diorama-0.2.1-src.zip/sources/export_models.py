"""Rebuild and export ladx-diorama models headlessly: export_models.py PACK_DIR [model ...]
Builds each with ladx_models.py into sources/ladx/blend/<name>.blend, exports to
PACK_DIR/models/<name>.glb with tools/luxo3d/blender_export.py."""
import os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
EXPORT = os.path.normpath(os.path.join(HERE, "..", "..", "..", "..", "tools", "luxo3d", "blender_export.py"))
ANIMATED = {"hero", "marin", "tarin", "kid", "hero_sword"}
PIVOT = {"hero": "hero_torso", "marin": "marin_torso", "tarin": "tarin_torso", "kid": "kid_torso",
         "house_tarin": "house_walls", "house_shop": "house_walls", "house_madam": "house_walls",
         "hen": "hen_torso", "fox": "fox_torso", "pup": "pup_torso", "tree": "tree_trunk",
         # pass 2
         "hero_sword": "hero_torso", "sword": "sword_mound", "octorok": "octorok_torso", "crab": "crab_torso",
         "urchin": "urchin_torso", "owl": "owl_torso", "chomper": "chomper_torso", "rupee": "rupee_body",
         "palm": "palm_mound", "beach_rock": "rock_body", "stake": "stake_post", "surf": "surf_slab"}
ALL = ["hero", "marin", "tarin", "kid", "hen", "fox", "pup", "pot", "bed", "table", "dresser", "stool",
       "tree", "bush", "house_tarin", "house_shop", "house_madam",
       "hero_sword", "sword", "octorok", "crab", "urchin", "owl", "chomper", "rupee",
       "palm", "beach_rock", "stake", "surf"]

import json, struct


def dedupe_textures(path):
    """Blender's glTF exporter writes one texture entry per material even when they share an
    image and sampler; Luxo's validator counts entries.  Merge identical entries in place."""
    b = open(path, "rb").read()
    jlen = struct.unpack("<I", b[12:16])[0]
    j = json.loads(b[20:20 + jlen])
    texs = j.get("textures", [])
    uniq, remap = [], {}
    for i, t in enumerate(texs):
        key = json.dumps(t, sort_keys=True)
        keys = [json.dumps(u, sort_keys=True) for u in uniq]
        if key not in keys:
            uniq.append(t)
            keys.append(key)
        remap[i] = keys.index(key)

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k.endswith("Texture") and isinstance(v, dict) and "index" in v:
                    v["index"] = remap[v["index"]]
                else:
                    walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(j.get("materials", []))
    if texs:
        j["textures"] = uniq
    js = json.dumps(j, separators=(",", ":")).encode()
    js += b" " * ((4 - len(js) % 4) % 4)
    rest = b[20 + jlen:]
    total = 12 + 8 + len(js) + len(rest)
    out = b[:8] + struct.pack("<I", total) + struct.pack("<I", len(js)) + b"JSON" + js + rest
    open(path, "wb").write(out)
    return len(texs), len(uniq)


pack = sys.argv[1]
names = sys.argv[2:] or ALL
os.makedirs(os.path.join(HERE, "blend"), exist_ok=True)
os.makedirs(os.path.join(pack, "models"), exist_ok=True)
for n in names:
    blend = os.path.join(HERE, "blend", n + ".blend")
    r = subprocess.run(["blender", "-b", "--factory-startup", "--python", os.path.join(HERE, "ladx_models.py"),
                        "--", "--model", n, "--blend", blend], capture_output=True, text=True)
    line = [l for l in r.stdout.splitlines() if l.startswith(n + ":")]
    if r.returncode or not line:
        print(n, "BUILD FAILED\n", r.stdout[-2000:], r.stderr[-2000:])
        continue
    cmd = ["blender", "-b", blend, "--python", EXPORT, "--", "--out", os.path.join(pack, "models", n + ".glb")]
    if n in PIVOT:
        cmd += ["--pivot", PIVOT[n]]
    if n in ANIMATED:
        cmd += ["--animations"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    out = [l for l in r.stdout.splitlines() if l.startswith("luxo3d:") or "rror" in l]
    glb = os.path.join(pack, "models", n + ".glb")
    if os.path.exists(glb):
        out.append("textures %d -> %d" % dedupe_textures(glb))
    print(line[0], "|", " ".join(out[-3:]) if out else r.stdout[-600:] + r.stderr[-600:])
