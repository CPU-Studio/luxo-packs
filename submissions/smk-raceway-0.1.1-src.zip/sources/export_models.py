"""Rebuild and export the smk-raceway models headlessly:
    python3 -I export_models.py PACK_DIR [model ...]
Builds each with smk_models.py into sources/smk/blend/<name>.blend and exports it to
PACK_DIR/models/<name>.glb with tools/luxo3d/blender_export.py."""
import os, subprocess, sys
import os  # noqa: E402
REPO = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", ".."))  # the repository root

HERE = os.path.dirname(os.path.abspath(__file__))
EXPORT = os.path.join(REPO, "tools", "luxo3d", "blender_export.py")
ALL = ["kart_player", "kart_rival", "pipe", "coin", "banana", "shell", "item_box"]
PIVOT = {"kart_player": "kart_player_body", "kart_rival": "kart_rival_body", "pipe": "pipe_body",
         "coin": "coin_face", "banana": "banana_core", "shell": "shell_dome", "item_box": "item_box"}


def main():
    pack = sys.argv[1]
    names = sys.argv[2:] or ALL
    os.makedirs(os.path.join(HERE, "blend"), exist_ok=True)
    os.makedirs(os.path.join(pack, "models"), exist_ok=True)
    for n in names:
        blend = os.path.join(HERE, "blend", n + ".blend")
        r = subprocess.run(["blender", "-b", "--factory-startup", "--python", os.path.join(HERE, "smk_models.py"),
                            "--", n, blend], capture_output=True, text=True)
        print([l for l in r.stdout.splitlines() if "triangles" in l] or r.stdout[-800:] + r.stderr[-800:])
        out = os.path.join(pack, "models", n + ".glb")
        r = subprocess.run(["blender", "-b", blend, "--python", EXPORT, "--", "--out", out,
                            "--pivot", PIVOT[n]], capture_output=True, text=True)
        tail = [l for l in r.stdout.splitlines() if "luxo" in l.lower() or "size" in l.lower() or "error" in l.lower()]
        print(n, tail[-4:] if tail else r.stdout[-600:] + r.stderr[-600:])


if __name__ == "__main__":
    main()
