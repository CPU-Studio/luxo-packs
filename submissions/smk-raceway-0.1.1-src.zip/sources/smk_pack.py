"""Writes the groups and models of packs/smk-raceway/pack.json from work/objects.json
(made by smk_groups.py).  python3 -I smk_pack.py OBJECTS.json PACK_DIR

Objects:
  player  palette-9 kart at the player's place on screen      -> kart_player
  rival   other racer sprites (palettes 8-11)                 -> kart_rival (palette colours)
  pipe    palette 15                                          -> pipe
  coin    palette 14, taller than wide                        -> coin
  banana  palette 14, small and squat                         -> banana
Palettes 12 (rank and coins counter, under a HUD region) and 13 (the cloud-riding official,
drift dust) stay sprites.
"""
import json, sys, os, math
import os  # noqa: E402
REPO = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", ".."))  # the repository root
sys.path.insert(0, os.path.join(REPO, "tools", "luxo3d"))

MODELS = {
    "kart_player": {"file": "models/kart_player.glb", "scale": 0.9},
    "kart_rival": {"file": "models/kart_rival.glb", "scale": 0.9},
    "pipe": {"file": "models/pipe.glb", "scale": 1},
    "coin": {"file": "models/coin.glb", "scale": 1},
    "banana": {"file": "models/banana.glb", "scale": 1.6},
    "shell": {"file": "models/shell.glb", "scale": 1},
}


# Objects sized per group (the player is always near; its low poses, hops, keep the full
# size).  MODEL_H: each model's height in units, as exported.
SIZED = {"rival", "pipe", "coin", "banana"}
MODEL_H = {"kart_rival": 33.1, "pipe": 24.2, "coin": 14.8, "banana": 7.3}
KART_KEYS = set()  # every tile shape seen in a kart (filled in main)
LEVELS = [0.05, 0.08, 0.12, 0.18, 0.25, 0.35, 0.5, 0.7, 1.0]


def line_k(run, foot):
    """Luxo's floor scale k at a screen line: the run's map scale there over its bottom
    line's.  The dumps give the scale at the run's top and bottom; Mode 7 perspective
    makes 1/scale linear in the line."""
    if not run:
        return 1.0
    (l0, l1), (s0, s1) = run["lines"], run["scale"]
    foot = min(max(foot, l0), l1)
    inv = 1 / s0 + (foot - l0) * (1 / s1 - 1 / s0) / float(l1 - l0)
    k = (1 / inv) / s1
    return k if k <= 6 else 6.0


def classify(o):
    obj = o["object"]
    if obj in ("player", "rival"):
        return obj, "kart_" + obj
    if obj == "track_pal15":
        # Pipes are at most 16x32 (8 tiles). Palette 15 also draws the dust and grass spray
        # at the player's wheels (22 tiles) and, during a star, the player's kart itself:
        # those must not become pipes (a group ignores palettes, so a "pipe" holding kart
        # tiles took the player's tiles).
        x0, y0, x1, y1 = o["box"]
        at_wheels = x0 < 156 and x1 > 100 and y1 > 80
        kart = any(t[2] in KART_KEYS for t in o["sig"])
        if len(o["sig"]) > 8 or at_wheels or kart:
            return None, None
        return "pipe", "pipe"
    if obj == "track_pal14":
        x0, y0, x1, y1 = o["box"]
        if any(t[2] in KART_KEYS for t in o["sig"]):
            return None, None
        yellow = sum(v for k, v in o["hist"].items() if k in ("#ffff00", "#ff8b00"))
        total = sum(o["hist"].values()) or 1
        n = len(o["sig"])
        if n >= 6:
            return None, None  # star sparkles
        fw, fh = o.get("fill") or (0, 0)
        # coins are tall ovals (spinning: as narrow as 2 px); a banana peel lies flat,
        # about as wide as it is tall
        if yellow / total > 0.3 and fh >= 6 and fh >= 1.4 * fw:
            # the coin just picked up flies off above the screen's centre (x 119): an
            # effect drawn on the screen, not a coin on the track; it stays a sprite
            if x0 == 119 and y1 <= 46:
                return None, None
            return "coin", "coin"
        if yellow / total > 0.2 and fh < 1.4 * fw:
            return "banana", "banana"
        return None, None
    return None, None


def main():
    objs = json.load(open(sys.argv[1]))
    KART_KEYS.update(t[2] for o in objs if o["object"] in ("player", "rival") for t in o["sig"])
    pack_dir = sys.argv[2]
    pf = os.path.join(pack_dir, "pack.json")
    pack = json.load(open(pf))
    groups = []
    models = dict(MODELS)
    for i, o in enumerate(objs):
        name, model = classify(o)
        if not name:
            continue
        if name in SIZED:
            # Luxo scales a floor model by its line's distance k (the line's Mode 7 scale over
            # the floor's bottom line), and the side camera hardly shrinks it back, so a model
            # of fixed size came out up to 3x too big far away.  Each group gets a scale that
            # makes the model as tall as its sprite: sprite height / model height / k at the
            # group's median foot line.  Models entries are shared per 10% step of scale.
            # Height, not width: two far karts side by side join into one wide object.
            h = o["box"][3] - o["box"][1]
            k = line_k(o.get("m7"), o.get("foot", 0))
            s = h / MODEL_H[model] / k
            s = max(0.05, min(MODELS[model]["scale"], s))
            # a few levels only: every models entry counts its file's triangles in the
            # pack's 200k budget, even when entries share one GLB
            step = min(LEVELS + [MODELS[model]["scale"]], key=lambda L: abs(math.log(L / s)))
            if abs(step - MODELS[model]["scale"]) > 0.01:
                sized = "%s_s%03d" % (model, int(round(step * 100)))
                models[sized] = {"file": MODELS[model]["file"], "scale": step}
                model = sized
        tiles = []
        for dx, dy, key, hf, vf in o["sig"]:
            tiles.append({"dx": dx, "dy": dy, "key": key, "hflip": hf, "vflip": vf})
        groups.append({"id": "%s_%03d" % (name, i), "object": name, "scene": "race", "tiles": tiles,
                       "model": model, "_n": len(tiles), "_c": o["count"]})
    # larger groups first, so a kart is not split by a smaller group inside it
    groups.sort(key=lambda g: (-g["_n"], -g["_c"]))
    for g in groups:
        del g["_n"], g["_c"]
    used = {g["model"] for g in groups}
    pack["groups"] = groups
    pack["models"] = {k: v for k, v in models.items() if k in used and os.path.exists(os.path.join(pack_dir, v["file"]))}
    for g in groups:
        if g["model"] not in pack["models"]:
            del g["model"]
    json.dump(pack, open(pf, "w"), indent=1)
    import collections
    print(len(groups), "groups", dict(collections.Counter(g["object"] for g in groups)), "models", list(pack["models"]))


if __name__ == "__main__":
    main()
