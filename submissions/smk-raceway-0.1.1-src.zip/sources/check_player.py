"""Counts racing dumps where the player is not drawn as a model, by applying the pack to
existing dumps (luxo3d match --verbose; no new capture).
    python3 -I check_player.py PACK_DIR DUMP_DIR [first_frame]"""
import glob, json, os, subprocess, sys
import os  # noqa: E402
REPO = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", ".."))  # the repository root

L = os.path.join(REPO, "tools", "luxo3d", "out", "luxo3d")
pack, d = sys.argv[1], sys.argv[2]
first = int(sys.argv[3]) if len(sys.argv) > 3 else 560
files = sorted(f for f in glob.glob(os.path.join(d, "*.json")) if int(f[-11:-5]) >= first)
groups = {g["id"]: g["object"] for g in json.load(open(os.path.join(pack, "pack.json")))["groups"]}
n, miss = 0, []
for i in range(0, len(files), 200):
    out = subprocess.run([L, "match", os.path.join(pack, "pack.json"), "--verbose"] + files[i:i + 200],
                         capture_output=True, text=True).stdout.splitlines()
    cur = None
    for line in out:
        if line.endswith(".json") is False and ".json" in line and " scene " in line:
            cur = (line.split()[0], line.split()[2])
            if cur[1] == "race":
                n += 1
                miss.append(cur[0])
        elif line.strip().startswith("matched:") and cur and cur[1] == "race":
            ids = line.split()[1:]
            if any(groups.get(x) == "player" for x in ids):
                miss.remove(cur[0])
print("racing dumps", n, "without the player model", len(miss), [m[2:8] for m in miss][:60])
