"""Builds the sprite groups of the smk-raceway pack from race dumps.

Each frame's sprites in the race view (the top half) are joined into objects: sprites of
one palette that touch or overlap. Every distinct object (same tiles at the same offsets)
becomes one group. Racers are palettes 8-11; the player is the palette-9 object at the
player's fixed place on screen. Other palettes are track objects, classified by
`classify()` from the shapes listed in TRACK (filled in after looking at the pictures).

usage: python3 -I smk_groups.py DUMP_DIR [...] --out groups.json [--report]
"""
import json, glob, sys, os, collections
sys.path.insert(0, os.path.join(REPO, "tools", "luxo3d"))
import dump_pixels
import os  # noqa: E402
REPO = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", ".."))  # the repository root

RACER_PALS = {8, 9, 10, 11}
TOP_LIMIT = 110  # race view lines; the course map is below


def clusters(tiles):
    tiles = [t for t in tiles if t["layer"] == "sprite" and t["y"] < TOP_LIMIT and t["y"] > -8]
    n = len(tiles)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i in range(n):
        a = tiles[i]
        for j in range(i + 1, n):
            b = tiles[j]
            if a["pal"] != b["pal"]:
                continue
            if a["x"] - 8 <= b["x"] <= a["x"] + 8 and a["y"] - 8 <= b["y"] <= a["y"] + 8:
                parent[find(i)] = find(j)
    out = collections.defaultdict(list)
    for i in range(n):
        out[find(i)].append(tiles[i])
    return list(out.values())


def signature(cl):
    cl = sorted(cl, key=lambda t: (t["y"], t["x"], t["key"]))
    a = cl[0]
    sig = tuple((t["x"] - a["x"], t["y"] - a["y"], t["key"], t["hflip"], t["vflip"]) for t in cl)
    # duplicate tiles at the same place (two sprites drawn on each other) count once
    return tuple(dict.fromkeys(sig)), cl


def main():
    args = sys.argv[1:]
    out = args[args.index("--out") + 1]
    dirs = [a for a in args if not a.startswith("--") and a != out]
    seen = collections.OrderedDict()
    for d in dirs:
        for f in sorted(glob.glob(os.path.join(d, "*.json"))):
            dump = json.load(open(f))
            ram = bytes.fromhex(dump["ram"])
            if ram[0x36] != 2:
                continue
            shapes = {s["key"]: s["pixels"] for s in dump["shapes"]}
            for cl in clusters(dump["tiles"]):
                sig, cl = signature(cl)
                pal = cl[0]["pal"]
                hist = collections.Counter()
                fx, fy = [], []  # where pixels are drawn (the shape's real extent)
                for t in cl:
                    px = dump_pixels.decode(shapes[t["key"]])
                    for i, v in enumerate(px):
                        if v:
                            hist[dump["palettes"][pal][v]] += 1
                            sx, sy = i % 8, i // 8
                            fx.append(t["x"] + (7 - sx if t["hflip"] else sx))
                            fy.append(t["y"] + (7 - sy if t["vflip"] else sy))
                fill = (max(fx) - min(fx) + 1, max(fy) - min(fy) + 1) if fx else (0, 0)
                xs = [t["x"] for t in cl]; ys = [t["y"] for t in cl]
                box = (min(xs), min(ys), max(xs) + 8, max(ys) + 8)
                e = seen.setdefault(sig, {"pal": pal, "count": 0, "first": os.path.basename(f), "box": box,
                                          "pals": collections.Counter()})
                e["count"] += 1
                e["fill"] = fill
                e["pals"][pal] += 1
                e.setdefault("feet", []).append(box[3] - 1)
                if "m7" not in e and dump.get("mode7"):
                    e["m7"] = dump["mode7"]["runs"][0]
                e.setdefault("hist", collections.Counter()).update(hist)
    groups = []
    for sig, e in seen.items():
        x0, y0, x1, y1 = e["box"]
        if e["pal"] in RACER_PALS:
            player = e["pal"] == 9 and x0 <= 128 <= x1 and y0 <= 90 <= y1 and len(sig) >= 6
            obj = "player" if player else "rival"
        else:
            obj = "track_pal%d" % e["pal"]
        groups.append({"sig": sig, "object": obj, "count": e["count"], "first": e["first"],
                       "box": e["box"], "pal": e["pal"], "hist": dict(e["hist"].most_common(8)),
                       "foot": sorted(e["feet"])[len(e["feet"]) // 2], "m7": e.get("m7"),
                       "fill": e.get("fill")})
    json.dump(groups, open(out, "w"))
    by = collections.Counter(g["object"] for g in groups)
    print(len(groups), "distinct objects:", dict(by))


if __name__ == "__main__":
    main()
