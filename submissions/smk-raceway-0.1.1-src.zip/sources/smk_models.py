"""Models of the smk-raceway pack, built from primitives (original designs).

In Blender (live, through MCP):   exec(open(".../smk_models.py").read()); build("kart_player")
Headless (see export_models.py):   blender -b --python smk_models.py -- NAME OUT.blend

Convention (tools/luxo3d/MODELS.md): 1 unit = 1 game pixel, Z up, feet on Z = 0.
Karts are seen from behind in the race view, and a group without `facing` turns the model
towards the camera, so karts are built with their FRONT towards +Y: the camera sees the
rear (engine, exhausts, the driver's back).

Models:
  kart_player  the player's kart: red body, driver in a red helmet and blue suit
  kart_rival   the same kart with palette materials: the rival's own colours
               (pal10 helmet and body, pal12 suit, pal9 trim, pal8 gloves)
  pipe         a green warp-style pipe (generic object)
  coin         a gold coin on its edge
  banana       a banana peel
  shell        a turtle-style shell (generic)
  item_box     a floating, glowing question-mark cube (not used by a group: item boxes
               are Mode 7 floor art in this course)
"""
import math
import bpy
import bmesh
import numpy as np

# ---------------------------------------------------------------------------
# helpers


def clean():
    for c in (bpy.data.objects, bpy.data.meshes, bpy.data.materials, bpy.data.images,
              bpy.data.collections):
        for x in list(c):
            c.remove(x)


def tex(name, size, fn):
    """A generated texture: fn(u, v) -> (r, g, b) arrays in 0..1."""
    img = bpy.data.images.get(name)
    if img:
        return img
    img = bpy.data.images.new(name, size, size)
    v, u = np.mgrid[0:size, 0:size] / float(size)
    r, g, b = fn(u, v)
    px = np.stack([r, g, b, np.ones_like(r)], -1).astype(np.float32)
    img.pixels.foreach_set(px.ravel())
    img.pack()
    return img


def noise(u, v, s=7):
    rng = np.random.default_rng(s)
    n = rng.random(u.shape)
    return n


def tex_grain():  # light grey detail texture for palette materials and paint
    def f(u, v):
        n = noise(u, v, 3)
        g = 0.86 + 0.14 * n
        return g, g, g
    return tex("smk_grain", 64, f)


def tex_rubber():
    def f(u, v):
        tread = (np.floor(v * 16) % 2) * 0.12
        g = 0.18 + tread + 0.05 * noise(u, v, 5)
        return g, g, g
    return tex("smk_rubber", 64, f)


def tex_metal():
    def f(u, v):
        n = noise(u, v, 9)
        brush = 0.08 * np.sin(v * 140.0)
        g = 0.72 + 0.12 * n + brush
        return g, g, g * 1.03
    return tex("smk_metal", 64, f)


def tex_checker():  # number plate / flag accents
    def f(u, v):
        c = ((np.floor(u * 4) + np.floor(v * 4)) % 2)
        g = 0.12 + 0.85 * c
        return g, g, g
    return tex("smk_checker", 32, f)


def mat(name, rgb, image=None, rough=0.5, metal=0.0):
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = next(n for n in nt.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*rgb, 1)
    bsdf.inputs["Roughness"].default_value = rough
    bsdf.inputs["Metallic"].default_value = metal
    if image is not None:
        # The exporter writes a linked texture with factor 1, so the colour is baked into
        # a tinted copy of the texture (palette materials keep the light grey texture: the
        # palette colour multiplies it in Luxo).
        if not name.startswith("pal") and tuple(rgb) != (1, 1, 1):
            tname = image.name + "_" + name
            timg = bpy.data.images.get(tname)
            if timg is None:
                w, h = image.size
                px = np.array(image.pixels[:], dtype=np.float32).reshape(h, w, 4)
                px[..., :3] *= np.array(rgb, dtype=np.float32)
                timg = bpy.data.images.new(tname, w, h)
                timg.pixels.foreach_set(px.ravel())
                timg.pack()
            image = timg
        t = nt.nodes.new("ShaderNodeTexImage")
        t.image = image
        t.interpolation = "Closest"
        nt.links.new(t.outputs["Color"], bsdf.inputs["Base Color"])
    m.diffuse_color = (*rgb, 1)
    return m


def set_factor(m, rgb):
    """The glTF exporter takes the factor from a Mix/multiply only in some versions; keep the
    colour on the material's diffuse colour and on the BSDF so both paths export it."""
    m.diffuse_color = (*rgb, 1)


def box_uv(obj, scale=0.12):
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)
    uv = bm.loops.layers.uv.verify()
    for f in bm.faces:
        n = f.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        for l in f.loops:
            co = l.vert.co
            if ax == 0:
                l[uv].uv = (co.y * scale, co.z * scale)
            elif ax == 1:
                l[uv].uv = (co.x * scale, co.z * scale)
            else:
                l[uv].uv = (co.x * scale, co.y * scale)
    bm.to_mesh(me)
    bm.free()


def finish(obj, m, bevel=0.0, segs=2, smooth=True, coll=None):
    obj.data.materials.clear()
    obj.data.materials.append(m)
    if bevel > 0:
        mod = obj.modifiers.new("bevel", "BEVEL")
        mod.width = bevel
        mod.segments = segs
        mod.limit_method = "ANGLE"
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action="DESELECT")
        obj.select_set(True)
        bpy.ops.object.modifier_apply(modifier="bevel")
    if smooth:
        for p in obj.data.polygons:
            p.use_smooth = True
    box_uv(obj)
    if coll is not None:
        for c in list(obj.users_collection):
            c.objects.unlink(obj)
        coll.objects.link(obj)
    return obj


def cube(name, loc, size, m, bevel=0.6, coll=None, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return finish(o, m, bevel, 2, False, coll)


def cyl(name, loc, r, depth, m, rot=(0, 0, 0), verts=20, bevel=0.4, coll=None, r2=None):
    if r2 is None:
        bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=r, depth=depth, location=loc, rotation=rot)
    else:
        bpy.ops.mesh.primitive_cone_add(vertices=verts, radius1=r, radius2=r2, depth=depth, location=loc,
                                        rotation=rot)
    o = bpy.context.active_object
    o.name = name
    return finish(o, m, bevel, 2, True, coll)


def sphere(name, loc, r, m, scale=(1, 1, 1), coll=None, segs=20, rings=12):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segs, ring_count=rings, radius=r, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return finish(o, m, 0, 0, True, coll)


def torus(name, loc, R, r, m, rot=(0, 0, 0), coll=None):
    bpy.ops.mesh.primitive_torus_add(major_radius=R, minor_radius=r, location=loc, rotation=rot,
                                     major_segments=24, minor_segments=10)
    o = bpy.context.active_object
    o.name = name
    return finish(o, m, 0, 0, True, coll)


def collection(name):
    c = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(c)
    return c


# ---------------------------------------------------------------------------
# kart


def build_kart(name, colours):
    """colours: dict of material for body, trim, helmet, suit, glove (palette or fixed)."""
    C = collection(name)
    p = name + "_"
    grain, rubber, metal, checker = tex_grain(), tex_rubber(), tex_metal(), tex_checker()
    M = colours
    tyre = mat("smk_tyre", (0.09, 0.09, 0.1), rubber, 0.9)
    steel = mat("smk_steel", (0.75, 0.76, 0.8), metal, 0.35, 0.8)
    dark = mat("smk_dark", (0.12, 0.13, 0.15), None, 0.6)
    visor = mat("smk_visor", (0.05, 0.08, 0.14), None, 0.1, 0.3)
    plate = mat("smk_plate", (1, 1, 1), checker, 0.5)

    # chassis: low tub, front +Y. width 26, length 30
    cube(p + "body", (0, 0, 6.0), (20, 28, 5), M["body"], 1.6, C)
    cube(p + "nose", (0, 14.5, 5.5), (16, 6, 4), M["body"], 1.8, C)
    cube(p + "bumper_f", (0, 18.0, 3.6), (24, 2.4, 2.6), M["trim"], 1.0, C)
    cube(p + "bumper_r", (0, -15.0, 4.0), (26, 2.6, 3.2), M["trim"], 1.0, C)
    cube(p + "floor", (0, 0, 3.0), (22, 30, 1.6), dark, 0.5, C)
    # side pods
    for s in (-1, 1):
        cube(p + "pod%d" % s, (s * 10.5, 1.0, 6.2), (3.4, 14, 3.6), M["trim"], 1.2, C)
    # engine block and exhausts at the rear (towards the camera)
    cube(p + "engine", (0, -10.5, 9.4), (11, 6, 5), steel, 1.0, C)
    for s in (-1, 1):
        cyl(p + "exhaust%d" % s, (s * 4.0, -15.2, 10.5), 1.3, 5, steel, rot=(math.pi / 2, 0, 0), verts=12, coll=C)
        cyl(p + "exhaust_tip%d" % s, (s * 4.0, -17.8, 10.5), 0.8, 0.6, dark, rot=(math.pi / 2, 0, 0), verts=12,
            bevel=0, coll=C)
    # rear number plate (checker) and seat
    cube(p + "plate", (0, -16.4, 6.2), (8, 0.6, 3.0), plate, 0.2, C)
    cube(p + "seat", (0, -3.5, 10.0), (11, 6, 4), dark, 1.2, C)
    cube(p + "seatback", (0, -6.5, 13.5), (11, 2.2, 7), dark, 1.0, C)
    # steering wheel
    torus(p + "wheel_ring", (0, 6.0, 14.0), 3.0, 0.6, dark, rot=(math.radians(60), 0, 0), coll=C)
    cyl(p + "column", (0, 8.0, 11.0), 0.6, 6, steel, rot=(math.radians(-30), 0, 0), verts=8, bevel=0, coll=C)
    # wheels: big rears, smaller fronts
    for s in (-1, 1):
        for (y, r, w) in ((-10.0, 5.2, 5.0), (11.0, 4.2, 4.0)):
            x = s * (13.0 + w / 2 - 1)
            cyl(p + "tyre%d_%d" % (s, int(y)), (x, y, r), r, w, tyre, rot=(0, math.pi / 2, 0), verts=24,
                bevel=0.8, coll=C)
            cyl(p + "hub%d_%d" % (s, int(y)), (x + s * (w / 2), y, r), r * 0.45, 0.8, steel,
                rot=(0, math.pi / 2, 0), verts=16, bevel=0.2, coll=C)
    # spoiler over the rear
    cube(p + "spoiler", (0, -13.5, 15.5), (24, 3.5, 1.0), M["trim"], 0.4, C)
    for s in (-1, 1):
        cube(p + "spoiler_post%d" % s, (s * 6, -12.5, 12.8), (1.2, 1.2, 5), steel, 0.2, C)
    return C


def build_driver(name, M, C, build="hero"):
    p = name + "_drv_"
    dark = mat("smk_dark", (0.12, 0.13, 0.15), None, 0.6)
    visor = mat("smk_visor", (0.05, 0.08, 0.14), None, 0.1, 0.3)
    white = mat("smk_white", (0.95, 0.95, 0.95), None, 0.5)
    # torso seated on the seat, leaning slightly forward, back to the camera
    sphere(p + "torso", (0, -3.5, 16.5), 5.2, M["suit"], scale=(1.15, 0.9, 1.15), coll=C)
    sphere(p + "hips", (0, -2.0, 12.0), 4.5, M["suit"], scale=(1.2, 1.1, 0.7), coll=C)
    # arms reaching to the wheel
    for s in (-1, 1):
        cyl(p + "arm%d" % s, (s * 4.6, 1.0, 16.0), 1.7, 9, M["suit"], rot=(math.radians(-70), 0, s * math.radians(-12)),
            verts=12, bevel=0.3, coll=C)
        sphere(p + "glove%d" % s, (s * 3.0, 5.5, 14.5), 1.9, M["glove"], coll=C)
        sphere(p + "shoulder%d" % s, (s * 5.2, -3.0, 19.0), 2.2, M["suit"], coll=C)
    # racing stripe down the back
    cube(p + "stripe", (0, -8.0, 17.0), (2.0, 1.0, 7.0), white, 0.4, C,
         rot=(math.radians(-8), 0, 0))
    # helmet: a big round shell (the sprite's big head), visor at the front, a fin on top
    sphere(p + "helmet", (0, -2.0, 26.0), 6.6, M["helmet"], scale=(1.0, 1.0, 0.95), coll=C, segs=28, rings=16)
    sphere(p + "visor", (0, 2.6, 25.5), 4.6, visor, scale=(1.05, 0.6, 0.55), coll=C)
    cube(p + "fin", (0, -2.0, 32.3), (1.4, 8.0, 1.6), white, 0.6, C)
    torus(p + "collar", (0, -2.0, 20.3), 4.2, 1.1, dark, coll=C)
    # a white band round the helmet, and a badge on its back
    torus(p + "band", (0, -2.0, 25.0), 6.45, 0.55, white, coll=C)
    sphere(p + "badge", (0, -8.4, 27.0), 1.8, white, scale=(1, 0.4, 1), coll=C)
    if build == "hero":
        # the hero wears a little cape-like scarf flying back over the engine
        cube(p + "scarf", (0, -9.5, 19.0), (5.0, 5.0, 0.8), M["trim"], 0.4, C, rot=(math.radians(-25), 0, 0))


def kart_player():
    grain = tex_grain()
    M = {"body": mat("player_red", (0.85, 0.06, 0.05), grain, 0.35),
         "trim": mat("player_white", (0.93, 0.93, 0.9), grain, 0.4),
         "helmet": mat("player_red", (0.85, 0.06, 0.05), grain, 0.35),
         "suit": mat("player_suit", (0.08, 0.25, 0.85), grain, 0.7),
         "glove": mat("player_glove", (0.97, 0.97, 0.95), None, 0.6)}
    C = build_kart("kart_player", M)
    build_driver("kart_player", M, C, "hero")


def kart_rival():
    grain = tex_grain()
    # palette materials: each rival's own colours (see the docstring)
    M = {"body": mat("pal10", (0.6, 0.6, 0.6), grain, 0.35),
         "trim": mat("pal9", (0.7, 0.7, 0.7), grain, 0.4),
         "helmet": mat("pal10", (0.6, 0.6, 0.6), grain, 0.35),
         "suit": mat("pal12", (0.5, 0.5, 0.5), grain, 0.7),
         "glove": mat("pal8", (0.8, 0.8, 0.8), None, 0.6)}
    C = build_kart("kart_rival", M)
    build_driver("kart_rival", M, C, "rival")


# ---------------------------------------------------------------------------
# track objects


def pipe():
    """Sprite: 16 wide, 16-24 tall when near. A green pipe with a lip."""
    C = collection("pipe")
    def f(u, v):
        band = 0.75 + 0.25 * np.clip(np.sin(u * math.pi * 2) * 1.5, -1, 1) * 0.5
        n = 0.05 * noise(u, v, 11)
        return 0.15 * band + n, 0.75 * band + n, 0.2 * band + n
    green = mat("pipe_green", (1, 1, 1), tex("smk_pipe", 64, f), 0.3)
    dark = mat("pipe_inside", (0.02, 0.12, 0.03), None, 0.8)
    cyl("pipe_body", (0, 0, 10), 6.0, 20, green, verts=28, bevel=0.3, coll=C)
    cyl("pipe_lip", (0, 0, 21.5), 7.6, 5, green, verts=28, bevel=0.8, coll=C)
    cyl("pipe_hole", (0, 0, 23.6), 6.0, 1.2, dark, verts=28, bevel=0, coll=C)


def coin():
    """Sprite: 8 wide, 16 tall. A thick gold coin on its edge, facing the camera."""
    C = collection("coin")
    gold = mat("coin_gold", (1.0, 0.78, 0.1), tex_metal(), 0.25, 0.9)
    rim = mat("coin_rim", (0.85, 0.5, 0.05), tex_metal(), 0.3, 0.9)
    cyl("coin_face", (0, 0, 8), 6.5, 2.2, gold, rot=(math.pi / 2, 0, 0), verts=24, bevel=0.5, coll=C)
    torus("coin_rim", (0, 0, 8), 6.5, 0.9, rim, rot=(math.pi / 2, 0, 0), coll=C)
    cube("coin_slot", (0, -1.2, 8), (1.6, 0.6, 7.0), rim, 0.2, C)
    o = bpy.data.objects["coin_face"]
    o.scale = (0.75, 1, 1.0)


def banana():
    """Sprite: one tile, 8x8. A peel lying flat with three flaps."""
    C = collection("banana")
    yellow = mat("banana_yellow", (1.0, 0.85, 0.15), tex_grain(), 0.5)
    brown = mat("banana_tip", (0.35, 0.22, 0.08), None, 0.7)
    sphere("banana_core", (0, 0, 2.5), 2.2, yellow, scale=(1, 1, 1.4), coll=C)
    for i in range(3):
        a = i * 2 * math.pi / 3 + 0.3
        cube("banana_flap%d" % i, (math.cos(a) * 3.0, math.sin(a) * 3.0, 0.7), (4.5, 2.2, 0.8), yellow, 0.4, C,
             rot=(0, 0, a))
    cyl("banana_stem", (0, 0, 5.8), 0.6, 1.8, brown, verts=8, bevel=0, coll=C)


def shell():
    """A generic turtle-style shell: dome with plates and a white rim. 12 wide."""
    C = collection("shell")
    def f(u, v):
        hexes = (np.sin(u * 40) * np.sin(v * 40) > 0.6) * 0.25
        g = 0.75 + hexes + 0.05 * noise(u, v, 13)
        return 0.1 * g, 0.75 * g, 0.15 * g
    green = mat("shell_green", (1, 1, 1), tex("smk_shell", 64, f), 0.3)
    white = mat("shell_rim", (0.97, 0.97, 0.95), tex_grain(), 0.4)
    sphere("shell_dome", (0, 0, 3.0), 6.0, green, scale=(1, 1, 0.75), coll=C)
    torus("shell_rim", (0, 0, 2.6), 5.8, 1.3, white, coll=C)
    cube("shell_base", (0, 0, 1.0), (9, 9, 2.0), white, 0.8, C)


def item_box():
    """A floating cube with a question mark (generic), 14 units."""
    C = collection("item_box")
    glyph = ["........",
             "..####..",
             ".##..##.",
             ".....##.",
             "....##..",
             "...##...",
             "........",
             "...##..."]
    G = np.array([[c == "#" for c in row] for row in glyph])

    def f(u, v):
        gx = np.clip((u * 10 - 1).astype(int), -1, 8)
        gy = np.clip(((1 - v) * 10 - 1).astype(int), -1, 8)  # image rows run bottom-up
        inside = (gx >= 0) & (gx < 8) & (gy >= 0) & (gy < 8)
        q = np.zeros_like(u, dtype=bool)
        q[inside] = G[gy[inside], gx[inside]]
        edge = (u < 0.06) | (u > 0.94) | (v < 0.06) | (v > 0.94)
        r = np.where(q, 1.0, np.where(edge, 0.75, 0.98))
        g = np.where(q, 1.0, np.where(edge, 0.35, 0.62))
        b = np.where(q, 1.0, np.where(edge, 0.05, 0.12))
        return r, g, b
    m = mat("item_face", (1, 1, 1), tex("smk_qbox", 64, f), 0.3)
    o = cube("item_box", (0, 0, 9), (14, 14, 14), m, 1.0, C)
    # face UVs 0..1 per side
    me = o.data
    bm = bmesh.new(); bm.from_mesh(me)
    uv = bm.loops.layers.uv.verify()
    for fc in bm.faces:
        n = fc.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        for l in fc.loops:
            co = l.vert.co
            a, b = [(co.y, co.z), (co.x, co.z), (co.x, co.y)][ax]
            s = 1 if n[ax] < 0 else -1  # read left to right on every side
            ua = (a + 7) / 14 if (ax != 0 or s > 0) else (7 - a) / 14
            if ax == 1 and n[1] > 0:
                ua = (7 - a) / 14
            l[uv].uv = (ua, (b + 7) / 14)  # local coordinates: the cube spans -7..7
    bm.to_mesh(me); bm.free()
    cube("item_box_stand", (0, 0, 0.5), (4, 4, 1), mat("smk_dark", (0.12, 0.13, 0.15)), 0.3, C)


BUILDERS = {"kart_player": kart_player, "kart_rival": kart_rival, "pipe": pipe, "coin": coin,
            "banana": banana, "shell": shell, "item_box": item_box}


def build(name):
    clean()
    BUILDERS[name]()
    tris = 0
    for o in bpy.data.objects:
        if o.type == "MESH":
            o.data.calc_loop_triangles()
            tris += len(o.data.loop_triangles)
    print(name, "triangles", tris)


if __name__ == "__main__":
    import sys
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if argv:
        build(argv[0])
        bpy.ops.wm.save_as_mainfile(filepath=argv[1])
