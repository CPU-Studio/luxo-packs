# smk-raceway sources

Everything in `packs/smk-raceway/` is rebuilt by these scripts (run from the trial folder).

| Script | What it does |
|---|---|
| `smk_models.py` | Builds each model from primitives and generated textures (original designs). Live: `exec(open(".../smk_models.py").read()); build("kart_player")`. Headless: `blender -b --python smk_models.py -- NAME OUT.blend` |
| `export_models.py` | `python3 -I export_models.py packs/smk-raceway [names]`: builds `blend/<name>.blend` and exports `models/<name>.glb` with `tools/luxo3d/blender_export.py` |
| `smk_groups.py` | `python3 -I smk_groups.py DUMP_DIR... --out work/objects.json`: joins each race frame's sprites into objects (same palette, touching) and lists every distinct one, with its colours, drawn extent, median foot line and the Mode 7 run |
| `smk_pack.py` | `python3 -I smk_pack.py work/objects.json packs/smk-raceway`: names the objects (player, rival, pipe, coin, banana), sizes far ones by distance, writes `groups` and `models` into `pack.json` |
| `check_player.py` | `python3 -I check_player.py packs/smk-raceway DUMP_DIR`: applies the pack to dumps and lists racing frames where the player is not a model |

Scenes, HUD regions and pack metadata were set with `edit_pack` and are kept by `smk_pack.py`
(it only replaces `groups` and `models`).

To rebuild from scratch (the dumps are made by `capture` with `inputs/race.txt` from
`states/grid_001150.state`, every 10 frames into `dumps/race2`, and every frame into
`work/check2`):

```
python3 -I sources/smk/export_models.py packs/smk-raceway
python3 -I sources/smk/smk_groups.py dumps/race2 dumps/racefine dumps/grid work/check2 --out work/objects.json
python3 -I sources/smk/smk_pack.py work/objects.json packs/smk-raceway
```

`work/drive.py` (outside this folder) made the inputs: a closed-loop driver that follows a
rival's recorded line using the kart's RAM (x `0x1018`, y `0x101C`, heading `0x102A`).

0.1.1 (by hand in `pack.json`, which the scripts keep): the rank and counters HUD region
widened to x 176-256, so the big rank digit is in it.
