import json, glob, subprocess, os
import os  # noqa: E402
REPO = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "..", ".."))  # the repository root
TRIAL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
L = os.path.join(REPO, "tools", "luxo3d", "out", "luxo3d")
ROM = os.path.join(REPO, "roms", "Super Mario Kart (USA).sfc")
out = os.path.join(TRIAL, "work/rivals")
os.makedirs(out, exist_ok=True)
subprocess.run([L, "capture", "--rom", ROM, "--state", os.path.join(TRIAL, "states/grid_001150.state"),
                "--frames", "3600", "--every", "8",
                "--out", out, "--name", "r"], check=True, capture_output=True)
fs = sorted(glob.glob(out + "/r_*.json"))
paths = {k: [] for k in range(8)}
for f in fs:
    r = bytes.fromhex(json.load(open(f))["ram"])
    for k in range(8):
        b = 0x1000 + 0x100 * k
        paths[k].append((r[b + 0x18] | r[b + 0x19] << 8, r[b + 0x1c] | r[b + 0x1d] << 8))
json.dump(paths, open(os.path.join(TRIAL, "work/rival_paths.json"), "w"))
for k in range(8):
    p = paths[k]
    print(k, p[60], p[100], p[200], p[300], p[400])
