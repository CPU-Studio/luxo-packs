"""2D sprite beside its 3D model, cut from a render_preview picture (2048x768), scaled x2.
The preview's own `crop` cuts the sprite's 2D place in the 3D half too, which is wrong for
models the engine moves onto the Mode 7 floor, so crops are cut by hand.
    crops.py IMAGE OUT  x2d y2d w2d h2d  x3d y3d w3d h3d"""
import subprocess, sys
img, out = sys.argv[1], sys.argv[2]
a = list(map(int, sys.argv[3:11]))
h = max(a[3], a[7]) * 3
f = ("[0:v]crop=%d:%d:%d:%d,scale=-1:%d:flags=neighbor[a];"
     "[0:v]crop=%d:%d:%d:%d,scale=-1:%d:flags=neighbor[b];[a][b]hstack" %
     (a[2], a[3], a[0], a[1], h, a[6], a[7], a[4], a[5], h))
subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", img, "-filter_complex", f, out], check=True)
print(out)
