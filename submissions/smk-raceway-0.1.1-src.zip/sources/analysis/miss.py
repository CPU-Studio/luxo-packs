import json, sys, os
T = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(T, "sources/smk"))
import smk_groups as g
objs = json.load(open(os.path.join(T, "work/objects.json")))
known = {tuple(tuple(x) for x in o["sig"]) for o in objs}
d_in = sys.argv[1]
for fr in [int(a) for a in sys.argv[2:]]:
    d = json.load(open(os.path.join(T, d_in, "c_%06d.json" % fr)))
    for cl in g.clusters(d["tiles"]):
        sig, cl = g.signature(cl)
        xs = [t["x"] for t in cl]; ys = [t["y"] for t in cl]
        if min(xs) <= 128 <= max(xs) + 8 and min(ys) <= 90 <= max(ys) + 8:
            print(fr, "pal", cl[0]["pal"], "tiles", len(sig), "box", (min(xs), min(ys), max(xs) + 8, max(ys) + 8),
                  "known", tuple(tuple(x) for x in sig) in known)
