"""Closed-loop driver: follows a rival's recorded line (pure pursuit) in short segments,
writing the inputs it chose to inputs/race.txt (frames from grid_001150.state)."""
import json, glob, subprocess, os, math, sys, shutil
import os  # noqa: E402
REPO = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "..", ".."))  # the repository root
TRIAL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
L = os.path.join(REPO, "tools", "luxo3d", "out", "luxo3d")
ROM = os.path.join(REPO, "roms", "Super Mario Kart (USA).sfc")
W = os.path.join(TRIAL, "work/drive")
os.makedirs(W, exist_ok=True)
paths = json.load(open(os.path.join(TRIAL, "work/rival_paths.json")))
RIVAL = sys.argv[1] if len(sys.argv) > 1 else "4"
END = int(sys.argv[2]) if len(sys.argv) > 2 else 5400
LOOK = int(sys.argv[3]) if len(sys.argv) > 3 else 48
raw = paths[RIVAL]
# one lap of the rival: from leaving the grid until back near its start, then loop
start = raw[0]
path = []
for i, p in enumerate(raw):
    if i > 100 and abs(p[0] - start[0]) < 60 and p[1] < start[1] and p[1] > start[1] - 80:
        break
    if not path or (p[0] - path[-1][0]) ** 2 + (p[1] - path[-1][1]) ** 2 > 16:
        path.append(p)
print("path points", len(path))

SEG = 6
START = 560          # race starts (lights) around here; hold B from just before
state = os.path.join(TRIAL, "states/grid_001150.state")
lines = []
frame = 0
# before the start: just wait, holding B late (a rocket start is luck; fine)
seg_in = os.path.join(W, "seg.txt")
def run(state, n, buttons):
    with open(seg_in, "w") as f:
        f.write("0-%d %s\n" % (n - 1, buttons) if buttons else "")
    for g in glob.glob(W + "/s_*"):
        os.remove(g)
    subprocess.run([L, "capture", "--rom", ROM, "--state", state, "--frames", str(n), "--every", str(n),
                    "--inputs", seg_in, "--out", W, "--name", "s", "--save-at", str(n)],
                   check=True, capture_output=True)
    d = json.load(open(glob.glob(W + "/s_*.json")[-1]))
    st = glob.glob(W + "/s_%06d.state" % n)[0]
    keep = os.path.join(W, "cur.state")
    shutil.copy(st, keep)
    return d, keep

d, state = run(state, START, "")
lines.append("%d-%d B" % (START - 40, START - 1)) if False else None
frame = START
idx = 0
log = []
while frame < END:
    r = bytes.fromhex(d["ram"])
    x = r[0x1018] | r[0x1019] << 8
    y = r[0x101c] | r[0x101d] << 8
    h = r[0x102a] | r[0x102b] << 8
    # nearest path point near the current index (search forward a window)
    best, bi = 1e18, idx
    for k in range(idx - 5, idx + 40):
        p = path[k % len(path)]
        dd = (p[0] - x) ** 2 + (p[1] - y) ** 2
        if dd < best:
            best, bi = dd, k
    idx = bi
    # look ahead along the path
    acc, k = 0, idx
    while acc < LOOK:
        a, b = path[k % len(path)], path[(k + 1) % len(path)]
        acc += math.hypot(b[0] - a[0], b[1] - a[1]); k += 1
    tx, ty = path[k % len(path)]
    want = math.atan2(tx - x, -(ty - y))           # 0 = north, + = clockwise (east)
    have = (h / 65536.0) * 2 * math.pi
    err = (want - have + math.pi) % (2 * math.pi) - math.pi
    btn = "B"
    if err > 0.12: btn += "+RIGHT"
    elif err < -0.12: btn += "+LEFT"
    # use an item now and then
    if (frame // SEG) % 50 == 0: btn += "+A"
    lines.append("%d-%d %s" % (frame, frame + SEG - 1, btn))
    log.append((frame, x, y, h, idx, round(err, 2), btn))
    d, state = run(state, SEG, btn)
    frame += SEG
    if frame % 300 < SEG:
        print(frame, x, y, idx, len(path), round(math.sqrt(best)), flush=True)
with open(os.path.join(TRIAL, "inputs/" + (sys.argv[4] if len(sys.argv) > 4 else "race.txt")), "w") as f:
    f.write("\n".join(lines) + "\n")
json.dump(log, open(os.path.join(W, "log.json"), "w"))
print("done", frame)
